package com.aronarik.photostudio.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun PhotoshopScreen() {
    var brushSize by remember { mutableFloatStateOf(24f) }
    var brushOpacity by remember { mutableFloatStateOf(1.0f) }
    val paths = remember { mutableStateListOf<List<Offset>>() }
    var currentPath by remember { mutableStateOf(listOf<Offset>()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Options Top Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface)
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "BRUSH TOOL",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.primary
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = "Size: ${brushSize.toInt()}px", fontSize = 11.sp, color = Color.White)
                Slider(
                    value = brushSize,
                    onValueChange = { brushSize = it },
                    valueRange = 5f..100f,
                    modifier = Modifier.width(120.dp)
                )
            }
        }

        // Interactive Layer Canvas
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(Color(0xFF090B0E))
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragStart = { offset ->
                            currentPath = listOf(offset)
                        },
                        onDrag = { change, _ ->
                            currentPath = currentPath + change.position
                        },
                        onDragEnd = {
                            if (currentPath.isNotEmpty()) {
                                paths.add(currentPath)
                                currentPath = emptyList()
                            }
                        }
                    )
                }
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                // Render committed paths
                for (path in paths) {
                    for (i in 0 until path.size - 1) {
                        drawLine(
                            color = Color(0xFF00D2FF),
                            start = path[i],
                            end = path[i + 1],
                            strokeWidth = brushSize,
                            cap = StrokeCap.Round
                        )
                    }
                }
                // Render active drag path
                for (i in 0 until currentPath.size - 1) {
                    drawLine(
                        color = Color(0xFF00D2FF),
                        start = currentPath[i],
                        end = currentPath[i + 1],
                        strokeWidth = brushSize,
                        cap = StrokeCap.Round
                    )
                }
            }
        }

        // Bottom Layers Dock
        Surface(
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Active: Layer 1 (Paint)",
                    fontSize = 12.sp,
                    color = Color.White
                )
                Button(
                    onClick = { paths.clear() },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Text("Clear Canvas", fontSize = 11.sp)
                }
            }
        }
    }
}
