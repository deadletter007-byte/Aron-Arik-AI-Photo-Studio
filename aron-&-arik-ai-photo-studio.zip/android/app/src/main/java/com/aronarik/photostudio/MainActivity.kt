package com.aronarik.photostudio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.aronarik.photostudio.ui.navigation.AronArikNavGraph
import com.aronarik.photostudio.ui.theme.AronArikStudioTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Samsung Galaxy S21 Plus (SM-G996U) One UI 7 / Android 15 Entry Point
        setContent {
            AronArikStudioTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AronArikNavGraph()
                }
            }
        }
    }
}
