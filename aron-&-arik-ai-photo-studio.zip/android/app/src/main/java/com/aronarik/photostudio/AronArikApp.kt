package com.aronarik.photostudio

import android.app.Application

class AronArikApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Initialize memory-efficient bitmap caching and Snapdragon 888 GPU hardware acceleration
    }
}
