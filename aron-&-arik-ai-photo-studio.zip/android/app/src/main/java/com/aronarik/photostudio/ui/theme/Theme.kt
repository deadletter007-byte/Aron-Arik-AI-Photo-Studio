package com.aronarik.photostudio.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val StudioBlack = Color(0xFF0D0F12)
val StudioGraphite = Color(0xFF121418)
val StudioTitanium = Color(0xFF1B1F27)
val StudioCharcoal = Color(0xFF252B37)
val StudioCyan = Color(0xFF00D2FF)
val StudioElectricBlue = Color(0xFF0099FF)
val StudioSilver = Color(0xFFE2E8F0)

private val DarkColorScheme = darkColorScheme(
    primary = StudioCyan,
    onPrimary = Color.Black,
    secondary = StudioElectricBlue,
    onSecondary = Color.White,
    background = StudioBlack,
    onBackground = StudioSilver,
    surface = StudioGraphite,
    onSurface = StudioSilver,
    surfaceVariant = StudioTitanium,
    onSurfaceVariant = Color(0xFF94A3B8)
)

@Composable
fun AronArikStudioTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        content = content
    )
}
