package com.aronarik.photostudio.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun LightroomScreen() {
    var exposure by remember { mutableFloatStateOf(0f) }
    var contrast by remember { mutableFloatStateOf(0f) }
    var highlights by remember { mutableFloatStateOf(0f) }
    var shadows by remember { mutableFloatStateOf(0f) }
    var temperature by remember { mutableFloatStateOf(0f) }
    var vibrance by remember { mutableFloatStateOf(0f) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Preview Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(240.dp)
                .background(Color(0xFF0A0C0F))
        ) {
            Text(
                text = "LIGHTROOM DEVELOP CANVAS (SM-G996U)",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(12.dp)
            )
        }

        // Sliders Scrollable Area
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(
                    text = "TONE CONTROLS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF64748B)
                )
            }

            item {
                AdjustmentSlider(
                    label = "Exposure",
                    value = exposure,
                    range = -2f..2f,
                    unit = " EV",
                    onValueChange = { exposure = it }
                )
            }

            item {
                AdjustmentSlider(
                    label = "Contrast",
                    value = contrast,
                    range = -100f..100f,
                    unit = "",
                    onValueChange = { contrast = it }
                )
            }

            item {
                AdjustmentSlider(
                    label = "Highlights",
                    value = highlights,
                    range = -100f..100f,
                    unit = "",
                    onValueChange = { highlights = it }
                )
            }

            item {
                AdjustmentSlider(
                    label = "Shadows",
                    value = shadows,
                    range = -100f..100f,
                    unit = "",
                    onValueChange = { shadows = it }
                )
            }

            item {
                AdjustmentSlider(
                    label = "Temperature",
                    value = temperature,
                    range = -100f..100f,
                    unit = " K",
                    onValueChange = { temperature = it }
                )
            }

            item {
                AdjustmentSlider(
                    label = "Vibrance",
                    value = vibrance,
                    range = -100f..100f,
                    unit = "",
                    onValueChange = { vibrance = it }
                )
            }
        }
    }
}

@Composable
fun AdjustmentSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    unit: String,
    onValueChange: (Float) -> Unit
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = label, fontSize = 12.sp, color = Color.White)
            Text(
                text = "${String.format("%.1f", value)}$unit",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.primary
            )
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = range,
            modifier = Modifier.fillMaxWidth()
        )
    }
}
