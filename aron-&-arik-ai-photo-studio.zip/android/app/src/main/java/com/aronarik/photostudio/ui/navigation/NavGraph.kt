package com.aronarik.photostudio.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.aronarik.photostudio.ui.screens.*

sealed class Screen(val route: String, val title: String) {
    object Splash : Screen("splash", "Splash")
    object Home : Screen("home", "Home")
    object Assistant : Screen("assistant", "AI Assistant")
    object Photoshop : Screen("photoshop", "Photoshop")
    object Lightroom : Screen("lightroom", "Lightroom")
    object AiTools : Screen("aitools", "AI Tools")
}

@Composable
fun AronArikNavGraph() {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    Scaffold(
        bottomBar = {
            // Only show bottom navigation when not on splash screen
            if (currentRoute != "splash") {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface
                ) {
                    NavigationBarItem(
                        icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                        label = { Text("Home") },
                        selected = currentRoute == "home",
                        onClick = {
                            navController.navigate("home") {
                                launchSingleTop = true
                            }
                        }
                    )
                    NavigationBarItem(
                        icon = { Icon(Icons.Default.AutoAwesome, contentDescription = "AI Assistant") },
                        label = { Text("Assistant") },
                        selected = currentRoute == "assistant",
                        onClick = {
                            navController.navigate("assistant") {
                                launchSingleTop = true
                            }
                        }
                    )
                    NavigationBarItem(
                        icon = { Icon(Icons.Default.Layers, contentDescription = "Photoshop") },
                        label = { Text("Photoshop") },
                        selected = currentRoute == "photoshop",
                        onClick = {
                            navController.navigate("photoshop") {
                                launchSingleTop = true
                            }
                        }
                    )
                    NavigationBarItem(
                        icon = { Icon(Icons.Default.Tune, contentDescription = "Lightroom") },
                        label = { Text("Lightroom") },
                        selected = currentRoute == "lightroom",
                        onClick = {
                            navController.navigate("lightroom") {
                                launchSingleTop = true
                            }
                        }
                    )
                }
            }
        }
    ) { paddingValues ->
        NavHost(
            navController = navController,
            startDestination = "splash",
            modifier = Modifier.padding(if (currentRoute == "splash") androidx.compose.foundation.layout.PaddingValues() else paddingValues)
        ) {
            composable("splash") {
                AndroidSplashScreen(onTimeout = {
                    navController.navigate("home") {
                        popUpTo("splash") { inclusive = true }
                    }
                })
            }
            composable("home") { HomeScreen(onNavigate = { route -> navController.navigate(route) }) }
            composable("assistant") { AssistantScreen() }
            composable("photoshop") { PhotoshopScreen() }
            composable("lightroom") { LightroomScreen() }
            composable("aitools") { AiToolsScreen() }
        }
    }
}
