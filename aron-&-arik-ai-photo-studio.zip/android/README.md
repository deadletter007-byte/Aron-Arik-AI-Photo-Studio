# Aron & Arik AI Photo Studio — Native Android Project

Professional native Android photo editing application built with **Kotlin** and **Jetpack Compose**, targeting the **Samsung Galaxy S21 Plus (SM-G996U)** running **Android 15 and One UI 7**.

---

## 1. System Requirements & Architecture

- **Operating System:** Android 15 (API level 35) / One UI 7 compatible (Min SDK: 26).
- **Primary Target Device:** Samsung Galaxy S21+ 5G (`SM-G996U`) with Qualcomm Snapdragon 888, 8GB RAM, 20:9 Dynamic AMOLED 2X.
- **Language:** Kotlin 2.0+
- **UI Toolkit:** Jetpack Compose with Material 3 Dark Titanium design system.
- **Image Pipeline:** Native Android 2D Canvas & 32-bit ARGB_8888 hardware-accelerated Bitmap rendering.
- **AI Engine:** Dual provider architecture (Gemini 3.8 Flash Vision & OpenAI GPT-4o mini).

---

## 2. Project Directory Structure

```
android/
├── app/
│   ├── build.gradle.kts                # App-level dependencies & Android 15 configs
│   └── src/
│       └── main/
│           ├── AndroidManifest.xml     # App permissions & Theme.App.Starting
│           ├── java/com/aronarik/photostudio/
│           │   ├── AronArikApp.kt      # Application initialization
│           │   ├── MainActivity.kt     # Edge-to-edge Compose entry point
│           │   ├── engine/
│           │   │   ├── LayerEngine.kt  # Multi-layer compositing & blend modes
│           │   │   └── FilterPipeline.kt # 32-bit float Lightroom adjustments
│           │   ├── ui/
│           │   │   ├── navigation/     # NavHost & bottom navigation bar
│           │   │   ├── theme/          # Dark titanium, matte black & electric cyan
│           │   │   └── screens/
│           │   │       ├── SplashScreen.kt # Premium matte black Splash Screen with centered logo
│           │   │       ├── HomeScreen.kt
│           │   │       ├── PhotoshopScreen.kt
│           │   │       ├── LightroomScreen.kt
│           │   │       ├── AssistantScreen.kt
│           │   │       └── AiToolsScreen.kt
│           └── res/
│               ├── drawable/
│               │   ├── ic_launcher_background.xml # Matte black background (#0D0F12)
│               │   └── ic_launcher_foreground.xml # Authentic 3D AI Microchip Logo
│               ├── mipmap-anydpi-v26/
│               │   ├── ic_launcher.xml        # Adaptive Icon definition
│               │   └── ic_launcher_round.xml  # Round Adaptive Icon definition
│               ├── mipmap-*/                  # Density assets (mdpi, hdpi, xhdpi, xxhdpi, xxxhdpi)
│               └── values/                    # Colors, themes, strings
├── build.gradle.kts                    # Root build configuration
├── settings.gradle.kts                 # Project modules & repository mirrors
└── gradle.properties                   # JVM memory & AndroidX flags
```

---

## 3. How to Build & Run in Android Studio

1. **Open in Android Studio:**
   - Launch **Android Studio Ladybug (2024.2+)** or later.
   - Select **Open**, and choose the `android/` directory.
   - Wait for Gradle sync to complete automatically.

2. **Connect Device or Launch Emulator:**
   - Connect your **Samsung Galaxy S21+ (SM-G996U)** via USB with **USB Debugging** enabled in Developer Options.
   - Or create an Android Virtual Device (AVD) with screen resolution **1080 × 2400 (20:9)** running **Android 15 (API 35)**.

3. **Build & Install Debug APK:**
   ```bash
   ./gradlew installDebug
   ```

4. **Generate Signed Release APK / Android App Bundle (AAB):**
   ```bash
   ./gradlew assembleRelease
   ```
   The generated APK will be located at:
   `android/app/build/outputs/apk/release/app-release-unsigned.apk`

---

## 4. Configuring AI Credentials

- In the app, navigate to **Settings > AI Providers**.
- Enter your **Gemini API Key** (for Google AI) or **OpenAI API Key** (for ChatGPT).
- Keys are saved securely using Android `EncryptedSharedPreferences`.
