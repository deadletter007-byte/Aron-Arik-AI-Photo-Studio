import React, { useState } from 'react';
import { StudioProvider, useStudio } from './context/StudioContext';
import { Header } from './components/common/Header';
import { DeviceFrame } from './components/common/DeviceFrame';
import { HomeWorkspace } from './components/home/HomeWorkspace';
import { PhotoshopWorkspace } from './components/photoshop/PhotoshopWorkspace';
import { LightroomWorkspace } from './components/lightroom/LightroomWorkspace';
import { ExpressWorkspace } from './components/express/ExpressWorkspace';
import { AssistantWorkspace } from './components/assistant/AssistantWorkspace';
import { AiToolsWorkspace } from './components/aitools/AiToolsWorkspace';
import { ProjectsWorkspace } from './components/projects/ProjectsWorkspace';
import { SettingsWorkspace } from './components/settings/SettingsWorkspace';
import { ExportModal } from './components/export/ExportModal';
import { SplashScreen } from './components/common/SplashScreen';
import { RefreshCw } from 'lucide-react';

const MainStudioContent: React.FC = () => {
  const { currentTab, isProcessing, statusMessage, showSplash, setShowSplash } = useStudio();
  const [showExportModal, setShowExportModal] = useState(false);

  if (showSplash) {
    return <SplashScreen onFinish={() => setShowSplash(false)} />;
  }

  return (
    <div className="flex flex-col h-screen w-screen bg-[#0d0f12] text-slate-100 overflow-hidden font-sans">
      {/* Top Bar Navigation */}
      <Header onOpenExport={() => setShowExportModal(true)} />

      {/* Main Studio Viewport (Samsung Galaxy S21+ SM-G996U or Full Studio Desktop) */}
      <DeviceFrame>
        {currentTab === 'home' && <HomeWorkspace />}
        {currentTab === 'photoshop' && <PhotoshopWorkspace />}
        {currentTab === 'lightroom' && <LightroomWorkspace />}
        {currentTab === 'express' && <ExpressWorkspace />}
        {currentTab === 'assistant' && <AssistantWorkspace />}
        {currentTab === 'aitools' && <AiToolsWorkspace />}
        {currentTab === 'projects' && <ProjectsWorkspace />}
        {currentTab === 'settings' && <SettingsWorkspace />}
      </DeviceFrame>

      {/* Global Processing / AI Neural Synthesis Overlay */}
      {isProcessing && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex flex-col items-center justify-center p-6 space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-[#14171d] border border-[#00d2ff]/50 flex items-center justify-center shadow-2xl shadow-[#00d2ff]/20">
            <RefreshCw className="w-6 h-6 text-[#00d2ff] animate-spin" />
          </div>
          <p className="text-sm font-semibold text-white tracking-wide">
            {statusMessage || 'Processing neural engine...'}
          </p>
          <p className="text-xs text-slate-400 font-mono">Snapdragon 888 · SM-G996U Processing</p>
        </div>
      )}

      {/* Export Artwork Modal */}
      {showExportModal && <ExportModal onClose={() => setShowExportModal(false)} />}
    </div>
  );
};

export default function App() {
  return (
    <StudioProvider>
      <MainStudioContent />
    </StudioProvider>
  );
}
