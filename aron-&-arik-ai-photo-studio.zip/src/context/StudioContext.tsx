import React, { createContext, useContext, useState, useEffect, useRef, useCallback } from 'react';
import {
  ScreenTab,
  Layer,
  LightroomAdjustments,
  PhotoshopTool,
  BrushSettings,
  PresetItem,
  AppSettings,
  BlendMode,
} from '../types';
import { DEFAULT_ADJUSTMENTS, BUILT_IN_PRESETS, applyLightroomAdjustments } from '../utils/imageProcessing';
import { ASSETS, loadImage } from '../utils/assets';

interface StudioContextType {
  currentTab: ScreenTab;
  setCurrentTab: (tab: ScreenTab) => void;

  // Project Info
  projectName: string;
  setProjectName: (name: string) => void;
  canvasWidth: number;
  canvasHeight: number;
  setCanvasDimensions: (w: number, h: number) => void;

  // Layers
  layers: Layer[];
  selectedLayerId: string | null;
  setSelectedLayerId: (id: string | null) => void;
  selectedLayer: Layer | undefined;
  addEmptyLayer: (name?: string) => void;
  addImageLayer: (img: HTMLImageElement | HTMLCanvasElement, name?: string) => void;
  duplicateLayer: (id: string) => void;
  deleteLayer: (id: string) => void;
  reorderLayers: (startIndex: number, endIndex: number) => void;
  updateLayer: (id: string, updates: Partial<Layer>) => void;

  // Photoshop Tools
  activeTool: PhotoshopTool;
  setActiveTool: (tool: PhotoshopTool) => void;
  brushSettings: BrushSettings;
  setBrushSettings: React.Dispatch<React.SetStateAction<BrushSettings>>;

  // Lightroom Adjustments
  adjustments: LightroomAdjustments;
  setAdjustments: React.Dispatch<React.SetStateAction<LightroomAdjustments>>;
  updateAdjustment: <K extends keyof LightroomAdjustments>(key: K, value: LightroomAdjustments[K]) => void;
  resetAdjustments: () => void;
  applyPreset: (preset: PresetItem) => void;
  activePresetId: string | null;
  customPresets: PresetItem[];
  saveCustomPreset: (name: string, category?: string) => void;

  // Viewport / Zoom
  zoom: number;
  setZoom: React.Dispatch<React.SetStateAction<number>>;
  pan: { x: number; y: number };
  setPan: React.Dispatch<React.SetStateAction<{ x: number; y: number }>>;
  resetView: () => void;

  // Before/After comparison
  beforeAfterMode: boolean;
  setBeforeAfterMode: (enabled: boolean) => void;
  beforeAfterSplit: number; // 0 to 100 percentage
  setBeforeAfterSplit: (split: number) => void;

  // History (Undo / Redo)
  canUndo: boolean;
  canRedo: boolean;
  undo: () => void;
  redo: () => void;
  pushHistory: () => void;

  // Settings
  settings: AppSettings;
  updateSettings: (updates: Partial<AppSettings>) => void;

  // Processing state
  isProcessing: boolean;
  setIsProcessing: (val: boolean) => void;
  statusMessage: string | null;
  setStatusMessage: (msg: string | null) => void;

  // Splash Screen
  showSplash: boolean;
  setShowSplash: (show: boolean) => void;
  triggerSplash: () => void;

  // Composited output
  getMergedCanvas: () => HTMLCanvasElement;
  getFlattenedAdjustedCanvas: () => HTMLCanvasElement;
  loadSampleProject: (sampleType: 'portrait' | 'landscape' | 'street') => Promise<void>;
  createNewBlankProject: (width?: number, height?: number, name?: string) => void;
}

const StudioContext = createContext<StudioContextType | undefined>(undefined);

export const StudioProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentTab, setCurrentTab] = useState<ScreenTab>('home');
  const [projectName, setProjectName] = useState<string>('Studio Session_01');
  const [canvasWidth, setCanvasWidth] = useState<number>(1080);
  const [canvasHeight, setCanvasHeight] = useState<number>(1350);

  const [layers, setLayers] = useState<Layer[]>([]);
  const [selectedLayerId, setSelectedLayerId] = useState<string | null>(null);

  const [activeTool, setActiveTool] = useState<PhotoshopTool>('brush');
  const [brushSettings, setBrushSettings] = useState<BrushSettings>({
    size: 24,
    hardness: 0.8,
    opacity: 1.0,
    color: '#00d2ff',
  });

  const [adjustments, setAdjustments] = useState<LightroomAdjustments>(DEFAULT_ADJUSTMENTS);
  const [activePresetId, setActivePresetId] = useState<string | null>(null);
  const [customPresets, setCustomPresets] = useState<PresetItem[]>([]);

  const [zoom, setZoom] = useState<number>(1);
  const [pan, setPan] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  const [beforeAfterMode, setBeforeAfterMode] = useState<boolean>(false);
  const [beforeAfterSplit, setBeforeAfterSplit] = useState<number>(50);

  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const [showSplash, setShowSplash] = useState<boolean>(true);
  const triggerSplash = () => setShowSplash(true);

  // Settings
  const [settings, setSettings] = useState<AppSettings>(() => {
    const saved = localStorage.getItem('aron_arik_settings');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {}
    }
    return {
      aiProvider: 'gemini',
      geminiApiKey: '',
      openaiApiKey: '',
      deviceSimMode: false, // Default to full responsive desktop/tablet studio view, with 1-click S21+ toggle
      exportFormat: 'jpeg',
      exportQuality: 0.95,
      autoSaveInterval: 60,
    };
  });

  const updateSettings = (updates: Partial<AppSettings>) => {
    setSettings((prev) => {
      const next = { ...prev, ...updates };
      localStorage.setItem('aron_arik_settings', JSON.stringify(next));
      return next;
    });
  };

  // Undo / Redo history
  const [historyStack, setHistoryStack] = useState<Array<{ layersState: Layer[]; adjustmentsState: LightroomAdjustments }>>([]);
  const [historyPointer, setHistoryPointer] = useState<number>(-1);

  // Helper to clone canvas
  const cloneCanvas = (orig: HTMLCanvasElement): HTMLCanvasElement => {
    const c = document.createElement('canvas');
    c.width = orig.width;
    c.height = orig.height;
    const ctx = c.getContext('2d');
    if (ctx) ctx.drawImage(orig, 0, 0);
    return c;
  };

  const pushHistory = useCallback(() => {
    // Clone layers and their canvases
    const clonedLayers: Layer[] = layers.map((l) => ({
      ...l,
      canvas: cloneCanvas(l.canvas),
    }));

    const newEntry = {
      layersState: clonedLayers,
      adjustmentsState: JSON.parse(JSON.stringify(adjustments)),
    };

    setHistoryStack((prev) => {
      const slice = prev.slice(0, historyPointer + 1);
      return [...slice, newEntry].slice(-25); // retain last 25 states
    });
    setHistoryPointer((prev) => Math.min(prev + 1, 24));
  }, [layers, adjustments, historyPointer]);

  const undo = () => {
    if (historyPointer > 0) {
      const target = historyStack[historyPointer - 1];
      setLayers(
        target.layersState.map((l) => ({
          ...l,
          canvas: cloneCanvas(l.canvas),
        }))
      );
      setAdjustments(JSON.parse(JSON.stringify(target.adjustmentsState)));
      setHistoryPointer(historyPointer - 1);
    }
  };

  const redo = () => {
    if (historyPointer < historyStack.length - 1) {
      const target = historyStack[historyPointer + 1];
      setLayers(
        target.layersState.map((l) => ({
          ...l,
          canvas: cloneCanvas(l.canvas),
        }))
      );
      setAdjustments(JSON.parse(JSON.stringify(target.adjustmentsState)));
      setHistoryPointer(historyPointer + 1);
    }
  };

  const canUndo = historyPointer > 0;
  const canRedo = historyPointer < historyStack.length - 1;

  // Selected layer
  const selectedLayer = layers.find((l) => l.id === selectedLayerId);

  // Layer manipulation
  const addEmptyLayer = (name?: string) => {
    const canvas = document.createElement('canvas');
    canvas.width = canvasWidth;
    canvas.height = canvasHeight;
    const newLayer: Layer = {
      id: `layer_${Date.now()}`,
      name: name || `Layer ${layers.length + 1}`,
      visible: true,
      locked: false,
      opacity: 1,
      blendMode: 'source-over',
      canvas,
      type: 'paint',
      x: 0,
      y: 0,
      width: canvasWidth,
      height: canvasHeight,
    };
    setLayers((prev) => [newLayer, ...prev]);
    setSelectedLayerId(newLayer.id);
  };

  const addImageLayer = (img: HTMLImageElement | HTMLCanvasElement, name?: string) => {
    const canvas = document.createElement('canvas');
    canvas.width = canvasWidth;
    canvas.height = canvasHeight;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      // Draw image scaled to fit canvas proportionally
      const scale = Math.min(canvasWidth / img.width, canvasHeight / img.height);
      const dw = img.width * scale;
      const dh = img.height * scale;
      const dx = (canvasWidth - dw) / 2;
      const dy = (canvasHeight - dh) / 2;
      ctx.drawImage(img, dx, dy, dw, dh);
    }
    const newLayer: Layer = {
      id: `layer_${Date.now()}`,
      name: name || `Layer ${layers.length + 1}`,
      visible: true,
      locked: false,
      opacity: 1,
      blendMode: 'source-over',
      canvas,
      type: 'image',
      x: 0,
      y: 0,
      width: canvasWidth,
      height: canvasHeight,
    };
    setLayers((prev) => [newLayer, ...prev]);
    setSelectedLayerId(newLayer.id);
  };

  const duplicateLayer = (id: string) => {
    const target = layers.find((l) => l.id === id);
    if (!target) return;
    const newLayer: Layer = {
      ...target,
      id: `layer_${Date.now()}`,
      name: `${target.name} copy`,
      canvas: cloneCanvas(target.canvas),
    };
    const idx = layers.findIndex((l) => l.id === id);
    const updated = [...layers];
    updated.splice(idx, 0, newLayer);
    setLayers(updated);
    setSelectedLayerId(newLayer.id);
  };

  const deleteLayer = (id: string) => {
    if (layers.length <= 1) return; // Keep at least one layer
    const nextLayers = layers.filter((l) => l.id !== id);
    setLayers(nextLayers);
    if (selectedLayerId === id) {
      setSelectedLayerId(nextLayers[0]?.id || null);
    }
  };

  const reorderLayers = (startIndex: number, endIndex: number) => {
    const result = Array.from(layers);
    const [removed] = result.splice(startIndex, 1);
    result.splice(endIndex, 0, removed);
    setLayers(result);
  };

  const updateLayer = (id: string, updates: Partial<Layer>) => {
    setLayers((prev) =>
      prev.map((l) => (l.id === id ? { ...l, ...updates } : l))
    );
  };

  // Adjustments
  const updateAdjustment = <K extends keyof LightroomAdjustments>(key: K, value: LightroomAdjustments[K]) => {
    setAdjustments((prev) => ({
      ...prev,
      [key]: value,
    }));
    setActivePresetId(null);
  };

  const resetAdjustments = () => {
    setAdjustments(DEFAULT_ADJUSTMENTS);
    setActivePresetId(null);
  };

  const applyPreset = (preset: PresetItem) => {
    setAdjustments((prev) => ({
      ...prev,
      ...preset.adjustments,
    }));
    setActivePresetId(preset.id);
  };

  const saveCustomPreset = (name: string, category: string = 'User') => {
    const newPreset: PresetItem = {
      id: `user_preset_${Date.now()}`,
      name,
      category,
      adjustments: JSON.parse(JSON.stringify(adjustments)),
    };
    setCustomPresets((prev) => [...prev, newPreset]);
  };

  const resetView = () => {
    setZoom(1);
    setPan({ x: 0, y: 0 });
  };

  // Merge visible layers into one canvas
  const getMergedCanvas = useCallback((): HTMLCanvasElement => {
    const merged = document.createElement('canvas');
    merged.width = canvasWidth;
    merged.height = canvasHeight;
    const ctx = merged.getContext('2d')!;

    // Draw from bottom to top (layers are ordered top-first in array)
    const reversed = [...layers].reverse();
    for (const l of reversed) {
      if (!l.visible) continue;
      ctx.save();
      ctx.globalAlpha = l.opacity;
      ctx.globalCompositeOperation = l.blendMode as GlobalCompositeOperation;
      ctx.drawImage(l.canvas, l.x, l.y, l.width, l.height);
      ctx.restore();
    }
    return merged;
  }, [layers, canvasWidth, canvasHeight]);

  // Flattened + Lightroom adjustments applied
  const getFlattenedAdjustedCanvas = useCallback((): HTMLCanvasElement => {
    const baseMerged = getMergedCanvas();
    const finalCanvas = document.createElement('canvas');
    finalCanvas.width = canvasWidth;
    finalCanvas.height = canvasHeight;
    const finalCtx = finalCanvas.getContext('2d')!;

    const baseCtx = baseMerged.getContext('2d')!;
    applyLightroomAdjustments(baseCtx, finalCtx, canvasWidth, canvasHeight, adjustments);
    return finalCanvas;
  }, [getMergedCanvas, canvasWidth, canvasHeight, adjustments]);

  // Load sample projects
  const loadSampleProject = async (sampleType: 'portrait' | 'landscape' | 'street') => {
    setIsProcessing(true);
    setStatusMessage('Loading high-resolution asset...');
    try {
      let src = ASSETS.samplePortrait;
      let w = 1080;
      let h = 1440;
      let title = 'Studio Portrait Session';

      if (sampleType === 'landscape') {
        src = ASSETS.sampleLandscape;
        w = 1920;
        h = 1080;
        title = 'Alpine Pavilion Dusk';
      } else if (sampleType === 'street') {
        src = ASSETS.sampleStreet;
        w = 1440;
        h = 1080;
        title = 'Metropolis Rain Reflection';
      }

      const img = await loadImage(src);
      setCanvasWidth(w);
      setCanvasHeight(h);
      setProjectName(title);

      const bgCanvas = document.createElement('canvas');
      bgCanvas.width = w;
      bgCanvas.height = h;
      const bgCtx = bgCanvas.getContext('2d')!;
      bgCtx.drawImage(img, 0, 0, w, h);

      const baseLayer: Layer = {
        id: `layer_${Date.now()}`,
        name: 'Background Photo',
        visible: true,
        locked: false,
        opacity: 1,
        blendMode: 'source-over',
        canvas: bgCanvas,
        type: 'image',
        x: 0,
        y: 0,
        width: w,
        height: h,
      };

      setLayers([baseLayer]);
      setSelectedLayerId(baseLayer.id);
      setAdjustments(DEFAULT_ADJUSTMENTS);
      setZoom(1);
      setPan({ x: 0, y: 0 });
    } catch (err) {
      console.error(err);
    } finally {
      setIsProcessing(false);
      setStatusMessage(null);
    }
  };

  const createNewBlankProject = (width: number = 1080, height: number = 1350, name: string = 'Untitled Artboard') => {
    setCanvasWidth(width);
    setCanvasHeight(height);
    setProjectName(name);

    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d')!;
    ctx.fillStyle = '#1e222b';
    ctx.fillRect(0, 0, width, height);

    const baseLayer: Layer = {
      id: `layer_${Date.now()}`,
      name: 'Background Fill',
      visible: true,
      locked: false,
      opacity: 1,
      blendMode: 'source-over',
      canvas,
      type: 'paint',
      x: 0,
      y: 0,
      width,
      height,
    };

    setLayers([baseLayer]);
    setSelectedLayerId(baseLayer.id);
    setAdjustments(DEFAULT_ADJUSTMENTS);
    setZoom(1);
    setPan({ x: 0, y: 0 });
  };

  // Initial load
  useEffect(() => {
    loadSampleProject('portrait');
  }, []);

  return (
    <StudioContext.Provider
      value={{
        currentTab,
        setCurrentTab,
        projectName,
        setProjectName,
        canvasWidth,
        canvasHeight,
        setCanvasDimensions: (w, h) => {
          setCanvasWidth(w);
          setCanvasHeight(h);
        },
        layers,
        selectedLayerId,
        setSelectedLayerId,
        selectedLayer,
        addEmptyLayer,
        addImageLayer,
        duplicateLayer,
        deleteLayer,
        reorderLayers,
        updateLayer,
        activeTool,
        setActiveTool,
        brushSettings,
        setBrushSettings,
        adjustments,
        setAdjustments,
        updateAdjustment,
        resetAdjustments,
        applyPreset,
        activePresetId,
        customPresets,
        saveCustomPreset,
        zoom,
        setZoom,
        pan,
        setPan,
        resetView,
        beforeAfterMode,
        setBeforeAfterMode,
        beforeAfterSplit,
        setBeforeAfterSplit,
        canUndo,
        canRedo,
        undo,
        redo,
        pushHistory,
        settings,
        updateSettings,
        isProcessing,
        setIsProcessing,
        statusMessage,
        setStatusMessage,
        showSplash,
        setShowSplash,
        triggerSplash,
        getMergedCanvas,
        getFlattenedAdjustedCanvas,
        loadSampleProject,
        createNewBlankProject,
      }}
    >
      {children}
    </StudioContext.Provider>
  );
};

export const useStudio = () => {
  const ctx = useContext(StudioContext);
  if (!ctx) throw new Error('useStudio must be used within a StudioProvider');
  return ctx;
};
