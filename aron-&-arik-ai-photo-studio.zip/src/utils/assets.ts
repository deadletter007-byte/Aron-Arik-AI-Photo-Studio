export const ASSETS = {
  logo: '/src/assets/logo/aron_arik_official_logo.jpg',
  samplePortrait: '/src/assets/images/sample_portrait_1793461148053.jpg',
  sampleLandscape: '/src/assets/images/sample_landscape_1793461148516.jpg',
  sampleStreet: '/src/assets/images/sample_street_1793461148774.jpg',
};

// Helper to safely load an Image object
export function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = (err) => {
      console.warn(`Failed loading image: ${src}, falling back to generated canvas.`, err);
      // Generate fallback canvas if image cannot load
      const fallback = document.createElement('canvas');
      fallback.width = 1000;
      fallback.height = 1000;
      const ctx = fallback.getContext('2d');
      if (ctx) {
        ctx.fillStyle = '#181b22';
        ctx.fillRect(0, 0, 1000, 1000);
        ctx.fillStyle = '#00d2ff';
        ctx.font = 'bold 36px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('Aron & Arik Studio', 500, 500);
      }
      const fallbackImg = new Image();
      fallbackImg.src = fallback.toDataURL();
      fallbackImg.onload = () => resolve(fallbackImg);
    };
    img.src = src;
  });
}
