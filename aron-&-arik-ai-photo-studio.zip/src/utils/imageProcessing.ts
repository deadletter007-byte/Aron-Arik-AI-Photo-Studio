import { LightroomAdjustments, PresetItem } from '../types';

export const DEFAULT_ADJUSTMENTS: LightroomAdjustments = {
  exposure: 0,
  brightness: 0,
  contrast: 0,
  highlights: 0,
  shadows: 0,
  whites: 0,
  blacks: 0,
  temperature: 0,
  tint: 0,
  vibrance: 0,
  saturation: 0,
  clarity: 0,
  texture: 0,
  dehaze: 0,
  sharpening: 15,
  noiseReduction: 0,
  vignette: 0,
  grain: 0,
  hsl: {
    red: { h: 0, s: 0, l: 0 },
    orange: { h: 0, s: 0, l: 0 },
    yellow: { h: 0, s: 0, l: 0 },
    green: { h: 0, s: 0, l: 0 },
    cyan: { h: 0, s: 0, l: 0 },
    blue: { h: 0, s: 0, l: 0 },
    purple: { h: 0, s: 0, l: 0 },
    magenta: { h: 0, s: 0, l: 0 },
  },
  curve: [
    { x: 0, y: 0 },
    { x: 64, y: 64 },
    { x: 128, y: 128 },
    { x: 192, y: 192 },
    { x: 255, y: 255 },
  ],
};

export const BUILT_IN_PRESETS: PresetItem[] = [
  {
    id: 'cinematic_teal_orange',
    name: 'Teal & Orange',
    category: 'Cinematic',
    adjustments: {
      exposure: 0.15,
      contrast: 22,
      highlights: -25,
      shadows: 18,
      whites: 10,
      blacks: -15,
      temperature: 12,
      tint: -4,
      vibrance: 25,
      saturation: -5,
      clarity: 15,
      vignette: -18,
      hsl: {
        ...DEFAULT_ADJUSTMENTS.hsl,
        orange: { h: 5, s: 20, l: 5 },
        cyan: { h: -10, s: 30, l: -10 },
        blue: { h: -15, s: 25, l: -15 },
      },
    },
  },
  {
    id: 'moody_dark',
    name: 'Moody Titanium',
    category: 'Dramatic',
    adjustments: {
      exposure: -0.25,
      contrast: 32,
      highlights: -45,
      shadows: -10,
      blacks: -28,
      whites: -15,
      temperature: -8,
      vibrance: -18,
      saturation: -15,
      clarity: 25,
      dehaze: 10,
      vignette: -35,
      grain: 12,
    },
  },
  {
    id: 'portra_film_400',
    name: 'Portra Film 400',
    category: 'Portrait',
    adjustments: {
      exposure: 0.1,
      contrast: 10,
      highlights: -15,
      shadows: 25,
      whites: -5,
      blacks: 12, // lifted blacks for film look
      temperature: 10,
      tint: 4,
      vibrance: 12,
      saturation: 2,
      clarity: -5,
      sharpening: 25,
      grain: 20,
      vignette: -8,
    },
  },
  {
    id: 'clean_commercial_studio',
    name: 'Commercial Studio',
    category: 'Studio',
    adjustments: {
      exposure: 0.2,
      contrast: 14,
      highlights: -10,
      shadows: 12,
      whites: 15,
      blacks: -5,
      temperature: -2,
      tint: 0,
      vibrance: 15,
      saturation: 8,
      clarity: 10,
      sharpening: 35,
    },
  },
  {
    id: 'high_contrast_bw',
    name: 'Fine Art B&W',
    category: 'Monochrome',
    adjustments: {
      exposure: 0.05,
      contrast: 40,
      highlights: -20,
      shadows: 20,
      whites: 25,
      blacks: -35,
      saturation: -100,
      vibrance: -100,
      clarity: 30,
      sharpening: 30,
      grain: 15,
      vignette: -20,
    },
  },
  {
    id: 'hdr_landscape',
    name: 'Vivid HDR',
    category: 'Landscape',
    adjustments: {
      exposure: 0,
      contrast: 18,
      highlights: -60,
      shadows: 50,
      whites: 10,
      blacks: -10,
      temperature: 5,
      tint: 2,
      vibrance: 38,
      saturation: 15,
      clarity: 22,
      dehaze: 15,
      sharpening: 40,
    },
  },
];

// Build 256-entry lookup table for tone curve
export function buildCurveLUT(points: Array<{ x: number; y: number }>): Uint8Array {
  const lut = new Uint8Array(256);
  if (!points || points.length < 2) {
    for (let i = 0; i < 256; i++) lut[i] = i;
    return lut;
  }

  // Sort points by x coordinate
  const sorted = [...points].sort((a, b) => a.x - b.x);

  // Simple monotonic linear / cubic interpolation
  for (let i = 0; i < 256; i++) {
    // Find segment
    let p0 = sorted[0];
    let p1 = sorted[sorted.length - 1];

    for (let j = 0; j < sorted.length - 1; j++) {
      if (i >= sorted[j].x && i <= sorted[j + 1].x) {
        p0 = sorted[j];
        p1 = sorted[j + 1];
        break;
      }
    }

    if (p0.x === p1.x) {
      lut[i] = Math.max(0, Math.min(255, Math.round(p0.y)));
    } else {
      const t = (i - p0.x) / (p1.x - p0.x);
      // Smooth step interpolation
      const smoothT = t * t * (3 - 2 * t);
      const val = p0.y + (p1.y - p0.y) * smoothT;
      lut[i] = Math.max(0, Math.min(255, Math.round(val)));
    }
  }

  return lut;
}

// Convert RGB to HSL
function rgbToHsl(r: number, g: number, b: number): [number, number, number] {
  r /= 255;
  g /= 255;
  b /= 255;
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  let h = 0;
  let s = 0;
  const l = (max + min) / 2;

  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r:
        h = (g - b) / d + (g < b ? 6 : 0);
        break;
      case g:
        h = (b - r) / d + 2;
        break;
      case b:
        h = (r - g) / d + 4;
        break;
    }
    h /= 6;
  }
  return [h * 360, s, l];
}

// Convert HSL back to RGB
function hslToRgb(h: number, s: number, l: number): [number, number, number] {
  h = ((h % 360) + 360) % 360 / 360;
  let r: number, g: number, b: number;

  if (s === 0) {
    r = g = b = l;
  } else {
    const hue2rgb = (p: number, q: number, t: number) => {
      if (t < 0) t += 1;
      if (t > 1) t -= 1;
      if (t < 1 / 6) return p + (q - p) * 6 * t;
      if (t < 1 / 2) return q;
      if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
      return p;
    };

    const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    const p = 2 * l - q;
    r = hue2rgb(p, q, h + 1 / 3);
    g = hue2rgb(p, q, h);
    b = hue2rgb(p, q, h - 1 / 3);
  }

  return [Math.round(r * 255), Math.round(g * 255), Math.round(b * 255)];
}

// Full real-time non-destructive Lightroom adjustment renderer
export function applyLightroomAdjustments(
  sourceCtx: CanvasRenderingContext2D,
  targetCtx: CanvasRenderingContext2D,
  width: number,
  height: number,
  adj: LightroomAdjustments
) {
  const imgData = sourceCtx.getImageData(0, 0, width, height);
  const data = imgData.data;
  const len = data.length;

  const curveLUT = buildCurveLUT(adj.curve);

  // Precompute global multipliers
  const expFactor = Math.pow(2, adj.exposure);
  const contrastFactor = (259 * (adj.contrast + 255)) / (255 * (259 - adj.contrast));
  const brightnessOffset = (adj.brightness / 100) * 128;

  // Temperature (Kelvin shift) & Tint
  const tempShift = adj.temperature; // -100 to 100
  const tintShift = adj.tint; // -100 to 100
  const rTemp = 1 + (tempShift * 0.003);
  const bTemp = 1 - (tempShift * 0.003);
  const gTint = 1 - (tintShift * 0.002);
  const rTint = 1 + (tintShift * 0.001);

  // Vibrance & Saturation
  const satFactor = 1 + adj.saturation / 100;
  const vibWeight = adj.vibrance / 100;

  // Shadows / Highlights recovery coefficients
  const shadowBoost = adj.shadows / 100;
  const highlightSuppression = adj.highlights / 100;
  const whitesBoost = adj.whites / 100;
  const blacksBoost = adj.blacks / 100;

  const centerX = width / 2;
  const centerY = height / 2;
  const maxRadius = Math.sqrt(centerX * centerX + centerY * centerY);
  const vignetteAmount = adj.vignette / 100;
  const grainAmount = adj.grain / 100;

  for (let i = 0; i < len; i += 4) {
    let r = data[i];
    let g = data[i + 1];
    let b = data[i + 2];
    const a = data[i + 3];

    if (a === 0) continue;

    // 1. Exposure
    r *= expFactor;
    g *= expFactor;
    b *= expFactor;

    // 2. Brightness & Contrast
    r = contrastFactor * (r - 128) + 128 + brightnessOffset;
    g = contrastFactor * (g - 128) + 128 + brightnessOffset;
    b = contrastFactor * (b - 128) + 128 + brightnessOffset;

    // 3. Temperature & Tint
    r *= rTemp * rTint;
    g *= gTint;
    b *= bTemp;

    // Luminance estimate
    let lum = 0.2126 * r + 0.7152 * g + 0.0722 * b;

    // 4. Highlights, Shadows, Whites, Blacks recovery
    if (lum < 128 && (shadowBoost !== 0 || blacksBoost !== 0)) {
      // Dark areas
      const shadowWeight = (128 - lum) / 128;
      const boost = (shadowBoost * 0.4 + blacksBoost * 0.3) * shadowWeight * 128;
      r += boost;
      g += boost;
      b += boost;
    } else if (lum >= 128 && (highlightSuppression !== 0 || whitesBoost !== 0)) {
      // Bright areas
      const highWeight = (lum - 128) / 127;
      const suppress = (highlightSuppression * 0.4 + whitesBoost * 0.3) * highWeight * 128;
      r += suppress;
      g += suppress;
      b += suppress;
    }

    // 5. Vibrance & Saturation
    lum = 0.2126 * r + 0.7152 * g + 0.0722 * b;
    const maxVal = Math.max(r, g, b);
    const minVal = Math.min(r, g, b);
    const currentSat = maxVal === 0 ? 0 : (maxVal - minVal) / maxVal;

    // Vibrance affects less-saturated colors more
    const effectiveSat = satFactor + (vibWeight * (1 - currentSat));
    r = lum + (r - lum) * effectiveSat;
    g = lum + (g - lum) * effectiveSat;
    b = lum + (b - lum) * effectiveSat;

    // 6. Tone Curve LUT
    const cr = Math.max(0, Math.min(255, Math.round(r)));
    const cg = Math.max(0, Math.min(255, Math.round(g)));
    const cb = Math.max(0, Math.min(255, Math.round(b)));
    r = curveLUT[cr];
    g = curveLUT[cg];
    b = curveLUT[cb];

    // 7. Vignette
    if (vignetteAmount !== 0) {
      const px = (i / 4) % width;
      const py = Math.floor((i / 4) / width);
      const dx = px - centerX;
      const dy = py - centerY;
      const dist = Math.sqrt(dx * dx + dy * dy) / maxRadius;
      if (dist > 0.3) {
        const factor = 1 + vignetteAmount * Math.pow((dist - 0.3) / 0.7, 1.8);
        r *= factor;
        g *= factor;
        b *= factor;
      }
    }

    // 8. Film Grain
    if (grainAmount > 0) {
      const noise = (Math.random() - 0.5) * grainAmount * 60;
      r += noise;
      g += noise;
      b += noise;
    }

    // Clamp
    data[i] = Math.max(0, Math.min(255, r));
    data[i + 1] = Math.max(0, Math.min(255, g));
    data[i + 2] = Math.max(0, Math.min(255, b));
  }

  // 9. Sharpening & Clarity (Convolution filter pass if requested)
  if (adj.sharpening > 0 || adj.clarity > 0) {
    const sharpness = (adj.sharpening / 100) * 0.8 + (adj.clarity / 100) * 0.4;
    if (sharpness > 0.05) {
      applySharpenPass(data, width, height, sharpness);
    }
  }

  targetCtx.putImageData(imgData, 0, 0);
}

// 3x3 Laplacian sharpening filter
function applySharpenPass(data: Uint8ClampedArray, width: number, height: number, strength: number) {
  const original = new Uint8ClampedArray(data);
  const w = width;
  const h = height;

  for (let y = 1; y < h - 1; y++) {
    for (let x = 1; x < w - 1; x++) {
      const idx = (y * w + x) * 4;

      for (let c = 0; c < 3; c++) {
        const center = original[idx + c];
        const top = original[((y - 1) * w + x) * 4 + c];
        const bottom = original[((y + 1) * w + x) * 4 + c];
        const left = original[(y * w + (x - 1)) * 4 + c];
        const right = original[(y * w + (x + 1)) * 4 + c];

        // Laplacian kernel
        const laplacian = center * 4 - (top + bottom + left + right);
        const sharpened = center + laplacian * (strength * 0.35);

        data[idx + c] = Math.max(0, Math.min(255, Math.round(sharpened)));
      }
    }
  }
}
