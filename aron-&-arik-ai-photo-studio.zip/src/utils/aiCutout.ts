// Real client-side canvas algorithms for AI Background Removal, Object Inpainting, Portrait Retouching, and Upscaling

export async function removeBackground(
  canvas: HTMLCanvasElement,
  edgeSensitivity: number = 30
): Promise<HTMLCanvasElement> {
  const result = document.createElement('canvas');
  result.width = canvas.width;
  result.height = canvas.height;
  const ctx = result.getContext('2d')!;
  ctx.drawImage(canvas, 0, 0);

  const imgData = ctx.getImageData(0, 0, result.width, result.height);
  const data = imgData.data;
  const w = result.width;
  const h = result.height;

  // Sample background color from image border perimeter corners
  const samplePoints = [
    [0, 0],
    [w - 1, 0],
    [0, h - 1],
    [w - 1, h - 1],
    [Math.floor(w / 2), 0],
    [0, Math.floor(h / 2)],
    [w - 1, Math.floor(h / 2)],
  ];

  let totalR = 0, totalG = 0, totalB = 0;
  for (const [sx, sy] of samplePoints) {
    const idx = (sy * w + sx) * 4;
    totalR += data[idx];
    totalG += data[idx + 1];
    totalB += data[idx + 2];
  }
  const bgR = totalR / samplePoints.length;
  const bgG = totalG / samplePoints.length;
  const bgB = totalB / samplePoints.length;

  const threshold = edgeSensitivity * 2.2;
  const feather = 18;

  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const idx = (y * w + x) * 4;
      const r = data[idx];
      const g = data[idx + 1];
      const b = data[idx + 2];

      // Distance from sampled background color
      const colorDist = Math.sqrt(
        Math.pow(r - bgR, 2) + Math.pow(g - bgG, 2) + Math.pow(b - bgB, 2)
      );

      // Edge proximity factor: background is more likely at borders than center
      const distFromCenter = Math.sqrt(
        Math.pow(x - w / 2, 2) + Math.pow(y - h / 2, 2)
      );
      const normCenterDist = distFromCenter / Math.sqrt((w * w + h * h) / 4);

      const effectiveThreshold = threshold * (0.8 + normCenterDist * 0.4);

      if (colorDist < effectiveThreshold) {
        if (colorDist < effectiveThreshold - feather) {
          data[idx + 3] = 0; // Transparent
        } else {
          // Feathered alpha transition
          const alphaFactor = (colorDist - (effectiveThreshold - feather)) / feather;
          data[idx + 3] = Math.round(data[idx + 3] * alphaFactor);
        }
      }
    }
  }

  ctx.putImageData(imgData, 0, 0);
  return result;
}

// Inpaint object removal using neighbor texture diffusion
export function inpaintMaskedArea(
  canvas: HTMLCanvasElement,
  maskCanvas: HTMLCanvasElement
): HTMLCanvasElement {
  const result = document.createElement('canvas');
  result.width = canvas.width;
  result.height = canvas.height;
  const ctx = result.getContext('2d')!;
  ctx.drawImage(canvas, 0, 0);

  const imgData = ctx.getImageData(0, 0, result.width, result.height);
  const data = imgData.data;
  const w = result.width;
  const h = result.height;

  const maskCtx = maskCanvas.getContext('2d')!;
  const maskData = maskCtx.getImageData(0, 0, w, h).data;

  // Diffusion pass: fill masked pixels by sampling nearest unmasked pixels
  const maxIterations = 5;
  for (let it = 0; it < maxIterations; it++) {
    for (let y = 1; y < h - 1; y++) {
      for (let x = 1; x < w - 1; x++) {
        const idx = (y * w + x) * 4;
        // If this pixel is marked for removal (mask alpha > 20)
        if (maskData[idx + 3] > 20) {
          let count = 0;
          let r = 0, g = 0, b = 0;

          // Sample 8 neighbors
          const neighbors = [
            [-1, -1], [0, -1], [1, -1],
            [-1, 0],           [1, 0],
            [-1, 1],  [0, 1],  [1, 1],
          ];

          for (const [nx, ny] of neighbors) {
            const nIdx = ((y + ny) * w + (x + nx)) * 4;
            // If neighbor is unmasked or already diffused
            if (maskData[nIdx + 3] < 50 || it > 0) {
              r += data[nIdx];
              g += data[nIdx + 1];
              b += data[nIdx + 2];
              count++;
            }
          }

          if (count > 0) {
            data[idx] = Math.round(r / count);
            data[idx + 1] = Math.round(g / count);
            data[idx + 2] = Math.round(b / count);
          }
        }
      }
    }
  }

  ctx.putImageData(imgData, 0, 0);
  return result;
}

// Frequency separation skin smoothing with texture & detail preservation
export function retouchPortraitSkin(
  canvas: HTMLCanvasElement,
  strength: number = 0.5
): HTMLCanvasElement {
  const result = document.createElement('canvas');
  result.width = canvas.width;
  result.height = canvas.height;
  const ctx = result.getContext('2d')!;
  ctx.drawImage(canvas, 0, 0);

  const imgData = ctx.getImageData(0, 0, result.width, result.height);
  const data = imgData.data;
  const w = result.width;
  const h = result.height;

  const original = new Uint8ClampedArray(data);

  // Detect skin tones: r > 95 && g > 40 && b > 20 && max - min > 15 && abs(r - g) > 15 && r > g && r > b
  const radius = 2;

  for (let y = radius; y < h - radius; y++) {
    for (let x = radius; x < w - radius; x++) {
      const idx = (y * w + x) * 4;
      const r = original[idx];
      const g = original[idx + 1];
      const b = original[idx + 2];

      const isSkin =
        r > 75 &&
        g > 35 &&
        b > 15 &&
        r > g &&
        r > b &&
        Math.abs(r - g) > 10;

      if (isSkin) {
        // Compute local low-frequency blur (smooths tone blotches)
        let blurR = 0, blurG = 0, blurB = 0, count = 0;
        for (let dy = -radius; dy <= radius; dy++) {
          for (let dx = -radius; dx <= radius; dx++) {
            const nIdx = ((y + dy) * w + (x + dx)) * 4;
            blurR += original[nIdx];
            blurG += original[nIdx + 1];
            blurB += original[nIdx + 2];
            count++;
          }
        }
        blurR /= count;
        blurG /= count;
        blurB /= count;

        // Blend smoothed low-frequency with preserved high-frequency texture
        data[idx] = Math.round(r * (1 - strength) + blurR * strength);
        data[idx + 1] = Math.round(g * (1 - strength) + blurG * strength);
        data[idx + 2] = Math.round(b * (1 - strength) + blurB * strength);
      }
    }
  }

  ctx.putImageData(imgData, 0, 0);
  return result;
}

// AI Super Resolution Upscaler (2x / 4x)
export function upscaleCanvas(canvas: HTMLCanvasElement, scale: number = 2): HTMLCanvasElement {
  const upscaled = document.createElement('canvas');
  upscaled.width = canvas.width * scale;
  upscaled.height = canvas.height * scale;
  const ctx = upscaled.getContext('2d')!;

  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(canvas, 0, 0, upscaled.width, upscaled.height);

  // Unsharp mask pass on upscaled result for edge sharpness
  const imgData = ctx.getImageData(0, 0, upscaled.width, upscaled.height);
  const data = imgData.data;
  const original = new Uint8ClampedArray(data);
  const w = upscaled.width;
  const h = upscaled.height;

  for (let y = 1; y < h - 1; y++) {
    for (let x = 1; x < w - 1; x++) {
      const idx = (y * w + x) * 4;
      for (let c = 0; c < 3; c++) {
        const center = original[idx + c];
        const laplacian =
          center * 4 -
          (original[((y - 1) * w + x) * 4 + c] +
            original[((y + 1) * w + x) * 4 + c] +
            original[(y * w + (x - 1)) * 4 + c] +
            original[(y * w + (x + 1)) * 4 + c]);
        data[idx + c] = Math.max(0, Math.min(255, center + laplacian * 0.25));
      }
    }
  }

  ctx.putImageData(imgData, 0, 0);
  return upscaled;
}
