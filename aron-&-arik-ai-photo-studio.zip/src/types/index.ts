export type ScreenTab =
  | 'home'
  | 'assistant'
  | 'photoshop'
  | 'lightroom'
  | 'express'
  | 'aitools'
  | 'projects'
  | 'settings';

export type BlendMode =
  | 'source-over'
  | 'multiply'
  | 'screen'
  | 'overlay'
  | 'darken'
  | 'lighten'
  | 'color-dodge'
  | 'color-burn'
  | 'hard-light'
  | 'soft-light'
  | 'difference'
  | 'exclusion';

export interface Layer {
  id: string;
  name: string;
  visible: boolean;
  locked: boolean;
  opacity: number; // 0 to 1
  blendMode: BlendMode;
  canvas: HTMLCanvasElement;
  type: 'image' | 'paint' | 'text' | 'shape' | 'adjustment';
  x: number;
  y: number;
  width: number;
  height: number;
  textContent?: string;
  textStyle?: {
    fontFamily: string;
    fontSize: number;
    color: string;
    bold: boolean;
    italic: boolean;
    letterSpacing?: number;
  };
}

export interface LightroomAdjustments {
  // Basic
  exposure: number;     // -2.0 to 2.0 (EV)
  brightness: number;   // -100 to 100
  contrast: number;     // -100 to 100
  highlights: number;   // -100 to 100
  shadows: number;      // -100 to 100
  whites: number;       // -100 to 100
  blacks: number;       // -100 to 100
  temperature: number;  // -100 (cool) to 100 (warm)
  tint: number;         // -100 (green) to 100 (magenta)
  vibrance: number;     // -100 to 100
  saturation: number;   // -100 to 100

  // Detail & Presence
  clarity: number;      // 0 to 100
  texture: number;      // 0 to 100
  dehaze: number;       // -50 to 50
  sharpening: number;   // 0 to 100
  noiseReduction: number; // 0 to 100
  vignette: number;     // -100 (dark) to 100 (light)
  grain: number;        // 0 to 100

  // HSL Mixer (Hue, Saturation, Luminance shifts)
  hsl: {
    red: { h: number; s: number; l: number };
    orange: { h: number; s: number; l: number };
    yellow: { h: number; s: number; l: number };
    green: { h: number; s: number; l: number };
    cyan: { h: number; s: number; l: number };
    blue: { h: number; s: number; l: number };
    purple: { h: number; s: number; l: number };
    magenta: { h: number; s: number; l: number };
  };

  // Tone Curve (points: [x, y] in 0-255)
  curve: Array<{ x: number; y: number }>;
}

export type PhotoshopTool =
  | 'move'
  | 'brush'
  | 'eraser'
  | 'clone_stamp'
  | 'healing_brush'
  | 'dodge'
  | 'burn'
  | 'blur'
  | 'sharpen'
  | 'marquee_rect'
  | 'marquee_ellipse'
  | 'lasso'
  | 'crop'
  | 'eyedropper'
  | 'bucket'
  | 'gradient'
  | 'text'
  | 'shape';

export interface BrushSettings {
  size: number;
  hardness: number; // 0 to 1
  opacity: number;  // 0 to 1
  color: string;
}

export interface ProjectMetadata {
  id: string;
  name: string;
  width: number;
  height: number;
  createdAt: number;
  updatedAt: number;
  thumbnailUrl?: string;
  layerCount: number;
}

export interface PresetItem {
  id: string;
  name: string;
  category: string;
  adjustments: Partial<LightroomAdjustments>;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
  imageUrl?: string;
  suggestedAdjustments?: Partial<LightroomAdjustments>;
  actionType?: 'apply_adjustments' | 'remove_bg' | 'enhance_portrait';
}

export type AiProvider = 'gemini' | 'openai';

export interface AppSettings {
  aiProvider: AiProvider;
  geminiApiKey: string;
  openaiApiKey: string;
  deviceSimMode: boolean; // true = S21+ frame, false = Full Studio Pro
  exportFormat: 'png' | 'jpeg' | 'webp';
  exportQuality: number; // 0.1 to 1.0
  autoSaveInterval: number; // seconds
}
