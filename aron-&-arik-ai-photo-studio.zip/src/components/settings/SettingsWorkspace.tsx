import React, { useState } from 'react';
import { useStudio } from '../../context/StudioContext';
import { ASSETS } from '../../utils/assets';
import {
  Settings,
  Key,
  Shield,
  Smartphone,
  HardDrive,
  Info,
  Check,
  AlertCircle,
  Code,
  Download,
  Copy,
  Cpu,
  RefreshCw,
  Image as ImageIcon,
  Sparkles,
} from 'lucide-react';

export const SettingsWorkspace: React.FC = () => {
  const { settings, updateSettings, triggerSplash } = useStudio();

  const [geminiKeyInput, setGeminiKeyInput] = useState(settings.geminiApiKey || '');
  const [openaiKeyInput, setOpenaiKeyInput] = useState(settings.openaiApiKey || '');
  const [testResult, setTestResult] = useState<{ status: 'idle' | 'testing' | 'success' | 'error'; message?: string }>({
    status: 'idle',
  });
  const [activeCodeFile, setActiveCodeFile] = useState<'AdaptiveIcon' | 'SplashScreenKt' | 'MainActivity' | 'FilterPipeline' | 'LayerEngine' | 'BuildGradle'>('AdaptiveIcon');
  const [copiedCode, setCopiedCode] = useState(false);

  const handleSaveKeys = () => {
    updateSettings({
      geminiApiKey: geminiKeyInput.trim(),
      openaiApiKey: openaiKeyInput.trim(),
    });
    setTestResult({ status: 'success', message: 'API keys saved securely to local studio storage.' });
    setTimeout(() => setTestResult({ status: 'idle' }), 3000);
  };

  const handleTestGemini = async () => {
    setTestResult({ status: 'testing' });
    try {
      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: 'Ping. Confirm connection with Aron & Arik AI Photo Studio.',
          customApiKey: geminiKeyInput.trim() || undefined,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Connection failed.');
      setTestResult({
        status: 'success',
        message: 'Connected to Gemini 3.8 Flash Vision model successfully.',
      });
    } catch (e: any) {
      setTestResult({
        status: 'error',
        message: e.message || 'Could not connect to Gemini API.',
      });
    }
  };

  const kotlinCodeSnippets: Record<string, { filename: string; code: string }> = {
    AdaptiveIcon: {
      filename: 'mipmap-anydpi-v26/ic_launcher.xml',
      code: `<?xml version="1.0" encoding="utf-8"?>
<!-- Android 8.0 through Android 15 Adaptive Icon -->
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <!-- Premium Matte Black Background (#0D0F12) -->
    <background android:drawable="@drawable/ic_launcher_background" />
    <!-- Authentic 3D AI Microchip Foreground Logo -->
    <foreground android:drawable="@drawable/ic_launcher_foreground" />
</adaptive-icon>`,
    },
    SplashScreenKt: {
      filename: 'ui/screens/SplashScreen.kt',
      code: `package com.aronarik.photostudio.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aronarik.photostudio.R

@Composable
fun AndroidSplashScreen(onTimeout: () -> Unit) {
    // Premium Matte Black Canvas (#0A0C0F)
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0C0F)),
        contentAlignment = Alignment.Center
    ) {
        // Beautifully centered authentic 3D AI Microchip Logo
        Image(
            painter = painterResource(id = R.drawable.ic_launcher),
            contentDescription = "Aron & Arik Official Brand Logo",
            contentScale = ContentScale.Fit,
            modifier = Modifier.size(180.dp)
        )
    }
}`,
    },
    MainActivity: {
      filename: 'MainActivity.kt',
      code: `package com.aronarik.photostudio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.aronarik.photostudio.ui.navigation.AronArikNavGraph
import com.aronarik.photostudio.ui.theme.AronArikStudioTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Optimized for Samsung Galaxy S21+ (SM-G996U) One UI 7 & Android 15
        setContent {
            AronArikStudioTheme(darkTheme = true) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AronArikNavGraph()
                }
            }
        }
    }
}`,
    },
    FilterPipeline: {
      filename: 'FilterPipeline.kt',
      code: `package com.aronarik.photostudio.engine

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.pow

data class AdjustmentsState(
    val exposure: Float = 0f,
    val contrast: Float = 0f,
    val highlights: Float = 0f,
    val shadows: Float = 0f,
    val temperature: Float = 0f,
    val tint: Float = 0f,
    val vibrance: Float = 0f,
    val saturation: Float = 0f
)

class FilterPipeline {
    /**
     * Non-destructive GPU/Bitmap pixel transformation engine
     * Optimized for Snapdragon 888 on Samsung Galaxy S21+
     */
    fun processBitmap(source: Bitmap, adjustments: AdjustmentsState): Bitmap {
        val width = source.width
        val height = source.height
        val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val pixels = IntArray(width * height)
        source.getPixels(pixels, 0, width, 0, 0, width, height)

        val expFactor = 2.0.pow(adjustments.exposure.toDouble()).toFloat()
        val contrastFactor = (259f * (adjustments.contrast + 255f)) / (255f * (259f - adjustments.contrast))

        for (i in pixels.indices) {
            val color = pixels[i]
            var r = (Color.red(color) * expFactor)
            var g = (Color.green(color) * expFactor)
            var b = (Color.blue(color) * expFactor)

            r = contrastFactor * (r - 128f) + 128f
            g = contrastFactor * (g - 128f) + 128f
            b = contrastFactor * (b - 128f) + 128f

            pixels[i] = Color.argb(
                Color.alpha(color),
                r.toInt().coerceIn(0, 255),
                g.toInt().coerceIn(0, 255),
                b.toInt().coerceIn(0, 255)
            )
        }

        output.setPixels(pixels, 0, width, 0, 0, width, height)
        return output
    }
}`,
    },
    LayerEngine: {
      filename: 'LayerEngine.kt',
      code: `package com.aronarik.photostudio.engine

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode

enum class BlendModeType {
    NORMAL, MULTIPLY, SCREEN, OVERLAY, DARKEN, LIGHTEN
}

data class StudioLayer(
    val id: String,
    val name: String,
    var bitmap: Bitmap,
    var visible: Boolean = true,
    var locked: Boolean = false,
    var opacity: Float = 1.0f,
    var blendMode: BlendModeType = BlendModeType.NORMAL
)

class LayerEngine(private val canvasWidth: Int, private val canvasHeight: Int) {
    private val layers = mutableListOf<StudioLayer>()

    fun composite(): Bitmap {
        val compositeBitmap = Bitmap.createBitmap(canvasWidth, canvasHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(compositeBitmap)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        layers.filter { it.visible }.reversed().forEach { layer ->
            paint.alpha = (layer.opacity * 255).toInt()
            paint.xfermode = when (layer.blendMode) {
                BlendModeType.MULTIPLY -> PorterDuffXfermode(PorterDuff.Mode.MULTIPLY)
                BlendModeType.SCREEN -> PorterDuffXfermode(PorterDuff.Mode.SCREEN)
                BlendModeType.OVERLAY -> PorterDuffXfermode(PorterDuff.Mode.OVERLAY)
                BlendModeType.DARKEN -> PorterDuffXfermode(PorterDuff.Mode.DARKEN)
                BlendModeType.LIGHTEN -> PorterDuffXfermode(PorterDuff.Mode.LIGHTEN)
                else -> PorterDuffXfermode(PorterDuff.Mode.SRC_OVER)
            }
            canvas.drawBitmap(layer.bitmap, 0f, 0f, paint)
        }
        return compositeBitmap
    }
}`,
    },
    BuildGradle: {
      filename: 'build.gradle.kts (app)',
      code: `plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
}

android {
    namespace = "com.aronarik.photostudio"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.aronarik.photostudio"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
}

dependencies {
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.material3)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.navigation.compose)
    implementation("io.coil-kt:coil-compose:2.7.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
}`,
    },
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  return (
    <div className="flex-1 overflow-y-auto bg-[#0d0f12] p-4 sm:p-6 lg:p-8">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="pb-4 border-b border-[#20252e]">
          <h2 className="text-xl font-bold text-white tracking-tight">Studio Settings &amp; Engine</h2>
          <p className="text-xs text-slate-400 mt-1">
            Configure AI model providers, secure API credentials, Samsung Galaxy S21+ optimizations, and inspect native Android source code.
          </p>
        </div>

        {/* AI Provider & API Keys */}
        <div className="p-5 rounded-2xl bg-[#13161c] border border-[#20252e] space-y-4">
          <div className="flex items-center gap-2.5">
            <Key className="w-4 h-4 text-[#00d2ff]" />
            <h3 className="text-sm font-bold text-white">AI Provider Keys</h3>
          </div>
          <p className="text-xs text-slate-400 leading-relaxed">
            Aron &amp; Arik AI Photo Studio runs on server-side Gemini 3.8 Flash automatically. You can also specify your own custom Gemini or OpenAI API keys securely in local browser storage.
          </p>

          <div className="space-y-3">
            <div>
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="text-slate-300 font-medium">Custom Gemini API Key</span>
                <span className="text-[10px] font-mono text-emerald-400">Environment Active (Default)</span>
              </div>
              <input
                type="password"
                placeholder="AIzaSy... (leave blank to use system key)"
                value={geminiKeyInput}
                onChange={(e) => setGeminiKeyInput(e.target.value)}
                className="w-full px-3 py-2 bg-[#0e1014] border border-[#262c37] rounded-xl text-xs text-white placeholder-slate-600 outline-none focus:border-[#00d2ff] font-mono"
              />
            </div>

            <div>
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="text-slate-300 font-medium">OpenAI API Key (for ChatGPT Provider)</span>
                <span className="text-[10px] font-mono text-slate-500">Optional</span>
              </div>
              <input
                type="password"
                placeholder="sk-proj-... (needed for ChatGPT provider mode)"
                value={openaiKeyInput}
                onChange={(e) => setOpenaiKeyInput(e.target.value)}
                className="w-full px-3 py-2 bg-[#0e1014] border border-[#262c37] rounded-xl text-xs text-white placeholder-slate-600 outline-none focus:border-[#00d2ff] font-mono"
              />
            </div>
          </div>

          <div className="flex items-center justify-between pt-2">
            <button
              onClick={handleTestGemini}
              disabled={testResult.status === 'testing'}
              className="px-3 py-1.5 rounded-lg bg-[#1a1f28] border border-[#282f3c] hover:border-[#00d2ff] text-slate-300 hover:text-white text-xs font-mono flex items-center gap-1.5 transition-colors"
            >
              {testResult.status === 'testing' ? (
                <RefreshCw className="w-3.5 h-3.5 animate-spin text-[#00d2ff]" />
              ) : (
                <Cpu className="w-3.5 h-3.5 text-[#00d2ff]" />
              )}
              <span>Test Connection</span>
            </button>

            <button
              onClick={handleSaveKeys}
              className="px-4 py-1.5 rounded-lg bg-[#00d2ff] hover:bg-[#38dcff] text-black text-xs font-bold transition-all shadow-sm"
            >
              Save Credentials
            </button>
          </div>

          {testResult.status !== 'idle' && (
            <div
              className={`p-3 rounded-xl border text-xs font-mono flex items-center gap-2 ${
                testResult.status === 'success'
                  ? 'bg-emerald-950/40 border-emerald-800/60 text-emerald-300'
                  : testResult.status === 'error'
                  ? 'bg-rose-950/40 border-rose-800/60 text-rose-300'
                  : 'bg-[#181c24] border-[#2b313d] text-slate-300'
              }`}
            >
              {testResult.status === 'success' && <Check className="w-4 h-4 text-emerald-400" />}
              {testResult.status === 'error' && <AlertCircle className="w-4 h-4 text-rose-400" />}
              <span>{testResult.message}</span>
            </div>
          )}
        </div>

        {/* Official Brand Identity & Android App Icon */}
        <div className="p-5 rounded-2xl bg-[#13161c] border border-[#20252e] space-y-4">
          <div className="flex items-center gap-2.5">
            <ImageIcon className="w-4 h-4 text-[#00d2ff]" />
            <h3 className="text-sm font-bold text-white">Official Brand Identity &amp; App Icon</h3>
          </div>
          <div className="flex flex-col sm:flex-row items-center gap-4 p-4 rounded-xl bg-[#0e1014] border border-[#222732]">
            <div className="w-24 h-24 aspect-square rounded-2xl overflow-hidden bg-[#0d0f12] border border-[#2c3340] shadow-xl shrink-0 p-1 flex items-center justify-center ring-1 ring-white/10">
              <img
                src={ASSETS.logo}
                alt="Aron &amp; Arik Official App Icon"
                className="w-full h-full object-contain"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="space-y-1 text-center sm:text-left">
              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
                <span className="text-sm font-bold text-white">Aron &amp; Arik 3D AI Logo</span>
                <span className="text-[10px] font-mono text-[#00d2ff] bg-[#00d2ff]/10 border border-[#00d2ff]/30 px-2 py-0.5 rounded">
                  AUTHENTIC USER ASSET
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Design, color, shape, text, and aspect ratio preserved 100% without alteration.
              </p>
              <div className="pt-2 flex flex-wrap items-center gap-2 justify-center sm:justify-start">
                <span className="bg-[#181c24] px-2 py-0.5 rounded text-[10px] font-mono text-slate-400">Home Screen Header</span>
                <span className="bg-[#181c24] px-2 py-0.5 rounded text-[10px] font-mono text-slate-400">Splash Screen</span>
                <span className="bg-[#181c24] px-2 py-0.5 rounded text-[10px] font-mono text-slate-400">Android App Icon (ic_launcher)</span>
                <button
                  onClick={triggerSplash}
                  className="px-3 py-1 rounded-lg bg-[#00d2ff]/15 hover:bg-[#00d2ff]/25 border border-[#00d2ff]/40 text-[#00d2ff] text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Preview Splash Screen</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Hardware & Target Profile */}
        <div className="p-5 rounded-2xl bg-[#13161c] border border-[#20252e] space-y-3">
          <div className="flex items-center gap-2.5">
            <Smartphone className="w-4 h-4 text-[#00d2ff]" />
            <h3 className="text-sm font-bold text-white">Target Device Profile</h3>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
            <div className="p-3 bg-[#0e1014] rounded-xl border border-[#20252e]">
              <span className="text-[10px] font-mono text-slate-500">HARDWARE MODEL</span>
              <p className="font-bold text-white mt-0.5">SM-G996U</p>
              <p className="text-[10px] text-slate-400">Galaxy S21+ 5G</p>
            </div>
            <div className="p-3 bg-[#0e1014] rounded-xl border border-[#20252e]">
              <span className="text-[10px] font-mono text-slate-500">OS PLATFORM</span>
              <p className="font-bold text-white mt-0.5">Android 15</p>
              <p className="text-[10px] text-slate-400">API Level 35</p>
            </div>
            <div className="p-3 bg-[#0e1014] rounded-xl border border-[#20252e]">
              <span className="text-[10px] font-mono text-slate-500">USER INTERFACE</span>
              <p className="font-bold text-white mt-0.5">One UI 7</p>
              <p className="text-[10px] text-slate-400">Samsung Custom</p>
            </div>
            <div className="p-3 bg-[#0e1014] rounded-xl border border-[#20252e]">
              <span className="text-[10px] font-mono text-slate-500">RENDER CANVAS</span>
              <p className="font-bold text-[#00d2ff] mt-0.5">20:9 AMOLED</p>
              <p className="text-[10px] text-slate-400">1080 × 2400</p>
            </div>
          </div>
        </div>

        {/* Native Android Studio Kotlin Project Inspector */}
        <div className="p-5 rounded-2xl bg-[#13161c] border border-[#20252e] space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Code className="w-4 h-4 text-[#00d2ff]" />
              <div>
                <h3 className="text-sm font-bold text-white">Native Android Studio Source Files</h3>
                <p className="text-xs text-slate-400">Jetpack Compose UI &amp; Native Image Engine</p>
              </div>
            </div>

            <button
              onClick={() => copyToClipboard(kotlinCodeSnippets[activeCodeFile].code)}
              className="px-3 py-1.5 rounded-lg bg-[#1a1f28] border border-[#282f3c] hover:border-[#00d2ff] text-xs font-mono text-slate-300 hover:text-white flex items-center gap-1.5 transition-colors"
            >
              {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedCode ? 'Copied' : 'Copy Code'}</span>
            </button>
          </div>

          {/* File Tabs */}
          <div className="flex items-center gap-2 border-b border-[#20252e] pb-2 text-xs font-mono overflow-x-auto">
            {Object.keys(kotlinCodeSnippets).map((key) => (
              <button
                key={key}
                onClick={() => setActiveCodeFile(key as any)}
                className={`px-3 py-1 rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  activeCodeFile === key
                    ? 'bg-[#1e2430] text-[#00d2ff] font-semibold border border-[#00d2ff]/40'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {kotlinCodeSnippets[key].filename}
              </button>
            ))}
          </div>

          {/* Code Viewer */}
          <pre className="p-4 rounded-xl bg-[#0a0c0f] border border-[#20252e] text-xs font-mono text-slate-300 overflow-x-auto leading-relaxed max-h-80">
            <code>{kotlinCodeSnippets[activeCodeFile].code}</code>
          </pre>
        </div>
      </div>
    </div>
  );
};
