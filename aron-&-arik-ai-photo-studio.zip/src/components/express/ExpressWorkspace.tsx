import React, { useState } from 'react';
import { useStudio } from '../../context/StudioContext';
import { StudioCanvas } from '../canvas/StudioCanvas';
import {
  Palette,
  Type,
  Shapes,
  LayoutTemplate,
  Sparkles,
  Smartphone,
  Tv,
  Instagram,
  Youtube,
  Image as ImageIcon,
} from 'lucide-react';

export const ExpressWorkspace: React.FC = () => {
  const {
    canvasWidth,
    canvasHeight,
    setCanvasDimensions,
    addEmptyLayer,
    layers,
    selectedLayerId,
    updateLayer,
    pushHistory,
  } = useStudio();

  const [activeToolTab, setActiveToolTab] = useState<'presets' | 'text' | 'shapes'>('presets');

  const canvasPresets = [
    { label: 'Instagram Square', w: 1080, h: 1080, ratio: '1:1', icon: <Instagram className="w-3.5 h-3.5" /> },
    { label: 'Instagram Portrait', w: 1080, h: 1350, ratio: '4:5', icon: <Instagram className="w-3.5 h-3.5" /> },
    { label: 'Story / TikTok', w: 1080, h: 1920, ratio: '9:16', icon: <Smartphone className="w-3.5 h-3.5" /> },
    { label: 'YouTube Thumbnail', w: 1280, h: 720, ratio: '16:9', icon: <Youtube className="w-3.5 h-3.5" /> },
    { label: 'Poster 2:3', w: 1200, h: 1800, ratio: '2:3', icon: <ImageIcon className="w-3.5 h-3.5" /> },
  ];

  // Helper to add text element to canvas
  const handleAddText = (text: string, style: 'headline' | 'subhead' | 'cyber' | 'accent') => {
    const canvas = document.createElement('canvas');
    canvas.width = canvasWidth;
    canvas.height = canvasHeight;
    const ctx = canvas.getContext('2d')!;

    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    if (style === 'headline') {
      ctx.font = '800 64px "Plus Jakarta Sans", sans-serif';
      ctx.fillStyle = '#ffffff';
      ctx.shadowColor = 'rgba(0,0,0,0.8)';
      ctx.shadowBlur = 12;
      ctx.fillText(text, canvasWidth / 2, canvasHeight / 2);
    } else if (style === 'cyber') {
      ctx.font = '700 52px "JetBrains Mono", monospace';
      ctx.fillStyle = '#00d2ff';
      ctx.shadowColor = 'rgba(0,210,255,0.6)';
      ctx.shadowBlur = 16;
      ctx.fillText(text, canvasWidth / 2, canvasHeight / 2);
    } else if (style === 'subhead') {
      ctx.font = '500 32px "Plus Jakarta Sans", sans-serif';
      ctx.fillStyle = '#e2e8f0';
      ctx.fillText(text, canvasWidth / 2, canvasHeight / 2);
    } else {
      ctx.font = '600 24px "JetBrains Mono", monospace';
      ctx.fillStyle = '#94a3b8';
      ctx.fillText(text, canvasWidth / 2, canvasHeight / 2);
    }

    addEmptyLayer(`Text: ${text}`);
    // Find newly added layer and write text onto its canvas
    setTimeout(() => {
      const target = layers[0];
      if (target) {
        const tCtx = target.canvas.getContext('2d');
        if (tCtx) tCtx.drawImage(canvas, 0, 0);
        pushHistory();
      }
    }, 50);
  };

  // Helper to add geometric shape
  const handleAddShape = (type: 'badge' | 'frame' | 'divider') => {
    const canvas = document.createElement('canvas');
    canvas.width = canvasWidth;
    canvas.height = canvasHeight;
    const ctx = canvas.getContext('2d')!;

    if (type === 'badge') {
      ctx.fillStyle = 'rgba(0, 210, 255, 0.2)';
      ctx.strokeStyle = '#00d2ff';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.roundRect(canvasWidth / 2 - 140, canvasHeight / 2 - 40, 280, 80, 20);
      ctx.fill();
      ctx.stroke();

      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 24px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('EXCLUSIVE EDITION', canvasWidth / 2, canvasHeight / 2);
    } else if (type === 'frame') {
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.4)';
      ctx.lineWidth = 4;
      ctx.strokeRect(60, 60, canvasWidth - 120, canvasHeight - 120);
    } else if (type === 'divider') {
      ctx.strokeStyle = '#00d2ff';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(canvasWidth / 4, canvasHeight / 2);
      ctx.lineTo((canvasWidth * 3) / 4, canvasHeight / 2);
      ctx.stroke();
    }

    addEmptyLayer(`Shape: ${type}`);
    setTimeout(() => {
      const target = layers[0];
      if (target) {
        const tCtx = target.canvas.getContext('2d');
        if (tCtx) tCtx.drawImage(canvas, 0, 0);
        pushHistory();
      }
    }, 50);
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-[#0d0f12] overflow-hidden">
      {/* Top Bar */}
      <div className="h-10 px-4 bg-[#121418] border-b border-[#20252e] flex items-center justify-between text-xs text-slate-300 shrink-0">
        <div className="flex items-center gap-2">
          <Palette className="w-3.5 h-3.5 text-[#00d2ff]" />
          <span className="font-semibold text-white font-mono text-[11px]">ADOBE EXPRESS DESIGN STUDIO</span>
        </div>

        <div className="flex items-center gap-2 font-mono text-[11px] text-slate-400">
          <span>Dimensions:</span>
          <span className="text-[#00d2ff]">{canvasWidth} × {canvasHeight}px</span>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* Left Elements Sidebar */}
        <div className="w-72 bg-[#121418] border-r border-[#20252e] flex flex-col shrink-0">
          {/* Tabs */}
          <div className="flex items-center border-b border-[#20252e] bg-[#0e1014] text-[11px]">
            <button
              onClick={() => setActiveToolTab('presets')}
              className={`flex-1 py-2 text-center font-medium border-b-2 transition-colors ${
                activeToolTab === 'presets'
                  ? 'border-[#00d2ff] text-[#00d2ff] bg-[#14171d]'
                  : 'border-transparent text-slate-400 hover:text-white'
              }`}
            >
              Canvas Presets
            </button>
            <button
              onClick={() => setActiveToolTab('text')}
              className={`flex-1 py-2 text-center font-medium border-b-2 transition-colors ${
                activeToolTab === 'text'
                  ? 'border-[#00d2ff] text-[#00d2ff] bg-[#14171d]'
                  : 'border-transparent text-slate-400 hover:text-white'
              }`}
            >
              Typography
            </button>
            <button
              onClick={() => setActiveToolTab('shapes')}
              className={`flex-1 py-2 text-center font-medium border-b-2 transition-colors ${
                activeToolTab === 'shapes'
                  ? 'border-[#00d2ff] text-[#00d2ff] bg-[#14171d]'
                  : 'border-transparent text-slate-400 hover:text-white'
              }`}
            >
              Shapes &amp; Badges
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {activeToolTab === 'presets' && (
              <div className="space-y-3">
                <p className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">Social Media Formats</p>
                {canvasPresets.map((preset) => (
                  <button
                    key={preset.label}
                    onClick={() => setCanvasDimensions(preset.w, preset.h)}
                    className="w-full flex items-center justify-between p-2.5 rounded-xl bg-[#161920] border border-[#222732] hover:border-[#00d2ff]/60 hover:bg-[#1a1f28] transition-colors text-left"
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="p-1.5 rounded-lg bg-[#20252e] text-[#00d2ff]">
                        {preset.icon}
                      </div>
                      <div>
                        <p className="text-xs font-semibold text-white">{preset.label}</p>
                        <p className="text-[10px] text-slate-400 font-mono">
                          {preset.w} × {preset.h} ({preset.ratio})
                        </p>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            )}

            {activeToolTab === 'text' && (
              <div className="space-y-3">
                <p className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">Pre-styled Typographic Headers</p>

                <button
                  onClick={() => handleAddText('MASTER PHOTO STUDIO', 'headline')}
                  className="w-full p-3 rounded-xl bg-[#161920] border border-[#232833] hover:border-[#00d2ff] text-left transition-colors"
                >
                  <p className="text-sm font-extrabold text-white tracking-wide">MASTER PHOTO STUDIO</p>
                  <p className="text-[10px] text-slate-400 font-mono mt-0.5">Bold Impact Display</p>
                </button>

                <button
                  onClick={() => handleAddText('AI NEURAL FILTER', 'cyber')}
                  className="w-full p-3 rounded-xl bg-[#161920] border border-[#232833] hover:border-[#00d2ff] text-left transition-colors"
                >
                  <p className="text-sm font-bold text-[#00d2ff] font-mono tracking-wider">AI NEURAL FILTER</p>
                  <p className="text-[10px] text-slate-400 font-mono mt-0.5">Electric Cyan Monospace</p>
                </button>

                <button
                  onClick={() => handleAddText('Editorial Autumn Collection', 'subhead')}
                  className="w-full p-3 rounded-xl bg-[#161920] border border-[#232833] hover:border-[#00d2ff] text-left transition-colors"
                >
                  <p className="text-xs font-medium text-slate-200">Editorial Autumn Collection</p>
                  <p className="text-[10px] text-slate-400 font-mono mt-0.5">Clean Subheading</p>
                </button>
              </div>
            )}

            {activeToolTab === 'shapes' && (
              <div className="space-y-3">
                <p className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">Graphic Overlays</p>

                <button
                  onClick={() => handleAddShape('badge')}
                  className="w-full p-3 rounded-xl bg-[#161920] border border-[#232833] hover:border-[#00d2ff] text-left transition-colors"
                >
                  <div className="w-24 h-6 rounded-md bg-[#00d2ff]/20 border border-[#00d2ff] flex items-center justify-center text-[10px] font-bold text-[#00d2ff] mb-1">
                    BADGE
                  </div>
                  <p className="text-xs text-white font-medium">Cyber Overlay Badge</p>
                </button>

                <button
                  onClick={() => handleAddShape('frame')}
                  className="w-full p-3 rounded-xl bg-[#161920] border border-[#232833] hover:border-[#00d2ff] text-left transition-colors"
                >
                  <div className="w-24 h-12 rounded border border-white/30 mb-1" />
                  <p className="text-xs text-white font-medium">Editorial Border Frame</p>
                </button>

                <button
                  onClick={() => handleAddShape('divider')}
                  className="w-full p-3 rounded-xl bg-[#161920] border border-[#232833] hover:border-[#00d2ff] text-left transition-colors"
                >
                  <div className="w-24 h-0.5 bg-[#00d2ff] my-2" />
                  <p className="text-xs text-white font-medium">Accent Divider Line</p>
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Center Canvas */}
        <StudioCanvas />
      </div>
    </div>
  );
};
