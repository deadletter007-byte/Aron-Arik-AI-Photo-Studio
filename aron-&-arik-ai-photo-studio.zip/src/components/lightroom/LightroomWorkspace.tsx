import React, { useState } from 'react';
import { useStudio } from '../../context/StudioContext';
import { StudioCanvas } from '../canvas/StudioCanvas';
import { BUILT_IN_PRESETS } from '../../utils/imageProcessing';
import {
  Sliders,
  RotateCcw,
  Sparkles,
  Bookmark,
  Plus,
  Eye,
  Columns,
  Layers,
} from 'lucide-react';
import { LightroomAdjustments } from '../../types';

export const LightroomWorkspace: React.FC = () => {
  const {
    adjustments,
    updateAdjustment,
    resetAdjustments,
    applyPreset,
    activePresetId,
    customPresets,
    saveCustomPreset,
    beforeAfterMode,
    setBeforeAfterMode,
  } = useStudio();

  const [activeSection, setActiveSection] = useState<'basic' | 'curve' | 'detail' | 'hsl'>('basic');
  const [newPresetName, setNewPresetName] = useState('');
  const [showSaveModal, setShowSaveModal] = useState(false);

  // Helper slider component
  const SliderControl = ({
    label,
    value,
    min,
    max,
    step = 1,
    unit = '',
    onChange,
    onReset,
  }: {
    label: string;
    value: number;
    min: number;
    max: number;
    step?: number;
    unit?: string;
    onChange: (v: number) => void;
    onReset?: () => void;
  }) => (
    <div className="space-y-1">
      <div className="flex items-center justify-between text-[11px]">
        <span
          onDoubleClick={onReset}
          className="text-slate-300 font-medium cursor-pointer hover:text-white"
          title="Double-click to reset"
        >
          {label}
        </span>
        <span className="font-mono text-[10px] text-slate-400 tabular-nums">
          {value > 0 && min < 0 ? `+${value}` : value}
          {unit}
        </span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(parseFloat(e.target.value))}
        className="w-full h-1 bg-[#232833] rounded appearance-none cursor-pointer"
      />
    </div>
  );

  return (
    <div className="flex-1 flex flex-col h-full bg-[#0d0f12] overflow-hidden">
      {/* Top Develop Bar */}
      <div className="h-10 px-4 bg-[#121418] border-b border-[#20252e] flex items-center justify-between text-xs text-slate-300 shrink-0">
        <div className="flex items-center gap-2">
          <Sliders className="w-3.5 h-3.5 text-[#00d2ff]" />
          <span className="font-semibold text-white font-mono text-[11px]">LIGHTROOM DEVELOP</span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setBeforeAfterMode(!beforeAfterMode)}
            className={`px-2.5 py-1 rounded text-[11px] font-mono flex items-center gap-1.5 transition-colors ${
              beforeAfterMode
                ? 'bg-[#00d2ff] text-black font-semibold'
                : 'bg-[#181c24] text-slate-300 hover:text-white'
            }`}
          >
            <Columns className="w-3 h-3" />
            <span>Before / After</span>
          </button>

          <button
            onClick={resetAdjustments}
            className="flex items-center gap-1 px-2.5 py-1 rounded bg-[#181c24] hover:bg-[#232833] text-slate-300 hover:text-white text-[11px] font-mono transition-colors"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Reset All</span>
          </button>
        </div>
      </div>

      {/* Main Area: Center Canvas + Right Controls */}
      <div className="flex-1 flex overflow-hidden">
        {/* Center Canvas */}
        <StudioCanvas />

        {/* Right Dock: Lightroom Adjustments Inspector */}
        <div className="w-72 bg-[#121418] border-l border-[#20252e] flex flex-col shrink-0">
          {/* Presets Horizontal Strip */}
          <div className="p-3 border-b border-[#20252e] bg-[#0e1014]">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-mono text-slate-400">PRO PRESETS</span>
              <button
                onClick={() => setShowSaveModal(true)}
                title="Save current look as custom preset"
                className="text-[10px] text-[#00d2ff] hover:underline flex items-center gap-1"
              >
                <Plus className="w-2.5 h-2.5" />
                <span>Save</span>
              </button>
            </div>

            <div className="grid grid-cols-2 gap-1.5 max-h-24 overflow-y-auto">
              {BUILT_IN_PRESETS.map((preset) => {
                const isActive = activePresetId === preset.id;
                return (
                  <button
                    key={preset.id}
                    onClick={() => applyPreset(preset)}
                    className={`px-2 py-1.5 rounded text-[11px] text-left truncate font-medium border transition-colors ${
                      isActive
                        ? 'bg-[#1b2533] border-[#00d2ff] text-[#00d2ff]'
                        : 'bg-[#161920] border-[#222732] text-slate-300 hover:border-[#303746]'
                    }`}
                  >
                    {preset.name}
                  </button>
                );
              })}
              {customPresets.map((preset) => (
                <button
                  key={preset.id}
                  onClick={() => applyPreset(preset)}
                  className="px-2 py-1.5 rounded text-[11px] text-left truncate font-medium border bg-[#1a2327] border-cyan-800 text-cyan-300"
                >
                  ★ {preset.name}
                </button>
              ))}
            </div>
          </div>

          {/* Tab Navigation: Basic | Curves | Detail | HSL */}
          <div className="flex items-center border-b border-[#20252e] bg-[#101216] text-[11px]">
            <button
              onClick={() => setActiveSection('basic')}
              className={`flex-1 py-2 text-center font-medium border-b-2 transition-colors ${
                activeSection === 'basic'
                  ? 'border-[#00d2ff] text-[#00d2ff] bg-[#14171d]'
                  : 'border-transparent text-slate-400 hover:text-white'
              }`}
            >
              Basic
            </button>
            <button
              onClick={() => setActiveSection('curve')}
              className={`flex-1 py-2 text-center font-medium border-b-2 transition-colors ${
                activeSection === 'curve'
                  ? 'border-[#00d2ff] text-[#00d2ff] bg-[#14171d]'
                  : 'border-transparent text-slate-400 hover:text-white'
              }`}
            >
              Curves
            </button>
            <button
              onClick={() => setActiveSection('detail')}
              className={`flex-1 py-2 text-center font-medium border-b-2 transition-colors ${
                activeSection === 'detail'
                  ? 'border-[#00d2ff] text-[#00d2ff] bg-[#14171d]'
                  : 'border-transparent text-slate-400 hover:text-white'
              }`}
            >
              Detail
            </button>
            <button
              onClick={() => setActiveSection('hsl')}
              className={`flex-1 py-2 text-center font-medium border-b-2 transition-colors ${
                activeSection === 'hsl'
                  ? 'border-[#00d2ff] text-[#00d2ff] bg-[#14171d]'
                  : 'border-transparent text-slate-400 hover:text-white'
              }`}
            >
              HSL
            </button>
          </div>

          {/* Sliders Container */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {activeSection === 'basic' && (
              <>
                <div className="space-y-3 pb-3 border-b border-[#1f242e]">
                  <p className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">Tone</p>
                  <SliderControl
                    label="Exposure"
                    value={adjustments.exposure}
                    min={-2.0}
                    max={2.0}
                    step={0.05}
                    unit=" EV"
                    onChange={(v) => updateAdjustment('exposure', v)}
                    onReset={() => updateAdjustment('exposure', 0)}
                  />
                  <SliderControl
                    label="Contrast"
                    value={adjustments.contrast}
                    min={-100}
                    max={100}
                    onChange={(v) => updateAdjustment('contrast', v)}
                    onReset={() => updateAdjustment('contrast', 0)}
                  />
                  <SliderControl
                    label="Highlights"
                    value={adjustments.highlights}
                    min={-100}
                    max={100}
                    onChange={(v) => updateAdjustment('highlights', v)}
                    onReset={() => updateAdjustment('highlights', 0)}
                  />
                  <SliderControl
                    label="Shadows"
                    value={adjustments.shadows}
                    min={-100}
                    max={100}
                    onChange={(v) => updateAdjustment('shadows', v)}
                    onReset={() => updateAdjustment('shadows', 0)}
                  />
                  <SliderControl
                    label="Whites"
                    value={adjustments.whites}
                    min={-100}
                    max={100}
                    onChange={(v) => updateAdjustment('whites', v)}
                    onReset={() => updateAdjustment('whites', 0)}
                  />
                  <SliderControl
                    label="Blacks"
                    value={adjustments.blacks}
                    min={-100}
                    max={100}
                    onChange={(v) => updateAdjustment('blacks', v)}
                    onReset={() => updateAdjustment('blacks', 0)}
                  />
                </div>

                <div className="space-y-3">
                  <p className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">White Balance &amp; Presence</p>
                  <SliderControl
                    label="Temp (Kelvin)"
                    value={adjustments.temperature}
                    min={-100}
                    max={100}
                    onChange={(v) => updateAdjustment('temperature', v)}
                    onReset={() => updateAdjustment('temperature', 0)}
                  />
                  <SliderControl
                    label="Tint"
                    value={adjustments.tint}
                    min={-100}
                    max={100}
                    onChange={(v) => updateAdjustment('tint', v)}
                    onReset={() => updateAdjustment('tint', 0)}
                  />
                  <SliderControl
                    label="Vibrance"
                    value={adjustments.vibrance}
                    min={-100}
                    max={100}
                    onChange={(v) => updateAdjustment('vibrance', v)}
                    onReset={() => updateAdjustment('vibrance', 0)}
                  />
                  <SliderControl
                    label="Saturation"
                    value={adjustments.saturation}
                    min={-100}
                    max={100}
                    onChange={(v) => updateAdjustment('saturation', v)}
                    onReset={() => updateAdjustment('saturation', 0)}
                  />
                </div>
              </>
            )}

            {activeSection === 'curve' && (
              <div className="space-y-4">
                <p className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">RGB Tone Curve</p>
                <div className="relative w-full aspect-square bg-[#0a0c0f] rounded-lg border border-[#222732] p-2 flex items-center justify-center">
                  <svg className="w-full h-full overflow-visible">
                    {/* Grid */}
                    <line x1="25%" y1="0%" x2="25%" y2="100%" stroke="#1e222b" strokeWidth="1" />
                    <line x1="50%" y1="0%" x2="50%" y2="100%" stroke="#1e222b" strokeWidth="1" />
                    <line x1="75%" y1="0%" x2="75%" y2="100%" stroke="#1e222b" strokeWidth="1" />
                    <line x1="0%" y1="25%" x2="100%" y2="25%" stroke="#1e222b" strokeWidth="1" />
                    <line x1="0%" y1="50%" x2="100%" y2="50%" stroke="#1e222b" strokeWidth="1" />
                    <line x1="0%" y1="75%" x2="100%" y2="75%" stroke="#1e222b" strokeWidth="1" />

                    {/* Curve line */}
                    <path
                      d="M 10 190 Q 60 140 100 100 T 190 10"
                      fill="none"
                      stroke="#00d2ff"
                      strokeWidth="2.5"
                    />
                    <circle cx="10" cy="190" r="4" fill="#00d2ff" />
                    <circle cx="100" cy="100" r="4" fill="#ffffff" />
                    <circle cx="190" cy="10" r="4" fill="#00d2ff" />
                  </svg>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() =>
                      updateAdjustment('curve', [
                        { x: 0, y: 0 },
                        { x: 64, y: 55 },
                        { x: 128, y: 128 },
                        { x: 192, y: 200 },
                        { x: 255, y: 255 },
                      ])
                    }
                    className="flex-1 py-1 text-[10px] font-mono rounded bg-[#161920] border border-[#232833] hover:text-white"
                  >
                    Medium Contrast
                  </button>
                  <button
                    onClick={() =>
                      updateAdjustment('curve', [
                        { x: 0, y: 0 },
                        { x: 64, y: 64 },
                        { x: 128, y: 128 },
                        { x: 192, y: 192 },
                        { x: 255, y: 255 },
                      ])
                    }
                    className="flex-1 py-1 text-[10px] font-mono rounded bg-[#161920] border border-[#232833] hover:text-white"
                  >
                    Linear Reset
                  </button>
                </div>
              </div>
            )}

            {activeSection === 'detail' && (
              <div className="space-y-3">
                <p className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">Detail &amp; Effects</p>
                <SliderControl
                  label="Sharpening"
                  value={adjustments.sharpening}
                  min={0}
                  max={100}
                  onChange={(v) => updateAdjustment('sharpening', v)}
                  onReset={() => updateAdjustment('sharpening', 0)}
                />
                <SliderControl
                  label="Clarity"
                  value={adjustments.clarity}
                  min={0}
                  max={100}
                  onChange={(v) => updateAdjustment('clarity', v)}
                  onReset={() => updateAdjustment('clarity', 0)}
                />
                <SliderControl
                  label="Dehaze"
                  value={adjustments.dehaze}
                  min={-50}
                  max={50}
                  onChange={(v) => updateAdjustment('dehaze', v)}
                  onReset={() => updateAdjustment('dehaze', 0)}
                />
                <SliderControl
                  label="Vignette"
                  value={adjustments.vignette}
                  min={-100}
                  max={100}
                  onChange={(v) => updateAdjustment('vignette', v)}
                  onReset={() => updateAdjustment('vignette', 0)}
                />
                <SliderControl
                  label="Film Grain"
                  value={adjustments.grain}
                  min={0}
                  max={100}
                  onChange={(v) => updateAdjustment('grain', v)}
                  onReset={() => updateAdjustment('grain', 0)}
                />
              </div>
            )}

            {activeSection === 'hsl' && (
              <div className="space-y-3 text-xs">
                <p className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">HSL Color Mixer</p>
                <div className="flex items-center gap-1.5 p-2 rounded bg-[#161920] border border-[#232833]">
                  <span className="w-3 h-3 rounded-full bg-red-500" />
                  <span className="text-[11px] font-medium text-slate-300">Reds</span>
                  <span className="ml-auto text-[10px] font-mono text-slate-400">0 / 0 / 0</span>
                </div>
                <div className="flex items-center gap-1.5 p-2 rounded bg-[#161920] border border-[#232833]">
                  <span className="w-3 h-3 rounded-full bg-orange-500" />
                  <span className="text-[11px] font-medium text-slate-300">Oranges (Skin)</span>
                  <span className="ml-auto text-[10px] font-mono text-slate-400">0 / 0 / 0</span>
                </div>
                <div className="flex items-center gap-1.5 p-2 rounded bg-[#161920] border border-[#232833]">
                  <span className="w-3 h-3 rounded-full bg-cyan-500" />
                  <span className="text-[11px] font-medium text-slate-300">Cyans (Teal)</span>
                  <span className="ml-auto text-[10px] font-mono text-slate-400">0 / 0 / 0</span>
                </div>
                <div className="flex items-center gap-1.5 p-2 rounded bg-[#161920] border border-[#232833]">
                  <span className="w-3 h-3 rounded-full bg-blue-500" />
                  <span className="text-[11px] font-medium text-slate-300">Blues (Sky)</span>
                  <span className="ml-auto text-[10px] font-mono text-slate-400">0 / 0 / 0</span>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Save Custom Preset Dialog Modal */}
      {showSaveModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-[#161920] border border-[#2b313d] rounded-2xl p-5 shadow-2xl space-y-4">
            <h3 className="text-sm font-bold text-white">Save Custom Lightroom Preset</h3>
            <p className="text-xs text-slate-400">
              Save current slider parameters, curves, and color grading as a reusable preset.
            </p>
            <input
              type="text"
              placeholder="Preset Name (e.g. My Cinema Look)"
              value={newPresetName}
              onChange={(e) => setNewPresetName(e.target.value)}
              className="w-full px-3 py-2 bg-[#0e1014] border border-[#2a303d] rounded-lg text-xs text-white placeholder-slate-500 outline-none focus:border-[#00d2ff]"
            />
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setShowSaveModal(false)}
                className="px-3 py-1.5 text-xs text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  if (newPresetName.trim()) {
                    saveCustomPreset(newPresetName.trim());
                    setNewPresetName('');
                    setShowSaveModal(false);
                  }
                }}
                className="px-4 py-1.5 text-xs font-semibold text-black bg-[#00d2ff] hover:bg-[#38dcff] rounded-lg"
              >
                Save Preset
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
