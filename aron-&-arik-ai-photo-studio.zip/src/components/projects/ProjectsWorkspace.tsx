import React, { useState, useRef } from 'react';
import { useStudio } from '../../context/StudioContext';
import {
  FolderOpen,
  Plus,
  Upload,
  Download,
  Copy,
  Trash2,
  Calendar,
  Layers,
  Sparkles,
  Check,
} from 'lucide-react';
import { ASSETS } from '../../utils/assets';

export const ProjectsWorkspace: React.FC = () => {
  const {
    projectName,
    setProjectName,
    loadSampleProject,
    createNewBlankProject,
    setCurrentTab,
    layers,
    adjustments,
    canvasWidth,
    canvasHeight,
    addImageLayer,
    pushHistory,
  } = useStudio();

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [showNewModal, setShowNewModal] = useState(false);
  const [newWidth, setNewWidth] = useState(1080);
  const [newHeight, setNewHeight] = useState(1350);
  const [newName, setNewName] = useState('New Project Session');

  // Handle local photo import
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      const img = new Image();
      img.onload = () => {
        createNewBlankProject(img.width, img.height, file.name.replace(/\.[^/.]+$/, ''));
        addImageLayer(img, 'Imported Photo');
        pushHistory();
        setCurrentTab('photoshop');
      };
      img.src = dataUrl;
    };
    reader.readAsDataURL(file);
  };

  // Export native project package (.aark json format)
  const handleExportProjectBundle = () => {
    const bundle = {
      format: 'aron_arik_project_v1',
      projectName,
      canvasWidth,
      canvasHeight,
      timestamp: Date.now(),
      adjustments,
      layers: layers.map((l) => ({
        id: l.id,
        name: l.name,
        visible: l.visible,
        locked: l.locked,
        opacity: l.opacity,
        blendMode: l.blendMode,
        type: l.type,
        dataUrl: l.canvas.toDataURL('image/png'),
      })),
    };

    const blob = new Blob([JSON.stringify(bundle, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${projectName.toLowerCase().replace(/\s+/g, '_')}.aark`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const sampleProjects = [
    {
      id: 'sample_portrait',
      title: 'Commercial Studio Portrait',
      type: 'portrait' as const,
      thumb: ASSETS.samplePortrait,
      dims: '1080 × 1440',
      description: 'Ultra-sharp 100mm portrait with natural skin texture and soft key rim lighting.',
    },
    {
      id: 'sample_landscape',
      title: 'Alpine Pavilion Dusk',
      type: 'landscape' as const,
      thumb: ASSETS.sampleLandscape,
      dims: '1920 × 1080',
      description: 'High dynamic range twilight architecture with blue hour sky and reflection pool.',
    },
    {
      id: 'sample_street',
      title: 'Metropolis Rain Reflection',
      type: 'street' as const,
      thumb: ASSETS.sampleStreet,
      dims: '1440 × 1080',
      description: 'Documentary night urban scene with rich charcoal tones and wet asphalt reflections.',
    },
  ];

  return (
    <div className="flex-1 flex flex-col h-full bg-[#0d0f12] overflow-y-auto p-4 sm:p-6 lg:p-8">
      {/* Hidden File Picker */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleFileSelect}
        className="hidden"
      />

      <div className="max-w-5xl mx-auto w-full space-y-6">
        {/* Header Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#20252e]">
          <div>
            <h2 className="text-xl font-bold text-white tracking-tight">Project Management</h2>
            <p className="text-xs text-slate-400 mt-1">
              Create, organize, import and export multi-layer non-destructive artwork sessions.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => fileInputRef.current?.click()}
              className="px-3.5 py-2 rounded-xl bg-[#161920] border border-[#2b313d] hover:border-[#00d2ff] text-slate-200 hover:text-white text-xs font-semibold flex items-center gap-2 transition-colors cursor-pointer"
            >
              <Upload className="w-3.5 h-3.5 text-[#00d2ff]" />
              <span>Import Photo</span>
            </button>

            <button
              onClick={handleExportProjectBundle}
              className="px-3.5 py-2 rounded-xl bg-[#161920] border border-[#2b313d] hover:border-[#00d2ff] text-slate-200 hover:text-white text-xs font-semibold flex items-center gap-2 transition-colors cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-[#00d2ff]" />
              <span>Export .AARK Project</span>
            </button>

            <button
              onClick={() => setShowNewModal(true)}
              className="px-4 py-2 rounded-xl bg-[#00d2ff] hover:bg-[#38dcff] text-black text-xs font-bold flex items-center gap-2 transition-all cursor-pointer shadow-sm"
            >
              <Plus className="w-4 h-4" />
              <span>New Canvas</span>
            </button>
          </div>
        </div>

        {/* Current Active Project Banner */}
        <div className="p-4 rounded-2xl bg-[#14171d] border border-[#232833] flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-[#1d222b] border border-[#2e3544] flex items-center justify-center text-[#00d2ff]">
              <Layers className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold text-white">{projectName}</span>
                <span className="text-[10px] font-mono text-[#00d2ff] bg-[#00d2ff]/10 px-2 py-0.5 rounded">
                  ACTIVE SESSION
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                {canvasWidth} × {canvasHeight}px · {layers.length} Layers · Non-destructive Develop enabled
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 w-full md:w-auto">
            <button
              onClick={() => setCurrentTab('photoshop')}
              className="flex-1 md:flex-initial px-4 py-2 rounded-xl bg-[#1d222b] hover:bg-[#252c38] text-white text-xs font-semibold transition-colors"
            >
              Open in Photoshop
            </button>
            <button
              onClick={() => setCurrentTab('lightroom')}
              className="flex-1 md:flex-initial px-4 py-2 rounded-xl bg-[#00d2ff] hover:bg-[#38dcff] text-black text-xs font-semibold transition-colors"
            >
              Open in Lightroom
            </button>
          </div>
        </div>

        {/* Sample High-Resolution Studio Projects */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
              Sample High-Dynamic-Range Sessions
            </h3>
            <span className="text-xs text-slate-400">Click to switch active project</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {sampleProjects.map((p) => (
              <div
                key={p.id}
                onClick={async () => {
                  await loadSampleProject(p.type);
                  setCurrentTab('photoshop');
                }}
                className="group rounded-2xl bg-[#14171d] border border-[#222732] hover:border-[#00d2ff]/60 p-3 transition-all cursor-pointer flex flex-col"
              >
                <div className="w-full aspect-[4/3] rounded-xl overflow-hidden bg-black/40 border border-[#222732] mb-3 relative">
                  <img
                    src={p.thumb}
                    alt={p.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute bottom-2 right-2 px-2 py-0.5 rounded bg-black/70 backdrop-blur-sm text-[10px] font-mono text-white">
                    {p.dims}
                  </div>
                </div>

                <h4 className="text-sm font-semibold text-white group-hover:text-[#00d2ff] transition-colors truncate">
                  {p.title}
                </h4>
                <p className="text-xs text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                  {p.description}
                </p>

                <div className="mt-3 pt-3 border-t border-[#1f242e] flex items-center justify-between text-xs text-[#00d2ff] font-semibold">
                  <span>Load Studio Artboard</span>
                  <span>→</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* New Project Modal */}
      {showNewModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-[#161920] border border-[#2b313d] rounded-2xl p-5 shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-white">Create New Blank Artboard</h3>

            <div className="space-y-3">
              <div>
                <label className="text-xs text-slate-400 block mb-1">Project Name</label>
                <input
                  type="text"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  className="w-full px-3 py-2 bg-[#0e1014] border border-[#2a303d] rounded-lg text-xs text-white outline-none focus:border-[#00d2ff]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-slate-400 block mb-1">Width (px)</label>
                  <input
                    type="number"
                    value={newWidth}
                    onChange={(e) => setNewWidth(parseInt(e.target.value) || 1080)}
                    className="w-full px-3 py-2 bg-[#0e1014] border border-[#2a303d] rounded-lg text-xs text-white outline-none focus:border-[#00d2ff] font-mono"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-400 block mb-1">Height (px)</label>
                  <input
                    type="number"
                    value={newHeight}
                    onChange={(e) => setNewHeight(parseInt(e.target.value) || 1080)}
                    className="w-full px-3 py-2 bg-[#0e1014] border border-[#2a303d] rounded-lg text-xs text-white outline-none focus:border-[#00d2ff] font-mono"
                  />
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setShowNewModal(false)}
                className="px-3.5 py-2 text-xs text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  createNewBlankProject(newWidth, newHeight, newName);
                  setShowNewModal(false);
                  setCurrentTab('photoshop');
                }}
                className="px-4 py-2 text-xs font-semibold text-black bg-[#00d2ff] hover:bg-[#38dcff] rounded-lg"
              >
                Create Artboard
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
