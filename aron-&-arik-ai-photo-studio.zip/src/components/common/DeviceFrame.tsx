import React from 'react';
import { useStudio } from '../../context/StudioContext';
import {
  Wifi,
  Battery,
  Signal,
  Layers,
  Sparkles,
  Sliders,
  Palette,
  Wand2,
  FolderOpen,
  Settings,
  Home,
} from 'lucide-react';
import { ScreenTab } from '../../types';

interface DeviceFrameProps {
  children: React.ReactNode;
}

export const DeviceFrame: React.FC<DeviceFrameProps> = ({ children }) => {
  const { settings, currentTab, setCurrentTab } = useStudio();

  // If desktop studio mode, render full-bleed
  if (!settings.deviceSimMode) {
    return <div className="flex-1 flex flex-col h-full overflow-hidden">{children}</div>;
  }

  // Samsung Galaxy S21 Plus (SM-G996U) Spec: 20:9 aspect ratio, 6.7" Dynamic AMOLED 2X, 1080x2400
  return (
    <div className="flex-1 flex flex-col items-center justify-center p-3 sm:p-6 bg-[#0a0c0f] overflow-y-auto">
      {/* Device Info Badge */}
      <div className="flex items-center gap-2 text-[11px] font-mono text-slate-400 mb-2">
        <span className="w-2 h-2 rounded-full bg-[#00d2ff]" />
        <span>Samsung Galaxy S21+ 5G (SM-G996U)</span>
        <span aria-hidden="true">·</span>
        <span>One UI 7 / Android 15</span>
      </div>

      {/* Galaxy S21+ Hardware Chassis */}
      <div className="relative w-full max-w-[420px] h-[860px] bg-[#14171d] rounded-[48px] p-3 shadow-2xl border-4 border-[#2d3340] ring-1 ring-white/10 flex flex-col overflow-hidden">
        {/* Hardware buttons on right edge */}
        <div className="absolute -right-5 top-28 w-1 h-12 bg-[#2d3340] rounded-r-sm" />
        <div className="absolute -right-5 top-44 w-1 h-20 bg-[#2d3340] rounded-r-sm" />

        {/* Inner Curved Screen Glass */}
        <div className="relative flex-1 bg-[#0d0f12] rounded-[38px] overflow-hidden flex flex-col border border-[#1b1f27]">
          {/* One UI 7 Status Bar with Infinity-O Punch Hole */}
          <div className="h-9 px-6 bg-[#101216] flex items-center justify-between text-xs text-slate-300 select-none shrink-0 z-40 border-b border-[#1b1f26]">
            {/* Clock */}
            <span className="font-semibold tracking-tight text-[11px] font-mono">10:45</span>

            {/* Infinity-O Camera Cutout */}
            <div className="w-3.5 h-3.5 rounded-full bg-black border border-[#2b303a] shadow-inner" />

            {/* Status Icons */}
            <div className="flex items-center gap-1.5 text-slate-400">
              <span className="text-[10px] font-semibold text-white font-mono">5G</span>
              <Signal className="w-3 h-3 text-white" />
              <Wifi className="w-3 h-3 text-white" />
              <Battery className="w-3.5 h-3.5 text-white" />
            </div>
          </div>

          {/* Main App Content Container */}
          <div className="flex-1 flex flex-col overflow-hidden relative">
            {children}
          </div>

          {/* Galaxy One UI 7 Bottom Navigation Tabs */}
          <div className="h-14 bg-[#101216] border-t border-[#1e222b] grid grid-cols-5 items-center px-1 shrink-0 z-40">
            <button
              onClick={() => setCurrentTab('home')}
              className={`flex flex-col items-center justify-center py-1 transition-colors ${
                currentTab === 'home' ? 'text-[#00d2ff]' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Home className="w-4 h-4" />
              <span className="text-[9px] mt-0.5 font-medium">Home</span>
            </button>

            <button
              onClick={() => setCurrentTab('assistant')}
              className={`flex flex-col items-center justify-center py-1 transition-colors ${
                currentTab === 'assistant' ? 'text-[#00d2ff]' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Sparkles className="w-4 h-4" />
              <span className="text-[9px] mt-0.5 font-medium">AI Assist</span>
            </button>

            <button
              onClick={() => setCurrentTab('photoshop')}
              className={`flex flex-col items-center justify-center py-1 transition-colors ${
                currentTab === 'photoshop' ? 'text-[#00d2ff]' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Layers className="w-4 h-4" />
              <span className="text-[9px] mt-0.5 font-medium">Layers</span>
            </button>

            <button
              onClick={() => setCurrentTab('lightroom')}
              className={`flex flex-col items-center justify-center py-1 transition-colors ${
                currentTab === 'lightroom' ? 'text-[#00d2ff]' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Sliders className="w-4 h-4" />
              <span className="text-[9px] mt-0.5 font-medium">Develop</span>
            </button>

            <button
              onClick={() => setCurrentTab('aitools')}
              className={`flex flex-col items-center justify-center py-1 transition-colors ${
                currentTab === 'aitools' ? 'text-[#00d2ff]' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Wand2 className="w-4 h-4" />
              <span className="text-[9px] mt-0.5 font-medium">AI Tools</span>
            </button>
          </div>

          {/* Android Navigation Gestures / Software Pill Bar */}
          <div className="h-4 bg-[#101216] flex items-center justify-center shrink-0">
            <div className="w-28 h-1 bg-slate-600 rounded-full" />
          </div>
        </div>
      </div>
    </div>
  );
};
