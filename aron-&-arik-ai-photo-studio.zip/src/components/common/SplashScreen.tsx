import React, { useEffect, useState } from 'react';
import { ASSETS } from '../../utils/assets';
import { Sparkles, ArrowRight } from 'lucide-react';

interface SplashScreenProps {
  onFinish: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onFinish }) => {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const start = Date.now();
    const duration = 1800; // 1.8 seconds

    const timer = setInterval(() => {
      const elapsed = Date.now() - start;
      const p = Math.min(100, Math.round((elapsed / duration) * 100));
      setProgress(p);

      if (p >= 100) {
        clearInterval(timer);
        setTimeout(onFinish, 200);
      }
    }, 30);

    return () => clearInterval(timer);
  }, [onFinish]);

  return (
    <div className="fixed inset-0 z-50 bg-[#0a0c0f] flex flex-col items-center justify-between p-6 sm:p-8 select-none relative overflow-hidden">
      {/* Subtle Matte Black Radial Ambience */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_#141922_0%,_#0a0c0f_70%)] pointer-events-none opacity-80" />

      {/* Top Meta info */}
      <div className="relative z-10 w-full max-w-md flex items-center justify-between text-[11px] font-mono text-slate-400">
        <span className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-[#00d2ff] animate-pulse" />
          <span>SAMSUNG GALAXY S21+ 5G</span>
        </span>
        <span>ONE UI 7 / ANDROID 15</span>
      </div>

      {/* Center Official Brand Logo & Identity */}
      <div className="relative z-10 flex flex-col items-center text-center max-w-sm space-y-6">
        {/* Official 3D AI Logo: exact proportions, no distortion, no color alteration */}
        <div className="relative w-44 h-44 sm:w-52 sm:h-52 rounded-3xl overflow-hidden bg-[#111317] border border-[#262c37] shadow-2xl p-2 flex items-center justify-center ring-1 ring-white/10">
          <img
            src={ASSETS.logo}
            alt="Aron &amp; Arik Official Brand Logo"
            className="w-full h-full object-contain"
            referrerPolicy="no-referrer"
          />
        </div>

        <div className="space-y-2">
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Aron &amp; Arik <span className="text-[#00d2ff]">Photo Studio</span>
          </h1>
          <p className="text-xs text-slate-400 font-mono tracking-wider uppercase">
            Official AI Photography &amp; Layer Engine
          </p>
        </div>
      </div>

      {/* Bottom Loading Progress Bar & Skip */}
      <div className="relative z-10 w-full max-w-xs space-y-3">
        <div className="flex items-center justify-between text-[11px] font-mono text-slate-400">
          <span>INITIALIZING WORKSPACES</span>
          <span className="text-[#00d2ff]">{progress}%</span>
        </div>

        <div className="w-full h-1.5 bg-[#181c24] rounded-full overflow-hidden border border-[#252b36]">
          <div
            className="h-full bg-[#00d2ff] rounded-full transition-all duration-100 ease-out shadow-sm shadow-[#00d2ff]"
            style={{ width: `${progress}%` }}
          />
        </div>

        <div className="flex justify-center pt-2">
          <button
            onClick={onFinish}
            className="text-[11px] font-mono text-slate-400 hover:text-white transition-colors flex items-center gap-1 py-1 px-3 rounded-lg hover:bg-[#161920]"
          >
            <span>Skip to Studio</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>
      </div>
    </div>
  );
};
