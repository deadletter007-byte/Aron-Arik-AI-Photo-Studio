import React from 'react';
import { useStudio } from '../../context/StudioContext';
import {
  Sparkles,
  Layers,
  Sliders,
  Palette,
  Wand2,
  FolderOpen,
  Settings,
  Download,
  RotateCcw,
  RotateCw,
  Smartphone,
  Monitor,
} from 'lucide-react';
import { ASSETS } from '../../utils/assets';

interface HeaderProps {
  onOpenExport: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenExport }) => {
  const {
    currentTab,
    setCurrentTab,
    projectName,
    canUndo,
    canRedo,
    undo,
    redo,
    settings,
    updateSettings,
    isProcessing,
  } = useStudio();

  return (
    <header className="flex items-center justify-between gap-8 px-5 py-3 bg-[#101216] border-b border-[#20242c] shrink-0 z-30 select-none">
      {/* Zone 1: Single text element wordmark with brand emblem */}
      <div className="flex items-center gap-3 whitespace-nowrap shrink-0">
        <div className="w-8 h-8 rounded-lg overflow-hidden border border-[#2c323d] bg-[#161920] flex items-center justify-center p-0.5 shadow-inner">
          <img
            src={ASSETS.logo}
            alt="Aron &amp; Arik Emblem"
            className="w-full h-full object-contain"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="flex items-baseline gap-2">
          <span className="text-base font-bold tracking-tight text-white font-sans">
            Aron &amp; Arik
          </span>
          <span className="text-xs font-semibold text-[#00d2ff] tracking-wider uppercase font-mono">
            Photo Studio
          </span>
        </div>
      </div>

      {/* Zone 2: Clean single-line text navigation links */}
      <nav className="hidden lg:flex items-center gap-1 xl:gap-2 text-xs font-medium text-slate-300">
        <button
          onClick={() => setCurrentTab('home')}
          className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
            currentTab === 'home'
              ? 'bg-[#1e232d] text-white font-semibold'
              : 'hover:text-white hover:bg-[#15181f]'
          }`}
        >
          <span>Studio Overview</span>
        </button>

        <button
          onClick={() => setCurrentTab('assistant')}
          className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
            currentTab === 'assistant'
              ? 'bg-[#1e232d] text-[#00d2ff] font-semibold'
              : 'hover:text-white hover:bg-[#15181f]'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>AI Assistant</span>
        </button>

        <button
          onClick={() => setCurrentTab('photoshop')}
          className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
            currentTab === 'photoshop'
              ? 'bg-[#1e232d] text-white font-semibold'
              : 'hover:text-white hover:bg-[#15181f]'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          <span>Photoshop Studio</span>
        </button>

        <button
          onClick={() => setCurrentTab('lightroom')}
          className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
            currentTab === 'lightroom'
              ? 'bg-[#1e232d] text-white font-semibold'
              : 'hover:text-white hover:bg-[#15181f]'
          }`}
        >
          <Sliders className="w-3.5 h-3.5" />
          <span>Lightroom Develop</span>
        </button>

        <button
          onClick={() => setCurrentTab('express')}
          className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
            currentTab === 'express'
              ? 'bg-[#1e232d] text-white font-semibold'
              : 'hover:text-white hover:bg-[#15181f]'
          }`}
        >
          <Palette className="w-3.5 h-3.5" />
          <span>Express Design</span>
        </button>

        <button
          onClick={() => setCurrentTab('aitools')}
          className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
            currentTab === 'aitools'
              ? 'bg-[#1e232d] text-[#00d2ff] font-semibold'
              : 'hover:text-white hover:bg-[#15181f]'
          }`}
        >
          <Wand2 className="w-3.5 h-3.5" />
          <span>AI Tools</span>
        </button>

        <button
          onClick={() => setCurrentTab('projects')}
          className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
            currentTab === 'projects'
              ? 'bg-[#1e232d] text-white font-semibold'
              : 'hover:text-white hover:bg-[#15181f]'
          }`}
        >
          <FolderOpen className="w-3.5 h-3.5" />
          <span>Projects</span>
        </button>

        <button
          onClick={() => setCurrentTab('settings')}
          className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
            currentTab === 'settings'
              ? 'bg-[#1e232d] text-white font-semibold'
              : 'hover:text-white hover:bg-[#15181f]'
          }`}
        >
          <Settings className="w-3.5 h-3.5" />
          <span>Settings</span>
        </button>
      </nav>

      {/* Zone 3: 1 primary action & compact utility triggers */}
      <div className="flex items-center gap-2 shrink-0">
        {/* Undo / Redo triggers */}
        <div className="flex items-center bg-[#161920] border border-[#262b35] rounded-lg p-0.5">
          <button
            onClick={undo}
            disabled={!canUndo}
            title="Undo (Ctrl+Z)"
            aria-label="Undo"
            className="w-7 h-7 flex items-center justify-center rounded text-slate-400 hover:text-white disabled:opacity-30 disabled:hover:text-slate-400 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={redo}
            disabled={!canRedo}
            title="Redo (Ctrl+Y)"
            aria-label="Redo"
            className="w-7 h-7 flex items-center justify-center rounded text-slate-400 hover:text-white disabled:opacity-30 disabled:hover:text-slate-400 transition-colors"
          >
            <RotateCw className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Samsung Galaxy S21+ vs Desktop toggle */}
        <button
          onClick={() => updateSettings({ deviceSimMode: !settings.deviceSimMode })}
          title={settings.deviceSimMode ? 'Switch to Full Desktop Studio' : 'Switch to Galaxy S21+ Mode'}
          className="flex items-center gap-1.5 px-2.5 py-1.5 bg-[#161920] border border-[#262b35] rounded-lg text-xs text-slate-300 hover:text-white hover:border-[#384150] transition-colors whitespace-nowrap shrink-0"
        >
          {settings.deviceSimMode ? (
            <>
              <Monitor className="w-3.5 h-3.5 text-[#00d2ff]" />
              <span className="hidden sm:inline">Desktop Pro</span>
            </>
          ) : (
            <>
              <Smartphone className="w-3.5 h-3.5 text-[#00d2ff]" />
              <span className="hidden sm:inline">S21+ SM-G996U</span>
            </>
          )}
        </button>

        {/* Primary Action Button */}
        <button
          onClick={onOpenExport}
          className="flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold text-black bg-[#00d2ff] hover:bg-[#38dcff] active:scale-95 transition-all rounded-lg shadow-sm whitespace-nowrap shrink-0 cursor-pointer"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Export Artwork</span>
        </button>
      </div>
    </header>
  );
};
