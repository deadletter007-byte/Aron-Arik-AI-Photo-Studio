import React, { useState } from 'react';
import { useStudio } from '../../context/StudioContext';
import {
  Download,
  Share2,
  X,
  Check,
  Image as ImageIcon,
  FileCheck,
  Sparkles,
} from 'lucide-react';

interface ExportModalProps {
  onClose: () => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({ onClose }) => {
  const {
    projectName,
    canvasWidth,
    canvasHeight,
    getFlattenedAdjustedCanvas,
  } = useStudio();

  const [format, setFormat] = useState<'image/jpeg' | 'image/png' | 'image/webp'>('image/jpeg');
  const [quality, setQuality] = useState<number>(0.95);
  const [scale, setScale] = useState<number>(1);
  const [isExporting, setIsExporting] = useState<boolean>(false);
  const [exportComplete, setExportComplete] = useState<boolean>(false);

  const outWidth = canvasWidth * scale;
  const outHeight = canvasHeight * scale;

  const handleDownload = () => {
    setIsExporting(true);
    setTimeout(() => {
      try {
        const fullCanvas = getFlattenedAdjustedCanvas();
        let targetCanvas = fullCanvas;

        if (scale !== 1) {
          const scaled = document.createElement('canvas');
          scaled.width = outWidth;
          scaled.height = outHeight;
          const sCtx = scaled.getContext('2d')!;
          sCtx.imageSmoothingEnabled = true;
          sCtx.imageSmoothingQuality = 'high';
          sCtx.drawImage(fullCanvas, 0, 0, outWidth, outHeight);
          targetCanvas = scaled;
        }

        const dataUrl = targetCanvas.toDataURL(format, quality);
        const a = document.createElement('a');
        const ext = format === 'image/jpeg' ? 'jpg' : format === 'image/png' ? 'png' : 'webp';
        a.href = dataUrl;
        a.download = `${projectName.toLowerCase().replace(/\s+/g, '_')}_${outWidth}x${outHeight}.${ext}`;
        a.click();

        setExportComplete(true);
        setTimeout(() => setExportComplete(false), 2500);
      } catch (e) {
        console.error('Export failed:', e);
      } finally {
        setIsExporting(false);
      }
    }, 100);
  };

  const handleNativeShare = async () => {
    try {
      const fullCanvas = getFlattenedAdjustedCanvas();
      fullCanvas.toBlob(async (blob) => {
        if (!blob) return;
        const ext = format === 'image/jpeg' ? 'jpg' : 'png';
        const file = new File([blob], `${projectName}.${ext}`, { type: format });

        if (navigator.canShare && navigator.canShare({ files: [file] })) {
          await navigator.share({
            title: projectName,
            text: 'Created with Aron & Arik AI Photo Studio on Samsung Galaxy S21+',
            files: [file],
          });
        } else {
          // Fallback to direct download
          handleDownload();
        }
      }, format, quality);
    } catch (e) {
      console.warn('Native share declined or unavailable, downloading instead.', e);
      handleDownload();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-md flex items-center justify-center p-4">
      <div className="w-full max-w-lg bg-[#14171d] border border-[#2b313d] rounded-3xl p-6 shadow-2xl space-y-5">
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#222732]">
          <div className="flex items-center gap-2">
            <Download className="w-4 h-4 text-[#00d2ff]" />
            <h3 className="text-base font-bold text-white">Export Finished Artwork</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-[#1f242e] transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Format Selector */}
        <div className="space-y-2">
          <label className="text-xs font-mono text-slate-400 uppercase">Export Format</label>
          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={() => setFormat('image/jpeg')}
              className={`py-2 px-3 rounded-xl border text-xs font-mono font-semibold transition-colors ${
                format === 'image/jpeg'
                  ? 'bg-[#1b2533] border-[#00d2ff] text-[#00d2ff]'
                  : 'bg-[#181c24] border-[#252b36] text-slate-300'
              }`}
            >
              JPG (Standard)
            </button>
            <button
              onClick={() => setFormat('image/png')}
              className={`py-2 px-3 rounded-xl border text-xs font-mono font-semibold transition-colors ${
                format === 'image/png'
                  ? 'bg-[#1b2533] border-[#00d2ff] text-[#00d2ff]'
                  : 'bg-[#181c24] border-[#252b36] text-slate-300'
              }`}
            >
              PNG (Lossless/Alpha)
            </button>
            <button
              onClick={() => setFormat('image/webp')}
              className={`py-2 px-3 rounded-xl border text-xs font-mono font-semibold transition-colors ${
                format === 'image/webp'
                  ? 'bg-[#1b2533] border-[#00d2ff] text-[#00d2ff]'
                  : 'bg-[#181c24] border-[#252b36] text-slate-300'
              }`}
            >
              WebP (Modern)
            </button>
          </div>
        </div>

        {/* Resolution Scale Multiplier */}
        <div className="space-y-2">
          <label className="text-xs font-mono text-slate-400 uppercase">Resolution Scale</label>
          <div className="grid grid-cols-3 gap-2 text-xs">
            <button
              onClick={() => setScale(1)}
              className={`p-2.5 rounded-xl border text-left transition-colors ${
                scale === 1
                  ? 'bg-[#1b2533] border-[#00d2ff] text-[#00d2ff]'
                  : 'bg-[#181c24] border-[#252b36] text-slate-300'
              }`}
            >
              <p className="font-bold">1× Native</p>
              <p className="text-[10px] text-slate-400 font-mono mt-0.5">
                {canvasWidth} × {canvasHeight}px
              </p>
            </button>

            <button
              onClick={() => setScale(2)}
              className={`p-2.5 rounded-xl border text-left transition-colors ${
                scale === 2
                  ? 'bg-[#1b2533] border-[#00d2ff] text-[#00d2ff]'
                  : 'bg-[#181c24] border-[#252b36] text-slate-300'
              }`}
            >
              <p className="font-bold">2× High Res</p>
              <p className="text-[10px] text-slate-400 font-mono mt-0.5">
                {canvasWidth * 2} × {canvasHeight * 2}px
              </p>
            </button>

            <button
              onClick={() => setScale(4)}
              className={`p-2.5 rounded-xl border text-left transition-colors ${
                scale === 4
                  ? 'bg-[#1b2533] border-[#00d2ff] text-[#00d2ff]'
                  : 'bg-[#181c24] border-[#252b36] text-slate-300'
              }`}
            >
              <p className="font-bold">4× Ultra 4K</p>
              <p className="text-[10px] text-slate-400 font-mono mt-0.5">
                {canvasWidth * 4} × {canvasHeight * 4}px
              </p>
            </button>
          </div>
        </div>

        {/* Quality Slider (for JPG & WebP) */}
        {format !== 'image/png' && (
          <div className="space-y-1.5 p-3 rounded-xl bg-[#161920] border border-[#222732]">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-300">Compression Quality</span>
              <span className="font-mono text-slate-400">{Math.round(quality * 100)}%</span>
            </div>
            <input
              type="range"
              min="0.3"
              max="1.0"
              step="0.05"
              value={quality}
              onChange={(e) => setQuality(parseFloat(e.target.value))}
              className="w-full h-1 bg-[#232833] rounded appearance-none cursor-pointer"
            />
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center gap-2 pt-2">
          <button
            onClick={handleNativeShare}
            disabled={isExporting}
            className="w-full sm:flex-1 py-2.5 px-4 rounded-xl bg-[#1d222c] hover:bg-[#262c38] text-white text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer"
          >
            <Share2 className="w-3.5 h-3.5 text-[#00d2ff]" />
            <span>Android Quick Share</span>
          </button>

          <button
            onClick={handleDownload}
            disabled={isExporting}
            className="w-full sm:flex-1 py-2.5 px-4 rounded-xl bg-[#00d2ff] hover:bg-[#38dcff] text-black text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer shadow-sm"
          >
            {exportComplete ? (
              <>
                <Check className="w-4 h-4" />
                <span>Downloaded!</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                <span>Download Artwork</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
