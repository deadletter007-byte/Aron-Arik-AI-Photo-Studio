import React, { useRef, useEffect, useState, useCallback } from 'react';
import { useStudio } from '../../context/StudioContext';
import { applyLightroomAdjustments } from '../../utils/imageProcessing';
import {
  ZoomIn,
  ZoomOut,
  Maximize2,
  Minimize2,
  Eye,
  Columns,
  Grid,
} from 'lucide-react';

export const StudioCanvas: React.FC = () => {
  const {
    layers,
    selectedLayer,
    canvasWidth,
    canvasHeight,
    activeTool,
    brushSettings,
    setBrushSettings,
    adjustments,
    zoom,
    setZoom,
    pan,
    setPan,
    resetView,
    beforeAfterMode,
    setBeforeAfterMode,
    beforeAfterSplit,
    setBeforeAfterSplit,
    pushHistory,
  } = useStudio();

  const containerRef = useRef<HTMLDivElement>(null);
  const viewportCanvasRef = useRef<HTMLCanvasElement>(null);

  const [isDrawing, setIsDrawing] = useState(false);
  const [isPanning, setIsPanning] = useState(false);
  const [lastPos, setLastPos] = useState<{ x: number; y: number } | null>(null);
  const [panStart, setPanStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  // Clone stamp source point
  const [cloneSource, setCloneSource] = useState<{ x: number; y: number } | null>(null);

  // Selection marquee
  const [selectionRect, setSelectionRect] = useState<{ x: number; y: number; w: number; h: number } | null>(null);
  const [selectionStart, setSelectionStart] = useState<{ x: number; y: number } | null>(null);

  // Show alignment grid
  const [showGrid, setShowGrid] = useState(false);

  // Color picker indicator
  const [pickedColor, setPickedColor] = useState<string | null>(null);

  // Compute canvas coordinate from mouse/touch event
  const getCanvasCoords = useCallback(
    (e: React.MouseEvent | React.TouchEvent | MouseEvent | TouchEvent) => {
      if (!viewportCanvasRef.current || !containerRef.current) return null;
      const rect = viewportCanvasRef.current.getBoundingClientRect();
      const clientX = 'touches' in e ? e.touches[0].clientX : (e as MouseEvent).clientX;
      const clientY = 'touches' in e ? e.touches[0].clientY : (e as MouseEvent).clientY;

      const scaleX = canvasWidth / rect.width;
      const scaleY = canvasHeight / rect.height;

      const x = Math.round((clientX - rect.left) * scaleX);
      const y = Math.round((clientY - rect.top) * scaleY);

      return { x, y };
    },
    [canvasWidth, canvasHeight]
  );

  // Redraw viewport whenever layers, adjustments, or before/after changes
  const renderViewport = useCallback(() => {
    const vCanvas = viewportCanvasRef.current;
    if (!vCanvas) return;
    vCanvas.width = canvasWidth;
    vCanvas.height = canvasHeight;
    const vCtx = vCanvas.getContext('2d');
    if (!vCtx) return;

    vCtx.clearRect(0, 0, canvasWidth, canvasHeight);

    // 1. Composite all visible layers into a buffer
    const compCanvas = document.createElement('canvas');
    compCanvas.width = canvasWidth;
    compCanvas.height = canvasHeight;
    const compCtx = compCanvas.getContext('2d')!;

    // Render layers bottom-to-top (layers array is top-to-bottom)
    const reversed = [...layers].reverse();
    for (const l of reversed) {
      if (!l.visible) continue;
      compCtx.save();
      compCtx.globalAlpha = l.opacity;
      compCtx.globalCompositeOperation = l.blendMode as GlobalCompositeOperation;
      compCtx.drawImage(l.canvas, l.x, l.y, l.width, l.height);
      compCtx.restore();
    }

    if (beforeAfterMode) {
      // Split view: Left = Original (unadjusted bottom layer), Right = Adjusted composite
      const splitX = Math.round((canvasWidth * beforeAfterSplit) / 100);

      // Draw original on entire canvas
      const baseLayer = layers[layers.length - 1];
      if (baseLayer) {
        vCtx.drawImage(baseLayer.canvas, 0, 0);
      }

      // Draw adjusted on right section with clipping
      vCtx.save();
      vCtx.beginPath();
      vCtx.rect(splitX, 0, canvasWidth - splitX, canvasHeight);
      vCtx.clip();

      const adjustedCanvas = document.createElement('canvas');
      adjustedCanvas.width = canvasWidth;
      adjustedCanvas.height = canvasHeight;
      const adjCtx = adjustedCanvas.getContext('2d')!;
      applyLightroomAdjustments(compCtx, adjCtx, canvasWidth, canvasHeight, adjustments);
      vCtx.drawImage(adjustedCanvas, 0, 0);
      vCtx.restore();

      // Draw divider line
      vCtx.save();
      vCtx.strokeStyle = '#00d2ff';
      vCtx.lineWidth = 2;
      vCtx.beginPath();
      vCtx.moveTo(splitX, 0);
      vCtx.lineTo(splitX, canvasHeight);
      vCtx.stroke();
      vCtx.restore();
    } else {
      // Normal mode: apply Lightroom adjustments to composited buffer
      applyLightroomAdjustments(compCtx, vCtx, canvasWidth, canvasHeight, adjustments);
    }

    // 2. Draw selection marquee overlay if present
    if (selectionRect && (selectionRect.w !== 0 || selectionRect.h !== 0)) {
      vCtx.save();
      vCtx.strokeStyle = '#00d2ff';
      vCtx.lineWidth = 2;
      vCtx.setLineDash([4, 4]);
      vCtx.strokeRect(selectionRect.x, selectionRect.y, selectionRect.w, selectionRect.h);
      vCtx.restore();
    }

    // 3. Draw grid overlay if enabled
    if (showGrid) {
      vCtx.save();
      vCtx.strokeStyle = 'rgba(255, 255, 255, 0.15)';
      vCtx.lineWidth = 1;
      const gridSize = 80;
      for (let x = gridSize; x < canvasWidth; x += gridSize) {
        vCtx.beginPath();
        vCtx.moveTo(x, 0);
        vCtx.lineTo(x, canvasHeight);
        vCtx.stroke();
      }
      for (let y = gridSize; y < canvasHeight; y += gridSize) {
        vCtx.beginPath();
        vCtx.moveTo(0, y);
        vCtx.lineTo(canvasWidth, y);
        vCtx.stroke();
      }
      vCtx.restore();
    }
  }, [layers, adjustments, canvasWidth, canvasHeight, beforeAfterMode, beforeAfterSplit, selectionRect, showGrid]);

  useEffect(() => {
    renderViewport();
  }, [renderViewport]);

  // Pointer interactions for Drawing / Editing
  const handlePointerDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    // If middle click or space key or move tool with Alt, start panning
    if (e.button === 1 || e.altKey || activeTool === 'move') {
      setIsPanning(true);
      setPanStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
      return;
    }

    const coords = getCanvasCoords(e);
    if (!coords) return;

    if (activeTool === 'eyedropper') {
      // Pick color from composite
      const vCanvas = viewportCanvasRef.current;
      if (vCanvas) {
        const ctx = vCanvas.getContext('2d')!;
        const p = ctx.getImageData(coords.x, coords.y, 1, 1).data;
        const hex = `#${((1 << 24) + (p[0] << 16) + (p[1] << 8) + p[2]).toString(16).slice(1)}`;
        setBrushSettings((prev) => ({ ...prev, color: hex }));
        setPickedColor(hex);
      }
      return;
    }

    if (activeTool === 'marquee_rect') {
      setSelectionStart(coords);
      setSelectionRect({ x: coords.x, y: coords.y, w: 0, h: 0 });
      setIsDrawing(true);
      return;
    }

    if (!selectedLayer || selectedLayer.locked || !selectedLayer.visible) {
      return;
    }

    setIsDrawing(true);
    setLastPos(coords);

    // Apply immediate single stamp stroke
    applyToolStroke(coords, coords);
  };

  const handlePointerMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (isPanning) {
      setPan({ x: e.clientX - panStart.x, y: e.clientY - panStart.y });
      return;
    }

    const coords = getCanvasCoords(e);
    if (!coords) return;

    if (isDrawing) {
      if (activeTool === 'marquee_rect' && selectionStart) {
        const w = coords.x - selectionStart.x;
        const h = coords.y - selectionStart.y;
        setSelectionRect({
          x: w < 0 ? coords.x : selectionStart.x,
          y: h < 0 ? coords.y : selectionStart.y,
          w: Math.abs(w),
          h: Math.abs(h),
        });
        renderViewport();
        return;
      }

      if (lastPos && selectedLayer && !selectedLayer.locked) {
        applyToolStroke(lastPos, coords);
        setLastPos(coords);
      }
    }
  };

  const handlePointerUp = () => {
    if (isDrawing && activeTool !== 'marquee_rect') {
      pushHistory();
    }
    setIsDrawing(false);
    setIsPanning(false);
    setLastPos(null);
  };

  // Tool brush stroke execution on active layer canvas
  const applyToolStroke = (from: { x: number; y: number }, to: { x: number; y: number }) => {
    if (!selectedLayer) return;
    const ctx = selectedLayer.canvas.getContext('2d');
    if (!ctx) return;

    ctx.save();

    if (activeTool === 'brush') {
      ctx.globalCompositeOperation = 'source-over';
      ctx.strokeStyle = brushSettings.color;
      ctx.fillStyle = brushSettings.color;
      ctx.lineWidth = brushSettings.size;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.globalAlpha = brushSettings.opacity;

      ctx.beginPath();
      ctx.moveTo(from.x, from.y);
      ctx.lineTo(to.x, to.y);
      ctx.stroke();
    } else if (activeTool === 'eraser') {
      ctx.globalCompositeOperation = 'destination-out';
      ctx.lineWidth = brushSettings.size;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.globalAlpha = brushSettings.opacity;

      ctx.beginPath();
      ctx.moveTo(from.x, from.y);
      ctx.lineTo(to.x, to.y);
      ctx.stroke();
    } else if (activeTool === 'dodge' || activeTool === 'burn') {
      // Dodge lightens, Burn darkens
      ctx.globalCompositeOperation = activeTool === 'dodge' ? 'screen' : 'multiply';
      ctx.strokeStyle = activeTool === 'dodge' ? 'rgba(255, 255, 255, 0.2)' : 'rgba(0, 0, 0, 0.2)';
      ctx.lineWidth = brushSettings.size;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';

      ctx.beginPath();
      ctx.moveTo(from.x, from.y);
      ctx.lineTo(to.x, to.y);
      ctx.stroke();
    } else if (activeTool === 'bucket') {
      ctx.fillStyle = brushSettings.color;
      ctx.fillRect(0, 0, canvasWidth, canvasHeight);
    }

    ctx.restore();
    renderViewport();
  };

  // Zoom handlers
  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const factor = e.deltaY < 0 ? 1.1 : 0.9;
    setZoom((prev) => Math.max(0.15, Math.min(5.0, prev * factor)));
  };

  return (
    <div
      ref={containerRef}
      onWheel={handleWheel}
      className="relative flex-1 bg-[#090b0e] overflow-hidden flex items-center justify-center select-none"
    >
      {/* Canvas Viewport Surface */}
      <div
        style={{
          transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
          transformOrigin: 'center center',
          transition: isPanning || isDrawing ? 'none' : 'transform 0.1s ease-out',
        }}
        className="relative shadow-2xl rounded-sm overflow-hidden bg-checkerboard cursor-crosshair border border-[#1f242e]"
      >
        <canvas
          ref={viewportCanvasRef}
          onMouseDown={handlePointerDown}
          onMouseMove={handlePointerMove}
          onMouseUp={handlePointerUp}
          onMouseLeave={handlePointerUp}
          className="block"
          style={{ width: `${canvasWidth}px`, height: `${canvasHeight}px` }}
        />
      </div>

      {/* Floating Canvas Quick View Controls Bar */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-1.5 px-3 py-1.5 bg-[#14171d]/90 backdrop-blur-md rounded-xl border border-[#232833] shadow-lg text-xs text-slate-300 z-20">
        <button
          onClick={() => setZoom((z) => Math.max(0.2, z * 0.85))}
          title="Zoom Out"
          className="p-1 hover:text-white rounded hover:bg-[#1f242e] transition-colors"
        >
          <ZoomOut className="w-3.5 h-3.5" />
        </button>

        <span className="font-mono text-[11px] px-1 text-slate-400">
          {Math.round(zoom * 100)}%
        </span>

        <button
          onClick={() => setZoom((z) => Math.min(4.0, z * 1.15))}
          title="Zoom In"
          className="p-1 hover:text-white rounded hover:bg-[#1f242e] transition-colors"
        >
          <ZoomIn className="w-3.5 h-3.5" />
        </button>

        <span className="w-px h-3.5 bg-[#2a303d] mx-0.5" />

        <button
          onClick={resetView}
          title="Fit Canvas"
          className="px-2 py-0.5 text-[10px] font-mono text-slate-400 hover:text-white rounded hover:bg-[#1f242e] transition-colors"
        >
          FIT
        </button>

        <button
          onClick={() => {
            setZoom(1);
            setPan({ x: 0, y: 0 });
          }}
          title="100% 1:1 Actual Pixels"
          className="px-2 py-0.5 text-[10px] font-mono text-slate-400 hover:text-white rounded hover:bg-[#1f242e] transition-colors"
        >
          100%
        </button>

        <span className="w-px h-3.5 bg-[#2a303d] mx-0.5" />

        {/* Before / After toggle */}
        <button
          onClick={() => setBeforeAfterMode(!beforeAfterMode)}
          title="Before / After Comparison"
          className={`px-2 py-0.5 rounded text-[10px] font-mono flex items-center gap-1 transition-colors ${
            beforeAfterMode ? 'bg-[#00d2ff] text-black font-bold' : 'text-slate-400 hover:text-white hover:bg-[#1f242e]'
          }`}
        >
          <Columns className="w-3 h-3" />
          <span>B/A</span>
        </button>

        {/* Grid toggle */}
        <button
          onClick={() => setShowGrid(!showGrid)}
          title="Toggle Alignment Grid"
          className={`p-1 rounded transition-colors ${
            showGrid ? 'text-[#00d2ff] bg-[#1f242e]' : 'text-slate-400 hover:text-white hover:bg-[#1f242e]'
          }`}
        >
          <Grid className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Floating Split Slider Bar when in Before/After Mode */}
      {beforeAfterMode && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 flex items-center gap-3 px-4 py-2 bg-[#14171d]/95 backdrop-blur-md rounded-xl border border-[#282e3b] shadow-xl text-xs z-20">
          <span className="text-[11px] font-mono text-slate-400">ORIGINAL</span>
          <input
            type="range"
            min="5"
            max="95"
            value={beforeAfterSplit}
            onChange={(e) => setBeforeAfterSplit(parseInt(e.target.value))}
            className="w-36 h-1.5 bg-[#232833] rounded-lg appearance-none cursor-pointer"
          />
          <span className="text-[11px] font-mono text-[#00d2ff]">EDITED</span>
        </div>
      )}

      {/* Active Eyedropper Color Preview Badge */}
      {pickedColor && (
        <div className="absolute top-4 right-4 flex items-center gap-2 px-3 py-1.5 bg-[#14171d] rounded-lg border border-[#2a303d] text-xs">
          <span className="w-3.5 h-3.5 rounded-full border border-white/20" style={{ backgroundColor: pickedColor }} />
          <span className="font-mono text-slate-300">{pickedColor.toUpperCase()}</span>
        </div>
      )}
    </div>
  );
};
