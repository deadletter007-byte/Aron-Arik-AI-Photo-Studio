import React from 'react';
import { useStudio } from '../../context/StudioContext';
import {
  Layers,
  Sliders,
  Palette,
  Sparkles,
  Wand2,
  FolderOpen,
  ArrowRight,
  Shield,
  Zap,
  Cpu,
  Monitor,
  Smartphone,
} from 'lucide-react';
import { ASSETS } from '../../utils/assets';

export const HomeWorkspace: React.FC = () => {
  const {
    setCurrentTab,
    projectName,
    canvasWidth,
    canvasHeight,
    layers,
    settings,
    updateSettings,
    loadSampleProject,
  } = useStudio();

  const workspaces = [
    {
      id: 'photoshop' as const,
      title: 'Photoshop Studio',
      badge: 'LAYER-BASED ENGINE',
      description: 'Multiple layers, blending modes, soft/hard brushes, clone stamp, healing, eraser, and marquee selection tools.',
      icon: <Layers className="w-5 h-5 text-[#00d2ff]" />,
      actionText: 'Open Photoshop Canvas',
    },
    {
      id: 'lightroom' as const,
      title: 'Lightroom Develop',
      badge: 'NON-DESTRUCTIVE COLOR',
      description: 'Exposure, contrast, highlights, shadows, Kelvin temperature, HSL color mixer, RGB tone curves, and one-tap pro presets.',
      icon: <Sliders className="w-5 h-5 text-[#00d2ff]" />,
      actionText: 'Open Lightroom Develop',
    },
    {
      id: 'express' as const,
      title: 'Adobe Express Design',
      badge: 'GRAPHIC COMPOSITION',
      description: 'Social media aspect ratios (Instagram, TikTok, YouTube), typographic templates, vector shapes, badges, and layout tools.',
      icon: <Palette className="w-5 h-5 text-[#00d2ff]" />,
      actionText: 'Open Design Studio',
    },
    {
      id: 'assistant' as const,
      title: 'AI Assistant Studio',
      badge: 'GEMINI 3.8 FLASH VISION',
      description: 'Visual analysis of lighting and composition, natural-language editing commands executed directly on canvas, and prompt generator.',
      icon: <Sparkles className="w-5 h-5 text-[#00d2ff]" />,
      actionText: 'Chat with AI Assistant',
    },
    {
      id: 'aitools' as const,
      title: 'AI Tools Suite',
      badge: 'NEURAL CUTOUT & INPAINT',
      description: 'Automatic alpha background removal, environment replacement, portrait skin smoothing with pore preservation, and 4K upscaler.',
      icon: <Wand2 className="w-5 h-5 text-[#00d2ff]" />,
      actionText: 'Launch AI Tools',
    },
    {
      id: 'projects' as const,
      title: 'Projects & Import',
      badge: 'ARCHIVE MANAGEMENT',
      description: 'Import camera photos, load sample studio artboards, export .AARK project archives, and manage multi-layer sessions.',
      icon: <FolderOpen className="w-5 h-5 text-[#00d2ff]" />,
      actionText: 'View Projects',
    },
  ];

  return (
    <div className="flex-1 overflow-y-auto bg-[#0d0f12] p-4 sm:p-6 lg:p-8">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Top Brand Header with Official Uploaded Logo */}
        <div className="flex items-center gap-4 p-4 rounded-2xl bg-[#121418] border border-[#20252e] shadow-md">
          <div className="w-16 h-16 sm:w-20 sm:h-20 aspect-square rounded-2xl overflow-hidden bg-[#0d0f12] border border-[#2b313d] shadow-lg shrink-0 flex items-center justify-center p-1">
            <img
              src={ASSETS.logo}
              alt="Aron &amp; Arik Official Logo"
              className="w-full h-full object-contain"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <h2 className="text-lg sm:text-2xl font-extrabold text-white tracking-tight truncate">
                Aron &amp; Arik AI Photo Studio
              </h2>
              <span className="hidden sm:inline text-[10px] font-mono text-[#00d2ff] bg-[#00d2ff]/10 border border-[#00d2ff]/30 px-2 py-0.5 rounded">
                OFFICIAL BRAND
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1 line-clamp-1">
              Samsung Galaxy S21+ (SM-G996U) · Android 15 / One UI 7 Native &amp; Pro Workstation
            </p>
          </div>
        </div>

        {/* Hero Section */}
        <div className="relative rounded-3xl bg-[#13161c] border border-[#20252e] p-6 sm:p-8 overflow-hidden shadow-2xl">
          {/* Subtle Ambient Glow */}
          <div className="absolute top-0 right-0 w-96 h-96 bg-[#00d2ff]/5 rounded-full blur-3xl pointer-events-none" />

          <div className="relative flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="space-y-4 max-w-2xl text-left">
              <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
                <span className="w-2 h-2 rounded-full bg-[#00d2ff]" />
                <span>NATIVE ANDROID &amp; DESKTOP PHOTO EDITING SUITE</span>
                <span aria-hidden="true">·</span>
                <span>ONE UI 7 / ANDROID 15</span>
              </div>

              <h1 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight leading-tight">
                Aron &amp; Arik <span className="text-[#00d2ff]">AI Photo Studio</span>
              </h1>

              <p className="text-sm text-slate-300 leading-relaxed">
                The unified creative studio combining Photoshop layer compositing, Lightroom photo development, Adobe Express graphic design, and Gemini/ChatGPT multimodal artificial intelligence. Built for Samsung Galaxy S21+ (SM-G996U) and high-performance desktop displays.
              </p>

              <div className="flex flex-wrap items-center gap-3 pt-2">
                <button
                  onClick={() => setCurrentTab('photoshop')}
                  className="px-5 py-2.5 rounded-xl bg-[#00d2ff] hover:bg-[#38dcff] text-black font-bold text-xs flex items-center gap-2 transition-all shadow-sm cursor-pointer"
                >
                  <Layers className="w-4 h-4" />
                  <span>Start Editing</span>
                </button>

                <button
                  onClick={() => setCurrentTab('assistant')}
                  className="px-5 py-2.5 rounded-xl bg-[#1b202a] hover:bg-[#252c3a] text-white border border-[#2d3545] font-semibold text-xs flex items-center gap-2 transition-all cursor-pointer"
                >
                  <Sparkles className="w-4 h-4 text-[#00d2ff]" />
                  <span>AI Image Consultant</span>
                </button>

                <button
                  onClick={() => updateSettings({ deviceSimMode: !settings.deviceSimMode })}
                  className="px-4 py-2.5 rounded-xl bg-[#161920] hover:bg-[#1e232d] text-slate-300 border border-[#252b37] text-xs font-mono flex items-center gap-2 transition-colors"
                >
                  {settings.deviceSimMode ? (
                    <>
                      <Monitor className="w-3.5 h-3.5 text-[#00d2ff]" />
                      <span>Switch to Pro Desktop Mode</span>
                    </>
                  ) : (
                    <>
                      <Smartphone className="w-3.5 h-3.5 text-[#00d2ff]" />
                      <span>Switch to Galaxy S21+ Mode</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Official 3D AI Logo Showcase (Exact proportions, colors & shape preserved) */}
            <div className="w-40 h-40 sm:w-52 sm:h-52 aspect-square rounded-3xl overflow-hidden border border-[#2c3340] shadow-2xl bg-[#0e1014] shrink-0 p-2 flex items-center justify-center">
              <img
                src={ASSETS.logo}
                alt="Aron &amp; Arik Official Brand Logo"
                className="w-full h-full object-contain"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
        </div>

        {/* Studio Session Status Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="p-4 rounded-2xl bg-[#13161c] border border-[#20252e]">
            <span className="text-[11px] font-mono text-slate-400">ACTIVE ARTBOARD</span>
            <p className="text-sm font-bold text-white mt-1 truncate">{projectName}</p>
          </div>
          <div className="p-4 rounded-2xl bg-[#13161c] border border-[#20252e]">
            <span className="text-[11px] font-mono text-slate-400">RESOLUTION</span>
            <p className="text-sm font-bold text-[#00d2ff] font-mono mt-1">
              {canvasWidth} × {canvasHeight}
            </p>
          </div>
          <div className="p-4 rounded-2xl bg-[#13161c] border border-[#20252e]">
            <span className="text-[11px] font-mono text-slate-400">COMPOSITE LAYERS</span>
            <p className="text-sm font-bold text-white font-mono mt-1">{layers.length} Layers</p>
          </div>
          <div className="p-4 rounded-2xl bg-[#13161c] border border-[#20252e]">
            <span className="text-[11px] font-mono text-slate-400">TARGET HARDWARE</span>
            <p className="text-sm font-bold text-slate-200 font-mono mt-1">SM-G996U S21+</p>
          </div>
        </div>

        {/* Feature Workspaces Grid */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-white tracking-tight">Studio Workspaces</h2>
            <span className="text-xs text-slate-400 font-mono">6 SPECIALIZED MODULES</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {workspaces.map((ws) => (
              <div
                key={ws.id}
                onClick={() => setCurrentTab(ws.id)}
                className="group p-5 rounded-2xl bg-[#13161c] border border-[#20252e] hover:border-[#00d2ff]/60 transition-all cursor-pointer flex flex-col justify-between space-y-4 hover:shadow-xl hover:shadow-[#00d2ff]/5"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="w-10 h-10 rounded-xl bg-[#1a1f29] border border-[#282f3d] flex items-center justify-center group-hover:scale-105 transition-transform">
                      {ws.icon}
                    </div>
                    <span className="text-[10px] font-mono text-[#00d2ff] bg-[#00d2ff]/10 px-2 py-0.5 rounded">
                      {ws.badge}
                    </span>
                  </div>

                  <div>
                    <h3 className="text-base font-bold text-white group-hover:text-[#00d2ff] transition-colors">
                      {ws.title}
                    </h3>
                    <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                      {ws.description}
                    </p>
                  </div>
                </div>

                <div className="pt-3 border-t border-[#1e232c] flex items-center justify-between text-xs font-semibold text-slate-300 group-hover:text-white">
                  <span>{ws.actionText}</span>
                  <ArrowRight className="w-3.5 h-3.5 text-[#00d2ff] group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
