import React, { useState, useRef, useEffect } from 'react';
import { useStudio } from '../../context/StudioContext';
import { StudioCanvas } from '../canvas/StudioCanvas';
import {
  Sparkles,
  Send,
  Bot,
  User,
  Wand2,
  Sliders,
  Layers,
  Image as ImageIcon,
  CheckCircle,
  AlertCircle,
  Cpu,
  RefreshCw,
} from 'lucide-react';
import { ChatMessage, AiProvider } from '../../types';

export const AssistantWorkspace: React.FC = () => {
  const {
    settings,
    updateSettings,
    getFlattenedAdjustedCanvas,
    setAdjustments,
    pushHistory,
    setCurrentTab,
  } = useStudio();

  const [provider, setProvider] = useState<AiProvider>(settings.aiProvider || 'gemini');
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'assistant',
      content: `Welcome to Aron & Arik AI Studio. I am your specialized photography and digital imaging consultant powered by ${
        provider === 'gemini' ? 'Gemini 3.8 Flash Vision' : 'ChatGPT (GPT-4o mini)'
      }.\n\nYou can ask me to analyze the active canvas, suggest precise Lightroom tone slider numbers, write background replacement prompts, or translate natural-language commands directly into image edits.`,
      timestamp: Date.now(),
    },
  ]);

  const [inputPrompt, setInputPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [includeCanvasSnapshot, setIncludeCanvasSnapshot] = useState(true);
  const [status, setStatus] = useState<'connected' | 'unconfigured' | 'error'>('connected');

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, loading]);

  // Send message to server AI endpoint
  const handleSendMessage = async (textToSend?: string) => {
    const text = textToSend || inputPrompt;
    if (!text.trim() || loading) return;

    let snapshotBase64: string | undefined = undefined;
    if (includeCanvasSnapshot) {
      try {
        const c = getFlattenedAdjustedCanvas();
        snapshotBase64 = c.toDataURL('image/jpeg', 0.8);
      } catch (e) {
        console.warn('Could not snapshot canvas:', e);
      }
    }

    const userMsg: ChatMessage = {
      id: `user_${Date.now()}`,
      role: 'user',
      content: text,
      timestamp: Date.now(),
      imageUrl: snapshotBase64,
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputPrompt('');
    setLoading(true);

    try {
      if (provider === 'gemini') {
        const res = await fetch('/api/ai/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            message: text,
            imageBase64: snapshotBase64,
            history: messages.slice(-6).map((m) => ({
              role: m.role,
              content: m.content,
            })),
            customApiKey: settings.geminiApiKey || undefined,
          }),
        });

        const data = await res.json();
        if (!res.ok) {
          throw new Error(data.error || 'Failed to get response from Gemini.');
        }

        // Check if reply contains adjustment suggestions
        const assistantMsg: ChatMessage = {
          id: `ai_${Date.now()}`,
          role: 'assistant',
          content: data.reply,
          timestamp: Date.now(),
        };
        setMessages((prev) => [...prev, assistantMsg]);
        setStatus('connected');
      } else {
        // OpenAI / ChatGPT provider
        const res = await fetch('/api/ai/openai/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            message: text,
            imageBase64: snapshotBase64,
            apiKey: settings.openaiApiKey,
          }),
        });

        const data = await res.json();
        if (!res.ok) {
          throw new Error(data.error || 'OpenAI error.');
        }

        const assistantMsg: ChatMessage = {
          id: `ai_${Date.now()}`,
          role: 'assistant',
          content: data.reply,
          timestamp: Date.now(),
        };
        setMessages((prev) => [...prev, assistantMsg]);
        setStatus('connected');
      }
    } catch (err: any) {
      setMessages((prev) => [
        ...prev,
        {
          id: `err_${Date.now()}`,
          role: 'assistant',
          content: `⚠️ Error: ${err.message}`,
          timestamp: Date.now(),
        },
      ]);
      setStatus('error');
    } finally {
      setLoading(false);
    }
  };

  // Quick Action: Deep Image Analysis
  const handleDeepAnalysis = async () => {
    setLoading(true);
    try {
      const c = getFlattenedAdjustedCanvas();
      const base64 = c.toDataURL('image/jpeg', 0.85);

      const res = await fetch('/api/ai/analyze-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: base64,
          customApiKey: settings.geminiApiKey || undefined,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Analysis failed.');

      const formatted = `### 🔍 AI Visual & Lighting Diagnostic
**Subject:** ${data.subject || 'Detected visual subject'}
**Summary:** ${data.summary || ''}

**Lighting & Dynamic Range:** ${data.lighting || 'Balanced'}
**Color Mood:** ${data.colorMood || 'Neutral'}

**Recommended Tone Sliders:**
- Exposure: ${data.suggestedAdjustments?.exposure || 0} EV
- Contrast: ${data.suggestedAdjustments?.contrast || 0}
- Highlights: ${data.suggestedAdjustments?.highlights || 0}
- Shadows: ${data.suggestedAdjustments?.shadows || 0}
- Temperature: ${data.suggestedAdjustments?.temperature || 0}

**Best Matched Preset:** ${data.bestPreset || 'Studio Portrait'}`;

      const aiMsg: ChatMessage = {
        id: `analysis_${Date.now()}`,
        role: 'assistant',
        content: formatted,
        timestamp: Date.now(),
        suggestedAdjustments: data.suggestedAdjustments,
      };

      setMessages((prev) => [...prev, aiMsg]);
    } catch (e: any) {
      setMessages((prev) => [
        ...prev,
        {
          id: `err_${Date.now()}`,
          role: 'assistant',
          content: `⚠️ Image analysis notice: ${e.message}`,
          timestamp: Date.now(),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  // Quick Action: Natural Language Command
  const handleExecuteCommand = async (command: string) => {
    setLoading(true);
    try {
      const res = await fetch('/api/ai/parse-command', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          command,
          customApiKey: settings.geminiApiKey || undefined,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Command interpretation failed.');

      if (data.adjustments) {
        setAdjustments((prev) => ({
          ...prev,
          ...data.adjustments,
        }));
        pushHistory();
      }

      setMessages((prev) => [
        ...prev,
        {
          id: `cmd_user_${Date.now()}`,
          role: 'user',
          content: command,
          timestamp: Date.now(),
        },
        {
          id: `cmd_ai_${Date.now()}`,
          role: 'assistant',
          content: `✨ ${data.explanation || 'Applied adjustments to canvas.'}`,
          timestamp: Date.now(),
        },
      ]);
    } catch (e: any) {
      setMessages((prev) => [
        ...prev,
        {
          id: `err_${Date.now()}`,
          role: 'assistant',
          content: `Could not execute command: ${e.message}`,
          timestamp: Date.now(),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-[#0d0f12] overflow-hidden">
      {/* Top Bar with Provider Selector */}
      <div className="h-10 px-4 bg-[#121418] border-b border-[#20252e] flex items-center justify-between text-xs text-slate-300 shrink-0">
        <div className="flex items-center gap-3">
          <Sparkles className="w-3.5 h-3.5 text-[#00d2ff]" />
          <span className="font-semibold text-white font-mono text-[11px]">AI ASSISTANT STUDIO</span>

          <span className="w-px h-3.5 bg-[#252b37]" />

          {/* Provider Selector */}
          <div className="flex items-center gap-1 bg-[#181c24] border border-[#252b37] rounded-md p-0.5 text-[11px]">
            <button
              onClick={() => {
                setProvider('gemini');
                updateSettings({ aiProvider: 'gemini' });
              }}
              className={`px-2.5 py-0.5 rounded transition-colors ${
                provider === 'gemini'
                  ? 'bg-[#00d2ff] text-black font-semibold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Gemini 3.8 Flash
            </button>
            <button
              onClick={() => {
                setProvider('openai');
                updateSettings({ aiProvider: 'openai' });
              }}
              className={`px-2.5 py-0.5 rounded transition-colors ${
                provider === 'openai'
                  ? 'bg-[#00d2ff] text-black font-semibold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              ChatGPT (OpenAI)
            </button>
          </div>
        </div>

        {/* Status Indicator */}
        <div className="flex items-center gap-2 text-[10px] font-mono text-slate-400">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
          <span>Active Vision Session</span>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* Left: Chat & Commands Column */}
        <div className="w-96 bg-[#121418] border-r border-[#20252e] flex flex-col shrink-0">
          {/* Quick AI Prompts Carousel */}
          <div className="p-2.5 border-b border-[#20252e] bg-[#0e1014] space-y-1.5">
            <p className="text-[10px] font-mono text-slate-400">QUICK INTELLIGENCE ACTIONS</p>
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-[11px]">
              <button
                onClick={handleDeepAnalysis}
                disabled={loading}
                className="px-2 py-1 rounded bg-[#161a22] border border-[#232936] hover:border-[#00d2ff] text-slate-300 hover:text-white whitespace-nowrap shrink-0 flex items-center gap-1"
              >
                <Wand2 className="w-3 h-3 text-[#00d2ff]" />
                <span>Deep Vision Analysis</span>
              </button>
              <button
                onClick={() => handleExecuteCommand('Make this look like a warm Portra film photograph with soft highlights')}
                disabled={loading}
                className="px-2 py-1 rounded bg-[#161a22] border border-[#232936] hover:border-[#00d2ff] text-slate-300 hover:text-white whitespace-nowrap shrink-0"
              >
                Warm Portra Film
              </button>
              <button
                onClick={() => handleExecuteCommand('High contrast cinematic mood with deep crushed blacks and cyan tint')}
                disabled={loading}
                className="px-2 py-1 rounded bg-[#161a22] border border-[#232936] hover:border-[#00d2ff] text-slate-300 hover:text-white whitespace-nowrap shrink-0"
              >
                Cinematic Cyan
              </button>
            </div>
          </div>

          {/* Messages Stream */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex gap-2.5 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                {msg.role === 'assistant' && (
                  <div className="w-6 h-6 rounded-md bg-[#1a2333] border border-[#00d2ff]/40 flex items-center justify-center shrink-0 mt-0.5">
                    <Bot className="w-3.5 h-3.5 text-[#00d2ff]" />
                  </div>
                )}

                <div
                  className={`max-w-[85%] rounded-xl p-3 text-xs leading-relaxed space-y-2 ${
                    msg.role === 'user'
                      ? 'bg-[#00d2ff]/15 border border-[#00d2ff]/30 text-white'
                      : 'bg-[#161920] border border-[#222732] text-slate-200'
                  }`}
                >
                  {/* Attached Image Thumbnail */}
                  {msg.imageUrl && (
                    <div className="w-24 h-24 rounded-lg overflow-hidden border border-[#2a303d] mb-1">
                      <img src={msg.imageUrl} alt="" className="w-full h-full object-cover" />
                    </div>
                  )}

                  <div className="whitespace-pre-wrap">{msg.content}</div>

                  {/* Apply Suggested Adjustments button if available */}
                  {msg.suggestedAdjustments && (
                    <div className="pt-2 border-t border-[#262c38]">
                      <button
                        onClick={() => {
                          if (msg.suggestedAdjustments) {
                            setAdjustments((prev) => ({
                              ...prev,
                              ...msg.suggestedAdjustments,
                            }));
                            pushHistory();
                            setCurrentTab('lightroom');
                          }
                        }}
                        className="w-full py-1.5 px-3 rounded-lg bg-[#00d2ff] text-black font-semibold text-xs flex items-center justify-center gap-1.5 hover:bg-[#38dcff] transition-all"
                      >
                        <Sliders className="w-3 h-3" />
                        <span>Apply Suggested Tone to Lightroom</span>
                      </button>
                    </div>
                  )}
                </div>

                {msg.role === 'user' && (
                  <div className="w-6 h-6 rounded-md bg-[#232833] flex items-center justify-center shrink-0 mt-0.5">
                    <User className="w-3.5 h-3.5 text-slate-300" />
                  </div>
                )}
              </div>
            ))}

            {loading && (
              <div className="flex gap-2.5 items-center text-xs text-slate-400">
                <div className="w-6 h-6 rounded-md bg-[#1a2333] flex items-center justify-center">
                  <RefreshCw className="w-3.5 h-3.5 text-[#00d2ff] animate-spin" />
                </div>
                <span>Analyzing image &amp; synthesizing expert advice...</span>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Bottom Prompt Input */}
          <div className="p-3 border-t border-[#20252e] bg-[#0e1014] space-y-2">
            <div className="flex items-center justify-between text-[10px] font-mono text-slate-400">
              <label className="flex items-center gap-1.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={includeCanvasSnapshot}
                  onChange={(e) => setIncludeCanvasSnapshot(e.target.checked)}
                  className="rounded border-[#2a303d] bg-[#161920] accent-[#00d2ff]"
                />
                <span>Attach Live Canvas Frame</span>
              </label>
              <span>{provider.toUpperCase()}</span>
            </div>

            <div className="flex items-center gap-1.5 bg-[#161920] border border-[#262c37] rounded-xl p-1 focus-within:border-[#00d2ff] transition-colors">
              <input
                type="text"
                placeholder={
                  provider === 'gemini'
                    ? 'Ask Gemini about composition, lighting, or prompt...'
                    : 'Ask ChatGPT photo instructions...'
                }
                value={inputPrompt}
                onChange={(e) => setInputPrompt(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                className="flex-1 bg-transparent px-3 py-1.5 text-xs text-white placeholder-slate-500 outline-none"
              />
              <button
                onClick={() => handleSendMessage()}
                disabled={loading || !inputPrompt.trim()}
                className="p-2 rounded-lg bg-[#00d2ff] hover:bg-[#38dcff] text-black disabled:opacity-30 disabled:hover:bg-[#00d2ff] transition-colors cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* Right Canvas */}
        <StudioCanvas />
      </div>
    </div>
  );
};
