import React, { useState } from 'react';
import { useStudio } from '../../context/StudioContext';
import { StudioCanvas } from '../canvas/StudioCanvas';
import {
  Move,
  Brush,
  Eraser,
  Stamp,
  Crosshair,
  Sun,
  Moon,
  Droplet,
  Square,
  Circle,
  Crop,
  Pipette,
  PaintBucket,
  Type,
  Shapes,
  Plus,
  Copy,
  Trash2,
  Eye,
  EyeOff,
  Lock,
  Unlock,
  ChevronUp,
  ChevronDown,
  Layers,
  History,
  Scissors,
} from 'lucide-react';
import { PhotoshopTool, BlendMode } from '../../types';

export const PhotoshopWorkspace: React.FC = () => {
  const {
    activeTool,
    setActiveTool,
    brushSettings,
    setBrushSettings,
    layers,
    selectedLayerId,
    setSelectedLayerId,
    selectedLayer,
    addEmptyLayer,
    duplicateLayer,
    deleteLayer,
    reorderLayers,
    updateLayer,
    pushHistory,
  } = useStudio();

  const [activeRightTab, setActiveRightTab] = useState<'layers' | 'history'>('layers');

  const tools: Array<{ id: PhotoshopTool; label: string; icon: React.ReactNode }> = [
    { id: 'move', label: 'Move Tool (V)', icon: <Move className="w-4 h-4" /> },
    { id: 'marquee_rect', label: 'Marquee Rect (M)', icon: <Square className="w-4 h-4" /> },
    { id: 'brush', label: 'Brush Tool (B)', icon: <Brush className="w-4 h-4" /> },
    { id: 'eraser', label: 'Eraser Tool (E)', icon: <Eraser className="w-4 h-4" /> },
    { id: 'clone_stamp', label: 'Clone Stamp (S)', icon: <Stamp className="w-4 h-4" /> },
    { id: 'healing_brush', label: 'Healing Brush (J)', icon: <Crosshair className="w-4 h-4" /> },
    { id: 'dodge', label: 'Dodge Lighten (O)', icon: <Sun className="w-4 h-4" /> },
    { id: 'burn', label: 'Burn Darken (O)', icon: <Moon className="w-4 h-4" /> },
    { id: 'eyedropper', label: 'Eyedropper (I)', icon: <Pipette className="w-4 h-4" /> },
    { id: 'bucket', label: 'Paint Bucket (G)', icon: <PaintBucket className="w-4 h-4" /> },
    { id: 'text', label: 'Type Tool (T)', icon: <Type className="w-4 h-4" /> },
  ];

  const blendModes: BlendMode[] = [
    'source-over',
    'multiply',
    'screen',
    'overlay',
    'darken',
    'lighten',
    'color-dodge',
    'color-burn',
    'hard-light',
    'soft-light',
    'difference',
  ];

  return (
    <div className="flex-1 flex flex-col h-full bg-[#0d0f12] overflow-hidden">
      {/* Top Options Bar */}
      <div className="h-10 px-4 bg-[#121418] border-b border-[#20252e] flex items-center justify-between text-xs text-slate-300 shrink-0">
        <div className="flex items-center gap-4">
          <span className="font-semibold text-white capitalize font-mono text-[11px]">
            {activeTool.replace('_', ' ')}
          </span>

          <span className="w-px h-4 bg-[#262c37]" />

          {/* Brush Size Slider */}
          <div className="flex items-center gap-2">
            <span className="text-[11px] text-slate-400">Size</span>
            <input
              type="range"
              min="1"
              max="150"
              value={brushSettings.size}
              onChange={(e) =>
                setBrushSettings((prev) => ({ ...prev, size: parseInt(e.target.value) }))
              }
              className="w-20 h-1 bg-[#232833] rounded appearance-none cursor-pointer"
            />
            <span className="font-mono text-[10px] w-6">{brushSettings.size}px</span>
          </div>

          {/* Opacity Slider */}
          <div className="flex items-center gap-2">
            <span className="text-[11px] text-slate-400">Opacity</span>
            <input
              type="range"
              min="0.05"
              max="1"
              step="0.05"
              value={brushSettings.opacity}
              onChange={(e) =>
                setBrushSettings((prev) => ({ ...prev, opacity: parseFloat(e.target.value) }))
              }
              className="w-16 h-1 bg-[#232833] rounded appearance-none cursor-pointer"
            />
            <span className="font-mono text-[10px] w-7">
              {Math.round(brushSettings.opacity * 100)}%
            </span>
          </div>

          {/* Color Picker */}
          <div className="flex items-center gap-2">
            <span className="text-[11px] text-slate-400">Color</span>
            <input
              type="color"
              value={brushSettings.color}
              onChange={(e) =>
                setBrushSettings((prev) => ({ ...prev, color: e.target.value }))
              }
              className="w-5 h-5 rounded cursor-pointer border border-[#2b313d] bg-transparent"
            />
          </div>
        </div>

        {/* Selected Layer Info */}
        <div className="hidden sm:flex items-center gap-2 text-slate-400 text-[11px] font-mono">
          <span>Target:</span>
          <span className="text-[#00d2ff] font-medium truncate max-w-[140px]">
            {selectedLayer?.name || 'No Layer'}
          </span>
        </div>
      </div>

      {/* Main Studio Body: Left Tools + Center Canvas + Right Dock */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Vertical Photoshop Toolbar */}
        <div className="w-12 bg-[#121418] border-r border-[#20252e] flex flex-col items-center py-2 gap-1 shrink-0 z-10">
          {tools.map((t) => (
            <button
              key={t.id}
              onClick={() => setActiveTool(t.id)}
              title={t.label}
              className={`w-8 h-8 rounded-lg flex items-center justify-center transition-colors ${
                activeTool === t.id
                  ? 'bg-[#00d2ff] text-black font-bold shadow-sm'
                  : 'text-slate-400 hover:text-white hover:bg-[#1a1e26]'
              }`}
            >
              {t.icon}
            </button>
          ))}
        </div>

        {/* Center Interactive Canvas Viewport */}
        <StudioCanvas />

        {/* Right Dock: Layers & History Panels */}
        <div className="w-64 bg-[#121418] border-l border-[#20252e] flex flex-col shrink-0">
          {/* Panel Header Tabs */}
          <div className="flex items-center border-b border-[#20252e] bg-[#0e1014] text-xs">
            <button
              onClick={() => setActiveRightTab('layers')}
              className={`flex-1 py-2 text-center font-medium border-b-2 transition-colors ${
                activeRightTab === 'layers'
                  ? 'border-[#00d2ff] text-[#00d2ff] bg-[#14171d]'
                  : 'border-transparent text-slate-400 hover:text-white'
              }`}
            >
              Layers ({layers.length})
            </button>
            <button
              onClick={() => setActiveRightTab('history')}
              className={`flex-1 py-2 text-center font-medium border-b-2 transition-colors ${
                activeRightTab === 'history'
                  ? 'border-[#00d2ff] text-[#00d2ff] bg-[#14171d]'
                  : 'border-transparent text-slate-400 hover:text-white'
              }`}
            >
              History
            </button>
          </div>

          {activeRightTab === 'layers' ? (
            <div className="flex-1 flex flex-col overflow-hidden">
              {/* Layer Blend Mode & Opacity Controls */}
              {selectedLayer && (
                <div className="p-3 border-b border-[#20252e] bg-[#14171d] space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400 text-[11px]">Blend</span>
                    <select
                      value={selectedLayer.blendMode}
                      onChange={(e) =>
                        updateLayer(selectedLayer.id, { blendMode: e.target.value as BlendMode })
                      }
                      className="bg-[#1e232d] text-white border border-[#2b313d] rounded px-2 py-0.5 text-[11px] font-mono outline-none"
                    >
                      {blendModes.map((bm) => (
                        <option key={bm} value={bm}>
                          {bm}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="flex items-center justify-between gap-2">
                    <span className="text-slate-400 text-[11px]">Opacity</span>
                    <input
                      type="range"
                      min="0"
                      max="1"
                      step="0.05"
                      value={selectedLayer.opacity}
                      onChange={(e) =>
                        updateLayer(selectedLayer.id, { opacity: parseFloat(e.target.value) })
                      }
                      className="flex-1 h-1 bg-[#232833] rounded appearance-none cursor-pointer"
                    />
                    <span className="font-mono text-[10px] w-7 text-right">
                      {Math.round(selectedLayer.opacity * 100)}%
                    </span>
                  </div>
                </div>
              )}

              {/* Layer Stack Items List */}
              <div className="flex-1 overflow-y-auto p-2 space-y-1.5">
                {layers.map((layer, index) => {
                  const isSelected = layer.id === selectedLayerId;
                  return (
                    <div
                      key={layer.id}
                      onClick={() => setSelectedLayerId(layer.id)}
                      className={`flex items-center gap-2 p-2 rounded-lg border transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-[#1a1f28] border-[#00d2ff]/60 text-white'
                          : 'bg-[#14171d] border-[#222732] text-slate-300 hover:border-[#2f3644]'
                      }`}
                    >
                      {/* Visibility Toggle */}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          updateLayer(layer.id, { visible: !layer.visible });
                        }}
                        className="text-slate-400 hover:text-white"
                      >
                        {layer.visible ? (
                          <Eye className="w-3.5 h-3.5 text-[#00d2ff]" />
                        ) : (
                          <EyeOff className="w-3.5 h-3.5 text-slate-500" />
                        )}
                      </button>

                      {/* Small Canvas Thumbnail */}
                      <div className="w-8 h-8 rounded bg-checkerboard border border-[#2b313d] overflow-hidden shrink-0 flex items-center justify-center">
                        <img
                          src={layer.canvas.toDataURL('image/png')}
                          alt=""
                          className="w-full h-full object-cover"
                        />
                      </div>

                      {/* Layer Info */}
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-medium truncate">{layer.name}</p>
                        <p className="text-[10px] text-slate-400 font-mono">
                          {layer.type} · {Math.round(layer.opacity * 100)}%
                        </p>
                      </div>

                      {/* Lock Toggle */}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          updateLayer(layer.id, { locked: !layer.locked });
                        }}
                        className="text-slate-400 hover:text-white"
                      >
                        {layer.locked ? (
                          <Lock className="w-3 h-3 text-amber-400" />
                        ) : (
                          <Unlock className="w-3 h-3 opacity-20 hover:opacity-100" />
                        )}
                      </button>
                    </div>
                  );
                })}
              </div>

              {/* Layers Footer Actions */}
              <div className="p-2 border-t border-[#20252e] bg-[#0e1014] flex items-center justify-between">
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => addEmptyLayer()}
                    title="Add Blank Layer"
                    className="p-1.5 rounded hover:bg-[#1f242e] text-slate-300 hover:text-white transition-colors"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => selectedLayerId && duplicateLayer(selectedLayerId)}
                    disabled={!selectedLayerId}
                    title="Duplicate Layer"
                    className="p-1.5 rounded hover:bg-[#1f242e] text-slate-300 hover:text-white disabled:opacity-30 transition-colors"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => selectedLayerId && deleteLayer(selectedLayerId)}
                    disabled={layers.length <= 1 || !selectedLayerId}
                    title="Delete Layer"
                    className="p-1.5 rounded hover:bg-[#1f242e] text-slate-300 hover:text-red-400 disabled:opacity-30 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Move Layer Order */}
                {selectedLayerId && (
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => {
                        const idx = layers.findIndex((l) => l.id === selectedLayerId);
                        if (idx > 0) reorderLayers(idx, idx - 1);
                      }}
                      title="Move Layer Up"
                      className="p-1 rounded hover:bg-[#1f242e] text-slate-400 hover:text-white"
                    >
                      <ChevronUp className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => {
                        const idx = layers.findIndex((l) => l.id === selectedLayerId);
                        if (idx < layers.length - 1) reorderLayers(idx, idx + 1);
                      }}
                      title="Move Layer Down"
                      className="p-1 rounded hover:bg-[#1f242e] text-slate-400 hover:text-white"
                    >
                      <ChevronDown className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="flex-1 p-3 overflow-y-auto space-y-1.5 text-xs text-slate-300">
              <p className="text-[11px] font-mono text-slate-400 mb-2">HISTORY STACK (25 STEPS)</p>
              <div className="p-2 bg-[#1a1f28] rounded border border-[#00d2ff]/40 text-[#00d2ff] font-mono text-[11px]">
                ● Current Artboard State
              </div>
              <div className="p-2 bg-[#14171d] rounded border border-[#222732] text-slate-400 font-mono text-[11px]">
                ○ Brush Stroke
              </div>
              <div className="p-2 bg-[#14171d] rounded border border-[#222732] text-slate-400 font-mono text-[11px]">
                ○ Layer Visibility Change
              </div>
              <div className="p-2 bg-[#14171d] rounded border border-[#222732] text-slate-400 font-mono text-[11px]">
                ○ Initial Image Import
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
