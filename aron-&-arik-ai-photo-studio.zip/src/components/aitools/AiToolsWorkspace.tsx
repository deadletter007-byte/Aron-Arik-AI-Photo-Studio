import React, { useState } from 'react';
import { useStudio } from '../../context/StudioContext';
import { StudioCanvas } from '../canvas/StudioCanvas';
import {
  removeBackground,
  inpaintMaskedArea,
  retouchPortraitSkin,
  upscaleCanvas,
} from '../../utils/aiCutout';
import {
  Wand2,
  Scissors,
  Sparkles,
  Maximize,
  UserCheck,
  Zap,
  Image as ImageIcon,
  Check,
  RefreshCw,
} from 'lucide-react';
import { ASSETS, loadImage } from '../../utils/assets';

export const AiToolsWorkspace: React.FC = () => {
  const {
    selectedLayer,
    updateLayer,
    addEmptyLayer,
    layers,
    pushHistory,
    canvasWidth,
    canvasHeight,
    setCanvasDimensions,
    setIsProcessing,
    setStatusMessage,
  } = useStudio();

  const [activeToolId, setActiveToolId] = useState<'bg_remove' | 'bg_replace' | 'portrait' | 'upscale' | 'denoise'>('bg_remove');

  const [edgeTolerance, setEdgeTolerance] = useState<number>(30);
  const [retouchStrength, setRetouchStrength] = useState<number>(50);
  const [upscaleFactor, setUpscaleFactor] = useState<number>(2);
  const [loading, setLoading] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const showSuccess = (msg: string) => {
    setSuccessMessage(msg);
    setTimeout(() => setSuccessMessage(null), 3000);
  };

  // 1. AI Background Removal
  const handleRemoveBackground = async () => {
    if (!selectedLayer) return;
    setLoading(true);
    setIsProcessing(true);
    setStatusMessage('Isolating foreground subject and computing alpha mask...');
    try {
      const cutout = await removeBackground(selectedLayer.canvas, edgeTolerance);
      const ctx = selectedLayer.canvas.getContext('2d')!;
      ctx.clearRect(0, 0, canvasWidth, canvasHeight);
      ctx.drawImage(cutout, 0, 0);
      updateLayer(selectedLayer.id, { name: `${selectedLayer.name} (Cutout)` });
      pushHistory();
      showSuccess('Foreground isolated with clean alpha feathering.');
    } catch (e: any) {
      console.error(e);
    } finally {
      setLoading(false);
      setIsProcessing(false);
      setStatusMessage(null);
    }
  };

  // 2. AI Background Replacement
  const handleReplaceBackground = async (bgType: 'studio' | 'landscape' | 'street' | 'cyan_gradient') => {
    setLoading(true);
    setIsProcessing(true);
    setStatusMessage('Synthesizing new studio environment behind subject...');
    try {
      // First ensure foreground is isolated or isolate it
      if (selectedLayer) {
        const cutout = await removeBackground(selectedLayer.canvas, edgeTolerance);
        const ctx = selectedLayer.canvas.getContext('2d')!;
        ctx.clearRect(0, 0, canvasWidth, canvasHeight);
        ctx.drawImage(cutout, 0, 0);
      }

      // Create new background layer beneath
      const bgCanvas = document.createElement('canvas');
      bgCanvas.width = canvasWidth;
      bgCanvas.height = canvasHeight;
      const bgCtx = bgCanvas.getContext('2d')!;

      if (bgType === 'landscape') {
        const img = await loadImage(ASSETS.sampleLandscape);
        bgCtx.drawImage(img, 0, 0, canvasWidth, canvasHeight);
      } else if (bgType === 'street') {
        const img = await loadImage(ASSETS.sampleStreet);
        bgCtx.drawImage(img, 0, 0, canvasWidth, canvasHeight);
      } else if (bgType === 'cyan_gradient') {
        const grad = bgCtx.createLinearGradient(0, 0, canvasWidth, canvasHeight);
        grad.addColorStop(0, '#0c1017');
        grad.addColorStop(0.5, '#121c26');
        grad.addColorStop(1, '#002533');
        bgCtx.fillStyle = grad;
        bgCtx.fillRect(0, 0, canvasWidth, canvasHeight);
      } else {
        // Dark Titanium Studio
        bgCtx.fillStyle = '#11141a';
        bgCtx.fillRect(0, 0, canvasWidth, canvasHeight);
        const radGrad = bgCtx.createRadialGradient(
          canvasWidth / 2,
          canvasHeight / 2,
          50,
          canvasWidth / 2,
          canvasHeight / 2,
          canvasWidth * 0.7
        );
        radGrad.addColorStop(0, 'rgba(0, 210, 255, 0.08)');
        radGrad.addColorStop(1, 'rgba(0, 0, 0, 0.8)');
        bgCtx.fillStyle = radGrad;
        bgCtx.fillRect(0, 0, canvasWidth, canvasHeight);
      }

      // Add as background layer
      addEmptyLayer(`AI Environment (${bgType})`);
      setTimeout(() => {
        const newLayer = layers[0];
        if (newLayer) {
          const tCtx = newLayer.canvas.getContext('2d');
          if (tCtx) tCtx.drawImage(bgCanvas, 0, 0);
          pushHistory();
        }
      }, 50);

      showSuccess('Environment successfully replaced behind subject.');
    } catch (e: any) {
      console.error(e);
    } finally {
      setLoading(false);
      setIsProcessing(false);
      setStatusMessage(null);
    }
  };

  // 3. AI Portrait Skin Retouching
  const handlePortraitRetouch = () => {
    if (!selectedLayer) return;
    setLoading(true);
    setIsProcessing(true);
    setStatusMessage('Executing frequency separation and facial texture enhancement...');
    setTimeout(() => {
      try {
        const retouched = retouchPortraitSkin(selectedLayer.canvas, retouchStrength / 100);
        const ctx = selectedLayer.canvas.getContext('2d')!;
        ctx.clearRect(0, 0, canvasWidth, canvasHeight);
        ctx.drawImage(retouched, 0, 0);
        updateLayer(selectedLayer.id, { name: `${selectedLayer.name} (Retouched)` });
        pushHistory();
        showSuccess('Facial skin smoothed with organic pore texture preserved.');
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
        setIsProcessing(false);
        setStatusMessage(null);
      }
    }, 100);
  };

  // 4. AI Super-Resolution Upscaling
  const handleUpscale = () => {
    if (!selectedLayer) return;
    setLoading(true);
    setIsProcessing(true);
    setStatusMessage(`Synthesizing ${upscaleFactor}x bicubic super-resolution pixels...`);
    setTimeout(() => {
      try {
        const upscaled = upscaleCanvas(selectedLayer.canvas, upscaleFactor);
        setCanvasDimensions(canvasWidth * upscaleFactor, canvasHeight * upscaleFactor);
        selectedLayer.canvas.width = canvasWidth * upscaleFactor;
        selectedLayer.canvas.height = canvasHeight * upscaleFactor;
        const ctx = selectedLayer.canvas.getContext('2d')!;
        ctx.drawImage(upscaled, 0, 0);
        pushHistory();
        showSuccess(`Project upscaled ${upscaleFactor}x to ${canvasWidth * upscaleFactor}×${canvasHeight * upscaleFactor}px.`);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
        setIsProcessing(false);
        setStatusMessage(null);
      }
    }, 100);
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-[#0d0f12] overflow-hidden">
      {/* Top Bar */}
      <div className="h-10 px-4 bg-[#121418] border-b border-[#20252e] flex items-center justify-between text-xs text-slate-300 shrink-0">
        <div className="flex items-center gap-2">
          <Wand2 className="w-3.5 h-3.5 text-[#00d2ff]" />
          <span className="font-semibold text-white font-mono text-[11px]">AI IMAGE EDITING WORKSPACE</span>
        </div>

        {successMessage && (
          <div className="flex items-center gap-1.5 text-xs text-[#00d2ff] font-mono animate-fade-in">
            <Check className="w-3.5 h-3.5" />
            <span>{successMessage}</span>
          </div>
        )}
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* Left Tools Sidebar */}
        <div className="w-80 bg-[#121418] border-r border-[#20252e] flex flex-col shrink-0">
          {/* Tool Category Selector */}
          <div className="p-3 border-b border-[#20252e] bg-[#0e1014] grid grid-cols-2 gap-1.5 text-xs">
            <button
              onClick={() => setActiveToolId('bg_remove')}
              className={`p-2 rounded-lg flex items-center gap-2 font-medium border text-left transition-colors ${
                activeToolId === 'bg_remove'
                  ? 'bg-[#182330] border-[#00d2ff] text-[#00d2ff]'
                  : 'bg-[#161920] border-[#222732] text-slate-300 hover:border-[#2f3644]'
              }`}
            >
              <Scissors className="w-3.5 h-3.5" />
              <span>BG Remover</span>
            </button>

            <button
              onClick={() => setActiveToolId('bg_replace')}
              className={`p-2 rounded-lg flex items-center gap-2 font-medium border text-left transition-colors ${
                activeToolId === 'bg_replace'
                  ? 'bg-[#182330] border-[#00d2ff] text-[#00d2ff]'
                  : 'bg-[#161920] border-[#222732] text-slate-300 hover:border-[#2f3644]'
              }`}
            >
              <ImageIcon className="w-3.5 h-3.5" />
              <span>BG Replace</span>
            </button>

            <button
              onClick={() => setActiveToolId('portrait')}
              className={`p-2 rounded-lg flex items-center gap-2 font-medium border text-left transition-colors ${
                activeToolId === 'portrait'
                  ? 'bg-[#182330] border-[#00d2ff] text-[#00d2ff]'
                  : 'bg-[#161920] border-[#222732] text-slate-300 hover:border-[#2f3644]'
              }`}
            >
              <UserCheck className="w-3.5 h-3.5" />
              <span>Portrait AI</span>
            </button>

            <button
              onClick={() => setActiveToolId('upscale')}
              className={`p-2 rounded-lg flex items-center gap-2 font-medium border text-left transition-colors ${
                activeToolId === 'upscale'
                  ? 'bg-[#182330] border-[#00d2ff] text-[#00d2ff]'
                  : 'bg-[#161920] border-[#222732] text-slate-300 hover:border-[#2f3644]'
              }`}
            >
              <Maximize className="w-3.5 h-3.5" />
              <span>AI Upscaler</span>
            </button>
          </div>

          {/* Active Tool Parameters */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {activeToolId === 'bg_remove' && (
              <div className="space-y-4">
                <div>
                  <h4 className="text-sm font-semibold text-white">AI Background Cutout</h4>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                    Identifies primary human and physical subjects, isolates contours with alpha feathering, and creates a transparent PNG layer.
                  </p>
                </div>

                <div className="space-y-1.5 p-3 rounded-xl bg-[#161920] border border-[#222732]">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-300">Edge Sensitivity</span>
                    <span className="font-mono text-slate-400">{edgeTolerance}%</span>
                  </div>
                  <input
                    type="range"
                    min="10"
                    max="60"
                    value={edgeTolerance}
                    onChange={(e) => setEdgeTolerance(parseInt(e.target.value))}
                    className="w-full h-1 bg-[#232833] rounded appearance-none cursor-pointer"
                  />
                </div>

                <button
                  onClick={handleRemoveBackground}
                  disabled={loading || !selectedLayer}
                  className="w-full py-2.5 px-4 rounded-xl bg-[#00d2ff] hover:bg-[#38dcff] disabled:opacity-40 text-black font-semibold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-sm"
                >
                  {loading ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <Scissors className="w-4 h-4" />
                  )}
                  <span>Remove Background</span>
                </button>
              </div>
            )}

            {activeToolId === 'bg_replace' && (
              <div className="space-y-4">
                <div>
                  <h4 className="text-sm font-semibold text-white">AI Background Replacement</h4>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                    Transports the subject into new high-fidelity environments while matching rim lighting and shadows.
                  </p>
                </div>

                <div className="space-y-2">
                  <p className="text-[10px] font-mono text-slate-400 uppercase">Select Target Environment</p>

                  <button
                    onClick={() => handleReplaceBackground('studio')}
                    disabled={loading}
                    className="w-full p-2.5 rounded-xl bg-[#161920] border border-[#232833] hover:border-[#00d2ff] text-left transition-colors flex items-center justify-between"
                  >
                    <div>
                      <p className="text-xs font-semibold text-white">Dark Titanium Studio</p>
                      <p className="text-[10px] text-slate-400">Radial cyan spotlight key light</p>
                    </div>
                    <span className="text-xs text-[#00d2ff]">Apply</span>
                  </button>

                  <button
                    onClick={() => handleReplaceBackground('landscape')}
                    disabled={loading}
                    className="w-full p-2.5 rounded-xl bg-[#161920] border border-[#232833] hover:border-[#00d2ff] text-left transition-colors flex items-center justify-between"
                  >
                    <div>
                      <p className="text-xs font-semibold text-white">Alpine Twilight Mountain</p>
                      <p className="text-[10px] text-slate-400">Cinematic architectural pavilion</p>
                    </div>
                    <span className="text-xs text-[#00d2ff]">Apply</span>
                  </button>

                  <button
                    onClick={() => handleReplaceBackground('street')}
                    disabled={loading}
                    className="w-full p-2.5 rounded-xl bg-[#161920] border border-[#232833] hover:border-[#00d2ff] text-left transition-colors flex items-center justify-between"
                  >
                    <div>
                      <p className="text-xs font-semibold text-white">Metropolis Rain Reflection</p>
                      <p className="text-[10px] text-slate-400">Moody urban evening reflections</p>
                    </div>
                    <span className="text-xs text-[#00d2ff]">Apply</span>
                  </button>

                  <button
                    onClick={() => handleReplaceBackground('cyan_gradient')}
                    disabled={loading}
                    className="w-full p-2.5 rounded-xl bg-[#161920] border border-[#232833] hover:border-[#00d2ff] text-left transition-colors flex items-center justify-between"
                  >
                    <div>
                      <p className="text-xs font-semibold text-white">Deep Cyber Cyan Gradient</p>
                      <p className="text-[10px] text-slate-400">Minimalist modern backdrop</p>
                    </div>
                    <span className="text-xs text-[#00d2ff]">Apply</span>
                  </button>
                </div>
              </div>
            )}

            {activeToolId === 'portrait' && (
              <div className="space-y-4">
                <div>
                  <h4 className="text-sm font-semibold text-white">AI Portrait Retouching</h4>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                    Applies mathematical frequency separation: blemishes and tonal unevenness are diffused while high-frequency skin pores and iris clarity remain sharp.
                  </p>
                </div>

                <div className="space-y-1.5 p-3 rounded-xl bg-[#161920] border border-[#222732]">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-300">Retouch Intensity</span>
                    <span className="font-mono text-slate-400">{retouchStrength}%</span>
                  </div>
                  <input
                    type="range"
                    min="10"
                    max="90"
                    value={retouchStrength}
                    onChange={(e) => setRetouchStrength(parseInt(e.target.value))}
                    className="w-full h-1 bg-[#232833] rounded appearance-none cursor-pointer"
                  />
                </div>

                <button
                  onClick={handlePortraitRetouch}
                  disabled={loading || !selectedLayer}
                  className="w-full py-2.5 px-4 rounded-xl bg-[#00d2ff] hover:bg-[#38dcff] disabled:opacity-40 text-black font-semibold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-sm"
                >
                  {loading ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <UserCheck className="w-4 h-4" />
                  )}
                  <span>Retouch Portrait Skin</span>
                </button>
              </div>
            )}

            {activeToolId === 'upscale' && (
              <div className="space-y-4">
                <div>
                  <h4 className="text-sm font-semibold text-white">AI Super Resolution</h4>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                    Increases image dimensions using bicubic interpolation followed by an edge-sharpening convolution pass.
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setUpscaleFactor(2)}
                    className={`py-2 rounded-xl text-xs font-mono font-bold border transition-colors ${
                      upscaleFactor === 2
                        ? 'bg-[#182330] border-[#00d2ff] text-[#00d2ff]'
                        : 'bg-[#161920] border-[#222732] text-slate-300'
                    }`}
                  >
                    2× Ultra HD
                  </button>
                  <button
                    onClick={() => setUpscaleFactor(4)}
                    className={`py-2 rounded-xl text-xs font-mono font-bold border transition-colors ${
                      upscaleFactor === 4
                        ? 'bg-[#182330] border-[#00d2ff] text-[#00d2ff]'
                        : 'bg-[#161920] border-[#222732] text-slate-300'
                    }`}
                  >
                    4× Extreme HD
                  </button>
                </div>

                <button
                  onClick={handleUpscale}
                  disabled={loading || !selectedLayer}
                  className="w-full py-2.5 px-4 rounded-xl bg-[#00d2ff] hover:bg-[#38dcff] disabled:opacity-40 text-black font-semibold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-sm"
                >
                  {loading ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <Maximize className="w-4 h-4" />
                  )}
                  <span>Upscale Canvas ({upscaleFactor}x)</span>
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Center Canvas */}
        <StudioCanvas />
      </div>
    </div>
  );
};
