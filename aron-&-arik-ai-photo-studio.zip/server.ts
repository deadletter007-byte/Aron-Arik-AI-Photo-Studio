import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT) : 3000;

// Body parsers with generous limits for image base64 transfers
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Helper to get Gemini client
function getGeminiClient(customKey?: string) {
  const apiKey = customKey || process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// 1. Health & Config status
app.get('/api/ai/status', (req: Request, res: Response) => {
  res.json({
    geminiConfigured: !!process.env.GEMINI_API_KEY,
    status: 'ready',
    version: '1.0.0',
    model: 'gemini-3.8-flash',
  });
});

// 2. AI Assistant Chat (Gemini 3.8 Flash with Multimodal Vision support)
app.post('/api/ai/chat', async (req: Request, res: Response) => {
  try {
    const { message, imageBase64, history, systemInstruction, customApiKey } = req.body;
    const ai = getGeminiClient(customApiKey);

    if (!ai) {
      res.status(400).json({
        error: 'Gemini API key is not configured. Please add GEMINI_API_KEY in the Secrets panel or provide your key in Studio Settings.',
      });
      return;
    }

    const defaultSystem = `You are Aron & Arik AI Photo Studio Assistant, an expert digital photography consultant, Adobe Photoshop master, and Adobe Lightroom specialist.
You help photographers and artists analyze composition, suggest precise Lightroom tone and color slider values (exposure, contrast, highlights, shadows, vibrance, temp, tint, curves), offer layer-by-layer retouching advice, and generate creative prompts for generative edits.
Keep advice practical, concise, and structured. When giving Lightroom adjustments, specify exact numbers between -100 and +100 where relevant.`;

    const contents: any[] = [];

    // Prior conversation history if provided
    if (Array.isArray(history)) {
      for (const h of history) {
        contents.push({
          role: h.role === 'assistant' ? 'model' : 'user',
          parts: [{ text: h.content }],
        });
      }
    }

    // Current turn parts
    const currentParts: any[] = [];
    if (imageBase64) {
      // Clean base64 header if present
      const cleanBase64 = imageBase64.replace(/^data:image\/\w+;base64,/, '');
      currentParts.push({
        inlineData: {
          mimeType: 'image/jpeg',
          data: cleanBase64,
        },
      });
    }
    currentParts.push({
      text: message || 'Analyze this image and provide professional editing recommendations.',
    });

    contents.push({
      role: 'user',
      parts: currentParts,
    });

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents,
      config: {
        systemInstruction: systemInstruction || defaultSystem,
      },
    });

    res.json({
      reply: response.text ?? 'No response generated.',
    });
  } catch (error: any) {
    console.error('Gemini chat error:', error);
    res.status(500).json({
      error: error.message || 'Error communicating with AI assistant.',
    });
  }
});

// 3. Deep Vision Analysis & Preset Recommendation
app.post('/api/ai/analyze-image', async (req: Request, res: Response) => {
  try {
    const { imageBase64, customApiKey } = req.body;
    const ai = getGeminiClient(customApiKey);

    if (!ai) {
      res.status(400).json({
        error: 'Gemini API key is not configured.',
      });
      return;
    }

    if (!imageBase64) {
      res.status(400).json({ error: 'Image data is required for analysis.' });
      return;
    }

    const cleanBase64 = imageBase64.replace(/^data:image\/\w+;base64,/, '');

    const prompt = `Analyze this image as a master photo editor.
Return a valid JSON object with the following schema:
{
  "summary": "1-2 sentence overview of the shot",
  "subject": "detected primary subject",
  "lighting": "analysis of lighting, shadows and dynamic range",
  "colorMood": "dominant color palette and mood",
  "suggestedAdjustments": {
    "exposure": number between -2.0 and 2.0 (e.g. 0.3),
    "contrast": integer between -50 and 50,
    "highlights": integer between -100 and 100,
    "shadows": integer between -100 and 100,
    "whites": integer between -50 and 50,
    "blacks": integer between -50 and 50,
    "temperature": integer between -50 and 50,
    "tint": integer between -30 and 30,
    "vibrance": integer between -50 and 50,
    "saturation": integer between -50 and 50,
    "clarity": integer between 0 and 50,
    "sharpening": integer between 0 and 60
  },
  "recommendedTools": ["tool1", "tool2", "tool3"],
  "photoshopAdvice": ["step 1", "step 2"],
  "bestPreset": "one of: Cinematic, Moody Dark, Studio Portrait, Clean Bright, Film 400, HDR Landscape"
}
Output only pure JSON.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: 'image/jpeg',
              data: cleanBase64,
            },
          },
          { text: prompt },
        ],
      },
      config: {
        responseMimeType: 'application/json',
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    res.json(parsed);
  } catch (error: any) {
    console.error('Image analysis error:', error);
    res.status(500).json({
      error: error.message || 'Image analysis failed.',
    });
  }
});

// 4. Natural Language Editing Command Parser
app.post('/api/ai/parse-command', async (req: Request, res: Response) => {
  try {
    const { command, customApiKey } = req.body;
    const ai = getGeminiClient(customApiKey);

    if (!ai) {
      res.status(400).json({ error: 'Gemini API key is not configured.' });
      return;
    }

    const prompt = `You are an AI translation engine for Aron & Arik AI Photo Studio.
The user enters a natural language photo editing request: "${command}"

Translate this into structured adjustments and recommended action.
Return a valid JSON object matching:
{
  "explanation": "Brief description of what will be changed",
  "adjustments": {
    "exposure": optional number (-2.0 to 2.0),
    "contrast": optional integer (-100 to 100),
    "highlights": optional integer (-100 to 100),
    "shadows": optional integer (-100 to 100),
    "whites": optional integer (-100 to 100),
    "blacks": optional integer (-100 to 100),
    "temperature": optional integer (-100 to 100),
    "tint": optional integer (-100 to 100),
    "vibrance": optional integer (-100 to 100),
    "saturation": optional integer (-100 to 100),
    "clarity": optional integer (0 to 100),
    "sharpening": optional integer (0 to 100),
    "dehaze": optional integer (-50 to 50),
    "vignette": optional integer (-100 to 100)
  },
  "action": "apply_adjustments" | "remove_background" | "auto_enhance" | "portrait_retouch" | "black_and_white"
}
Output only pure JSON.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    res.json(parsed);
  } catch (error: any) {
    console.error('Command parsing error:', error);
    res.status(500).json({
      error: error.message || 'Failed to interpret editing command.',
    });
  }
});

// 5. ChatGPT Provider Proxy (if user provides OpenAI API key)
app.post('/api/ai/openai/chat', async (req: Request, res: Response) => {
  try {
    const { message, apiKey, imageBase64 } = req.body;
    if (!apiKey) {
      res.status(400).json({
        error: 'OpenAI API key is required to use the ChatGPT provider. Enter it in Settings.',
      });
      return;
    }

    const messages: any[] = [
      {
        role: 'system',
        content: 'You are the ChatGPT assistant for Aron & Arik AI Photo Studio. Provide expert photo editing, Photoshop, and Lightroom guidance.',
      },
    ];

    if (imageBase64) {
      messages.push({
        role: 'user',
        content: [
          { type: 'text', text: message || 'Analyze this image for photo editing.' },
          { type: 'image_url', image_url: { url: imageBase64 } },
        ],
      });
    } else {
      messages.push({
        role: 'user',
        content: message,
      });
    }

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages,
      }),
    });

    if (!response.ok) {
      const errData = await response.json().catch(() => ({}));
      res.status(response.status).json({
        error: errData.error?.message || `OpenAI API returned status ${response.status}`,
      });
      return;
    }

    const data = await response.json();
    res.json({
      reply: data.choices?.[0]?.message?.content || 'No response from ChatGPT.',
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'OpenAI chat request failed.' });
  }
});

// Setup Vite middleware in dev or static files in production
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Aron & Arik AI Photo Studio server running on port ${PORT}`);
  });
}

startServer();
